type LiterarySource=string|{text:string;name?:string};
// Explicit title association is a metadata check, not independent bibliographic verification.
export function unsupportedLiteraryQuote(question:string,text:string,sources:LiterarySource[]):boolean {
 const asserted=/(?:원문|원작|시구|구절|첫\s*행|첫\s*문장)[은는이가을를]?\s*(?:은|는|:|：|다음|["“‘「『])/;
 const originalRequested=/(원문|시구|인용)/.test(question);
 const explicitCreation=/(창작|지어\s*줘|써\s*줘)/.test(question)&&!/(원문|실제|인용)/.test(question);
 if(explicitCreation&&!asserted.test(text))return false;
 if(!originalRequested&&!asserted.test(text))return false;
 const normalize=(s:string)=>s.normalize('NFC').replace(/\s+/g,'');
 // Line breaks are part of an original quotation, not a reason to skip evidence checks.
 const quotes=[...text.matchAll(/["“‘「『]([^"”’」』]{4,500})["”’」』]/g)].map(m=>m[1]);
 // A model may omit quotation marks but still explicitly label a passage as original.
 for(const m of text.matchAll(/(?:원문|시구|구절)\s*[:：]\s*([^\n]{4,500})/g)){
  if(!/^["“‘「『]/.test(m[1]))quotes.push(m[1].trim());
 }
 const titles=[...question.matchAll(/[「『《〈]([^」』》〉\n]{1,80})[」』》〉]/g)].map(m=>m[1].trim());
 const scoped=sources.filter(source=>{
  if(!titles.length)return true;
  const identity=typeof source==='string'?source:(source.name||'')+'\n'+source.text;
  return titles.some(title=>{
   const escaped=title.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
   return new RegExp('(^|[^\\p{L}\\p{N}])'+escaped+'(?=$|[^\\p{L}\\p{N}])','u').test(identity.normalize('NFC'));
  });
 });
 return quotes.some(q=>!scoped.some(s=>normalize(typeof s==='string'?s:s.text).includes(normalize(q))));
}

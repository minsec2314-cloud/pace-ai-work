type LiterarySource=string|{text:string;name?:string};
// Explicit title association is a metadata check, not independent bibliographic verification.
export function unsupportedLiteraryQuote(question:string,text:string,sources:LiterarySource[]):boolean {
 const markedText=text.replace(/\r\n?/g,'\n').replace(/^([ \t]*)(\*\*|__)(원문|시구|구절)[:：]?\2[ \t]*[:：]?/gm,'$1$3:').replace(/^([ \t]*)(원문|시구|구절)[ \t]*$/gm,'$1$2:');
 const asserted=/(?:원문|원작|시구|구절|첫\s*행|첫\s*문장)[은는이가을를]?\s*(?:은|는|:|：|다음|["“‘「『])/;
 const originalRequested=/(원문|시구|인용)/.test(question);
 const explicitCreation=/(창작|지어\s*줘|써\s*줘)/.test(question)&&!/(원문|실제|인용)/.test(question);
 if(explicitCreation&&!asserted.test(markedText))return false;
 if(!originalRequested&&!asserted.test(markedText))return false;
 const normalize=(s:string)=>s.normalize('NFC').replace(/\s+/g,'');
 // Line breaks and long excerpts must not skip evidence checks.
 // Inspect the complete quoted span/labelled line rather than silently ignoring or clipping it.
 const attributions=[...markedText.matchAll(/[「『《〈]([^」』》〉\n]{1,80})[」』》〉](?=\s*의\s*(?:원문|시구|구절))/g)].map(m=>({title:m[1].trim(),index:m.index!}));
 const quotes=[...markedText.matchAll(/["“‘「『]([^"”’」』]{4,})["”’」』]/g)].filter(m=>!attributions.some(a=>a.index===m.index)).map(m=>({text:m[1],index:m.index!}));
 // Explicit unquoted original blocks continue until a blank line or a labelled explanation.
 // Do not validate only the first line while returning an unchecked continuation.
 for(const m of markedText.matchAll(/(?:원문|시구|구절)[ \t]*[:：][ \t]*/g)){
  const rest=markedText.slice(m.index!+m[0].length);
  if(/^["“‘「『]/.test(rest.trimStart()))continue; // Quoted spans are checked above.
  const lines=rest.replace(/^(?:[ \t]*\n)+/,'').split('\n');
  const block:string[]=[];
  const fence=lines[0]?.match(/^[ \t]*(`{3,}|~{3,})[^\n]*$/);
  if(fence){
   const close=new RegExp('^[ \\t]*'+fence[1][0]+'{'+fence[1].length+',}[ \\t]*$');
   for(const line of lines.slice(1)){if(close.test(line))break;block.push(line);}
  }else if(/^[ \t]*>/.test(lines[0]||'')){
   for(const line of lines){const quoted=line.match(/^[ \t]*>[ \t]?(.*)$/);if(!quoted)break;block.push(quoted[1]);}
  }else for(const line of lines){
   if(!line.trim()||/^(?:해설|설명|의미|풀이|분석|참고|출처)\s*[:：]/.test(line.trim()))break;
   block.push(line.trim());
  }
  const excerpt=block.join('\n');if(excerpt.trim().length>=4)quotes.push({text:excerpt,index:m.index!});
 }
 const titles=[...question.matchAll(/[「『《〈]([^」』》〉\n]{1,80})[」』》〉]/g)].map(m=>m[1].trim());
 const matchesTitle=(source:LiterarySource,title:string)=>{
  const identity=typeof source==='string'?source:(source.name||'')+'\n'+source.text;
  const escaped=title.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  return new RegExp('(^|[^\\p{L}\\p{N}])'+escaped+'(?=$|[^\\p{L}\\p{N}])','u').test(identity.normalize('NFC'));
 };
 return quotes.some(q=>{
  // A claimed work belongs to this excerpt,not any other work in the request.
  const attributed=attributions.filter(a=>a.index<q.index).at(-1)?.title;
  const targets=attributed?[attributed]:titles;
  const scoped=targets.length?sources.filter(source=>targets.some(title=>matchesTitle(source,title))):sources;
  return !scoped.some(source=>normalize(typeof source==='string'?source:source.text).includes(normalize(q.text)));
 });
}

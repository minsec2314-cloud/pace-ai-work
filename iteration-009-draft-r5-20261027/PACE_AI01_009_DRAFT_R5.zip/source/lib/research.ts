import type { Source } from './study.ts';
export function textOnly(input:unknown,max=4000){return typeof input==='string'?input.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').trim().slice(0,max):'';}
type CrossrefWork={DOI?:string;title?:string[];author?:{given?:string;family?:string}[];published?:{'date-parts'?:number[][]};abstract?:string;type?:string};
// A DOI suffix is an opaque identifier. Encode each path segment so ? and #
// remain part of that identifier rather than changing the resolver URL.
export function crossrefSources(works:CrossrefWork[]):Source[]{
 if(!Array.isArray(works))throw new Error('학술 검색 결과의 형식을 읽지 못했습니다. 잠시 후 다시 시도해 주세요.');
 return works.flatMap(w=>{
  if(!w||typeof w.DOI!=='string'||!/^10\.\d{4,9}\/.+/u.test(w.DOI)||!Array.isArray(w.title)||typeof w.title[0]!=='string')return [];
  const title=textOnly(w.title[0],400);if(!title)return [];
  const authors=(Array.isArray(w.author)?w.author:[]).slice(0,4).filter(a=>a&&typeof a==='object').map(a=>[a.given,a.family].filter(p=>typeof p==='string'&&p.trim()).join(' ')).filter(Boolean).join(', ')||'저자 정보 없음';
  return [{id:w.DOI,title,url:`https://doi.org/${w.DOI.split('/').map(part=>encodeURIComponent(part)).join('/')}`,authors,year:String(w.published?.['date-parts']?.[0]?.[0]||'연도 미확인'),abstract:textOnly(w.abstract),provider:'Crossref'}];
 });
}
// Fixed scientific aliases only: unknown words/constraints are retained, never guessed.
export function researchProviderQuery(query:string):string {
 return query.normalize('NFKC').trim()
  .replace(/나트륨\s*이온/g,'sodium-ion ').replace(/리튬\s*이온/g,'lithium-ion ')
  .replace(/리튬\s*황/g,'lithium-sulfur ').replace(/전고체/g,'solid-state ')
  .replace(/화학\s*전지(?![\p{L}\p{N}])/gu,'electrochemical batteries').replace(/(?<![\p{L}\p{N}])전지(?![\p{L}\p{N}])/gu,'batteries')
  .replace(/차세대/g,'next generation').replace(/\s+/g,' ').trim();
}
// Metadata relevance is a conservative screen, not verification of paper claims.
export function researchMatches(query:string,source:Source):boolean {
 const q=query.normalize('NFKC').toLowerCase();
 const text=(source.title+' '+source.abstract).normalize('NFKC').toLowerCase();
 const compact=(s:string)=>s.replace(/[\s-]+/g,'');
 const groups:[RegExp,RegExp][]=[
  [/화학\s*전지|(?<![\p{L}\p{N}])전지(?![\p{L}\p{N}])|\bbatter(?:y|ies)\b/u,/전지|\bbatter(?:y|ies)\b/],
  [/나트륨\s*이온|sodium[ -]?ion/,/나트륨\s*이온|\bsodium[ -]?ion\b/],
  [/리튬\s*이온|lithium[ -]?ion/,/리튬\s*이온|\blithium[ -]?ion\b/],
  [/리튬\s*황|lithium[ -]?sulfur/,/리튬\s*황|\blithium[ -]?sulfur\b/],
  [/전고체|solid[ -]?state/,/전고체|\bsolid[ -]?state\b/],
 ];
 const required=groups.filter(([pattern])=>pattern.test(q));
 if(!required.every(([,pattern])=>pattern.test(text)))return false;
 // A recognized domain term must not erase additional user constraints.
 // These query patterns contain no capturing groups or stateful flags.
 let remainder=q;
 for(const [pattern] of required)remainder=remainder.replace(new RegExp(pattern.source,pattern.flags+'g'),' ');
 if(required.length)remainder=remainder.replace(/차세대|화학|\bnext[ -]?generation\b/g,' ');
 const terms=(remainder.match(/[\p{L}\p{N}]{2,}/gu)||[]).filter(term=>!['the','and','for','of','in','on','with'].includes(term));
 return (required.length>0||terms.length>0)&&terms.every(term=>compact(text).includes(compact(term)));
}
export async function searchResearch(query:string,fetcher:typeof fetch=fetch):Promise<Source[]>{
 if(query.trim().length<2||query.length>200)throw new Error('검색어를 2~200자로 입력해 주세요.');
 const url=new URL('https://api.crossref.org/works');url.searchParams.set('query.bibliographic',researchProviderQuery(query));url.searchParams.set('rows','7');url.searchParams.set('select','DOI,title,author,published,abstract,type');
 const response=await fetcher(url,{headers:{'User-Agent':'PaceStudyResearch/1.0','Accept':'application/json'},signal:AbortSignal.timeout(20000)});
 if(!response.ok)throw new Error(response.status===429?'학술 검색 요청이 많습니다. 잠시 후 다시 시도해 주세요.':'학술 검색 서버에 연결하지 못했습니다.');
 let data:{message?:{items?:CrossrefWork[]}}|null;
 try{data=await response.json() as typeof data;}catch{throw new Error('학술 검색 결과의 형식을 읽지 못했습니다. 잠시 후 다시 시도해 주세요.');}
 if(!Array.isArray(data?.message?.items))throw new Error('학술 검색 결과의 형식을 읽지 못했습니다. 잠시 후 다시 시도해 주세요.');
 return crossrefSources(data.message.items).filter(source=>researchMatches(query,source));
}

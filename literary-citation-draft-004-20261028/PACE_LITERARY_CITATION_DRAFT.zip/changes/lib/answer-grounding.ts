type LiterarySource=string|{text:string;name?:string};
// Explicit title association is a metadata check, not independent bibliographic verification.
export function unsupportedLiteraryQuote(question:string,text:string,sources:LiterarySource[]):boolean {
 const asserted=/(?:원문|원작|시구|구절|첫\s*행|첫\s*문장)[은는이가을를]?\s*(?:은|는|:|：|다음|["“‘「『])/;
 const originalRequested=/(원문|시구|인용)/.test(question);
 const explicitCreation=/(창작|지어\s*줘|써\s*줘)/.test(question)&&!/(원문|실제|인용)/.test(question);
 if(explicitCreation&&!asserted.test(text))return false;
 if(!originalRequested&&!asserted.test(text))return false;
 const normalize=(s:string)=>s.normalize('NFC').replace(/\s+/g,'');
 // Line breaks and long excerpts must not skip evidence checks.
 // Inspect the complete quoted span/labelled line rather than silently ignoring or clipping it.
 const quotes=[...text.matchAll(/["“‘「『]([^"”’」』]{4,})["”’」』]/g)].map(m=>m[1]);
 // Explicit unquoted original blocks continue until a blank line or a labelled explanation.
 // Do not validate only the first line while returning an unchecked continuation.
 for(const m of text.matchAll(/(?:원문|시구|구절)[ \t]*[:：][ \t]*/g)){
  const rest=text.slice(m.index!+m[0].length);
  if(/^["“‘「『]/.test(rest.trimStart()))continue; // Quoted spans are checked above.
  const lines=rest.split(/\r?\n/);if(!lines[0].trim())lines.shift();
  const block:string[]=[];
  for(const line of lines){
   if(!line.trim()||/^(?:해설|설명|의미|풀이|분석|참고|출처)\s*[:：]/.test(line.trim()))break;
   block.push(line.trim());
  }
  const excerpt=block.join('\n');if(excerpt.trim().length>=4)quotes.push(excerpt);
 }
 const titles=[...question.matchAll(/[「『《〈]([^」』》〉\n]{1,80})[」』》〉]/g)].map(m=>m[1].trim());
 const scoped=sources.filter(source=>{
  if(!titles.length)return true;
  const identity=typeof source==='string'?source:(source.name||'')+'\n'+source.text;
  return titles.some(title=>{
   const escaped=title.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
   return new RegExp('(^|[^\\p{L}\\p{N}])'+escaped+'(?=$|[^\\p{L}\\p{N}])','u').test(identity.normalize('NFC'));
  });
 });
 return quotes.some(q=>!scoped.some(s=>normalize(typeof s==='string'?s:s.text).includes(normalize(q))));
}

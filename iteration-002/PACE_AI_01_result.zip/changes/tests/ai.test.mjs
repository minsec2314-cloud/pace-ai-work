import test from 'node:test';import assert from 'node:assert/strict';
import {selectContext,verifyCitations,validateAIInput,generateAI,AIError,resolveReferences} from '../lib/ai.ts';
import {crossrefSources,searchResearch} from '../lib/research.ts';
const material={id:'m1',subjectId:'s',name:'수업 자료',kind:'lesson',sections:[{page:1,text:'좌극한과 우극한이 모두 존재하고 서로 같으면 극한이 존재한다.'},{page:2,text:'함수의 연속은 함숫값과 극한값이 같아야 한다.'}]};
const ask={mode:'ask',subject:'수학',question:'극한의 뜻은?',materials:[material]};
const past={...material,id:'past1',kind:'exam',sections:[{page:1,text:'기출: 좌극한과 우극한 조건을 주고 극한의 존재를 판단하는 서술형 문제.'}]};
const teacherQuiz={...ask,mode:'quiz',quizMode:'exam',materials:[material,past],count:1};
const response=(data,status=200)=>async(_url,request)=>{if(request&&JSON.parse(request.body).messages[0].content.startsWith('독립 풀이 검토')){const n=JSON.parse(JSON.parse(request.body).messages.at(-1).content).questions.length;return Response.json({choices:[{message:{content:JSON.stringify({solutions:Array.from({length:n},()=>({answer:'검산 답',explanation:'문제의 조건으로 다시 풀었습니다.'}))})},finish_reason:'stop'}]});}return new Response(JSON.stringify(status===200?{choices:[{message:{content:JSON.stringify(data)},finish_reason:'stop'}]}:data),{status});};
test('only accepts citations whose page and exact quote exist',()=>{const ctx=selectContext([material],'극한');assert.equal(verifyCitations([{materialId:'m1',page:1,quote:'좌극한과 우극한이 모두 존재하고 서로 같으면'}],ctx).length,1);for(const c of [{materialId:'madeup',page:1,quote:'좌극한과 우극한'},{materialId:'m1',page:99,quote:'좌극한과 우극한'},{materialId:'m1',page:1,quote:'연속이면 미분이 가능하다'}])assert.equal(verifyCitations([c],ctx).length,0);});
test('context obeys budget and keeps document coverage',()=>{const docs=Array.from({length:3},(_,i)=>({...material,id:'m'+i,sections:[{page:1,text:'극한'.repeat(700)}]}));const c=selectContext(docs,'극한',4000);assert(c.reduce((a,c)=>a+c.text.length,0)<=4000);assert.equal(new Set(c.map(c=>c.materialId)).size,3);});
test('validates requests and requires documents for teacher exam mode',()=>{assert.equal(validateAIInput(ask).mode,'ask');assert.throws(()=>validateAIInput({...ask,question:''}));assert.throws(()=>validateAIInput({...ask,mode:'quiz',quizMode:'exam',materials:[]}));assert.equal(validateAIInput({...ask,mode:'quiz',quizMode:'practice',materials:[]}).quizMode,'practice');assert.throws(()=>validateAIInput({...ask,materials:[{...material,sections:[{page:-1,text:'bad'}]}]}));});
test('unconfigured API does not fabricate a successful answer',async()=>{await assert.rejects(generateAI(ask,''),e=>e instanceof AIError&&e.status===503);});
test('rate limit is surfaced without a paid fallback',async()=>{let calls=0;await assert.rejects(generateAI(ask,'fake',async()=>{calls++;return new Response('{}',{status:429});}),e=>e.status===429);assert.equal(calls,1);});
test('removes unsupported citations from otherwise readable answers',async()=>{const r=await generateAI(ask,'fake',response({text:'설명',citations:[{materialId:'fake',page:1,quote:'가짜 원문'}]}));assert.equal(r.citations.length,0);assert(r.warning.includes('연결한 근거가 없습니다'));});
test('rejects a generated exam with no verifiable original source',async()=>{await assert.rejects(generateAI({...ask,mode:'quiz',count:1},'fake',response({analysis:'분석',questions:[{type:'서술형',question:'문제',answer:'정답',explanation:'해설',citations:[{materialId:'m1',page:1,quote:'없는 문장'}]}]})),e=>e.status===502);});
test('accepts grounded material practice without claiming teacher analysis',async()=>{const r=await generateAI({...ask,mode:'quiz',count:1},'fake',response({title:'연습',analysis:'조건 판단',questions:[{type:'서술형',question:'극한 존재 조건은?',answer:'좌우극한 일치',explanation:'조건을 확인한다.',citations:[{materialId:'m1',page:1,quote:'좌극한과 우극한이 모두 존재하고 서로 같으면'}]}]}));assert.equal(r.questions.length,1);assert(r.limitations.includes('일반 연습 문제'));});
test('does not accept malformed or truncated responses',async()=>{await assert.rejects(generateAI(ask,'fake',async()=>new Response('{"choices":[{"finish_reason":"length","message":{"content":"{}"}}]}')),e=>e.status===502);});
test('reference IDs restore exact original evidence even when the model rewords a quote',()=>{const context=selectContext([material],'극한');const result=resolveReferences([context[0].referenceId,'invented'],context);assert.equal(result.length,1);assert.equal(result[0].materialId,'m1');assert.equal(result[0].quote,context[0].text);assert.equal(result[0].page,context[0].page);});
test('teacher mode requires both past exams and lesson materials',()=>{assert.throws(()=>validateAIInput({...teacherQuiz,materials:[material]}),/기출과/);assert.throws(()=>validateAIInput({...teacherQuiz,materials:[past]}),/기출과/);assert.equal(validateAIInput(teacherQuiz).quizMode,'exam');assert.equal(validateAIInput({...teacherQuiz,quizMode:'practice',materials:[material]}).quizMode,'practice');});
test('unreadable PDF text is explained before consuming AI quota',async()=>{let calls=0;const broken={...past,sections:[{page:1,text:'깨진 수식 '+String.fromCharCode(0xE001).repeat(100)}]};const fetcher=async()=>{calls++;throw Error('must not call');};await assert.rejects(generateAI({...teacherQuiz,materials:[broken,material]},'fake',fetcher),e=>e.status===400&&e.message.includes('글자·수식'));await assert.rejects(generateAI({...ask,mode:'quiz',quizMode:'practice',materials:[broken]},'fake',fetcher),e=>e.status===400&&e.message.includes('읽을 수 있는'));assert.equal(calls,0);});
test('teacher analysis cites past exams while each new question cites lesson content',async()=>{const context=selectContext(teacherQuiz.materials,teacherQuiz.question);const lessonRef=context.find(c=>c.kind==='lesson').referenceId,pastRef=context.find(c=>c.kind==='exam').referenceId;const output={title:'기출 방식 연습',analysis:'조건을 해석하는 서술형이 관찰됩니다.',analysisReferenceIds:[pastRef],patterns:[{feature:'조건 해석 서술형',referenceIds:[pastRef],application:'좌우극한 조건을 설명한다.'}],questions:[{question:'극한이 존재하기 위한 조건은?',answer:'좌우극한이 존재하고 같아야 한다.',explanation:'조건을 확인한다.',referenceIds:[lessonRef]}]};const result=await generateAI(teacherQuiz,'fake',response(output));assert.equal(result.analysisCitations[0].materialId,'past1');assert.equal(result.questions[0].citations[0].materialId,'m1');await assert.rejects(generateAI(teacherQuiz,'fake',response({...output,analysisReferenceIds:[lessonRef],patterns:[{feature:'잘못 연결',referenceIds:[lessonRef],application:'확인'}]})),e=>e.status===502);});
test('one automatic repair recovers omitted references without accepting fabricated evidence',async()=>{let attempts=0;const fetcher=async(_url,request)=>{if(JSON.parse(request.body).messages[0].content.startsWith('독립 풀이 검토'))return response({})(_url,request);attempts++;const sent=JSON.parse(request.body),ctx=JSON.parse(sent.messages.at(-1).content).referenceMaterial;return response({analysis:'연습',questions:[{question:'극한 조건?',answer:'좌우극한 일치',explanation:'원문 조건 확인',referenceIds:attempts===1?['unknown']: [ctx[0].referenceId]}]})();};const result=await generateAI({...ask,mode:'quiz',quizMode:'practice',count:1},'fake',fetcher);assert.equal(attempts,2);assert.equal(result.questions[0].citations[0].materialId,'m1');});
test('Crossref sources preserve real DOI links and strip markup',()=>{const s=crossrefSources([{DOI:'10.1234/example',title:['<b>Photosynthesis</b>'],author:[{given:'A',family:'Kim'}],published:{'date-parts':[[2024]]},abstract:'<jats:p>Light matters.</jats:p>'},{DOI:'javascript:bad',title:['bad']}]);assert.equal(s.length,1);assert.equal(s[0].url,'https://doi.org/10.1234/example');assert.equal(s[0].title,'Photosynthesis');assert.equal(s[0].abstract,'Light matters.');});
test('research search uses fixed official API, not user-supplied URLs',async()=>{let actual;const result=await searchResearch('photosynthesis',async(url)=>{actual=String(url);return Response.json({message:{items:[]}});});assert(actual.startsWith('https://api.crossref.org/works?'));assert.deepEqual(result,[]);await assert.rejects(searchResearch('x'));});

for(const status of [429,401,403,500])test(`review HTTP ${status} preserves status without restarting generation`,async()=>{
 let generations=0,reviews=0;
 const fetcher=async(_url,request)=>{
  if(JSON.parse(request.body).messages[0].content.startsWith('독립 풀이 검토')){reviews++;return new Response('{}',{status});}
  generations++;
  return response({analysis:'일차식 연습',questions:[{question:'x+1=2에서 x는?',answer:'1',explanation:'양변에서 1을 뺀다.'}]})(_url,request);
 };
 await assert.rejects(generateAI({...ask,mode:'quiz',quizMode:'practice',materials:[],count:1},'synthetic-only',fetcher),e=>e.status===(status===429?429:[401,403].includes(status)?503:502));
 assert.equal(generations,1);assert.equal(reviews,1);
});
for(const failure of ['network','truncated','invalid-json','unsolved'])test(`review ${failure} failure is not retried as generation`,async()=>{
 let calls=0;
 const fetcher=async(_url,request)=>{
  calls++;
  if(JSON.parse(request.body).messages[0].content.startsWith('독립 풀이 검토')){
   if(failure==='network')throw Error('synthetic network failure');
   return Response.json({choices:[{finish_reason:failure==='truncated'?'length':'stop',message:{content:failure==='invalid-json'?'{':JSON.stringify({solutions:[{answer:'',explanation:'',error:'조건 부족'}]})}}]});
  }
  return response({analysis:'일차식 연습',questions:[{question:'x+1=2에서 x는?',answer:'1',explanation:'1을 뺀다.'}]})(_url,request);
 };
 await assert.rejects(generateAI({...ask,mode:'quiz',materials:[],count:1},'synthetic-only',fetcher),e=>e.status===(failure==='network'?504:502));
 assert.equal(calls,2);
});

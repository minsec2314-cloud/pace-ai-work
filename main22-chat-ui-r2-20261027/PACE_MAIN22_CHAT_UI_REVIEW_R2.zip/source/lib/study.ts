import {validRoutineState,type StudyRoutine,type RoutineRecord} from './routines.ts';
import {validAvailability,type AvailabilityPlan} from './availability.ts';
import {availabilityForDay} from './availability.ts';
import {freeStudyWindows,koreaTime} from './window-planning.ts';
import type {TeacherProfile} from './teachers';
import type { TopicLab } from './topics';
import { validTopicIdea } from './topics.ts';
export type Subject = { id: string; name: string; color: string; examDate: string; scope: string; minutes: number; confidence: number; teacher: string };
export type Source = { id:string; title:string; url:string; authors:string; year:string; abstract:string; provider:string };
export type Assessment = { requiresLaptop?:boolean; id: string; subjectId: string; title: string; due: string; prepareBy?:string; minutes: number; done: boolean; note: string; category?:'assessment'|'research'|'other'; journal?:string; dueTime?:string; reminderMinutes?:number; steps?:{id:string;title:string;done:boolean}[]; sources?:Source[]; aiNotes?:{id:string;title:string;text:string;createdAt:string}[] };
export type Session = { id: string; sourceId: string; kind: 'subject'|'task'; date: string; subjectId: string; title: string; minutes: number; done: boolean; startsAt?:string; availabilityLabel?:string };
export type SessionGroup={id:string;title:string;subjectId:string;kind:Session['kind'];date:string;sessions:Session[];minutes:number;doneMinutes:number;done:boolean};
export function groupSessions(sessions:Session[]):SessionGroup[]{
 const groups=new Map<string,SessionGroup>();for(const session of sessions){const id=JSON.stringify([session.date,session.kind,session.sourceId,session.subjectId]);let group=groups.get(id);if(!group){group={id,title:session.title,subjectId:session.subjectId,kind:session.kind,date:session.date,sessions:[],minutes:0,doneMinutes:0,done:false};groups.set(id,group);}group.sessions.push(session);group.minutes+=session.minutes;if(session.done)group.doneMinutes+=session.minutes;}
 return [...groups.values()].map(g=>({...g,done:g.sessions.every(s=>s.done)}));
}
export type Section = { page: number; text: string };
export type Material = { id: string; subjectId: string; name: string; kind: 'lesson'|'exam'; sections: Section[]; createdAt: string; size: number; warning?: string; taskId?:string };
export type Citation = { materialId: string; page: number; quote: string };
export type ChatThread = {id:string;subjectId:string;taskId?:string;title:string;archived:boolean};
export type Answer = { chatId?:string; text: string; citations: Citation[]; warning?: string; createdAt: string; question: string; subjectId: string; taskId?:string };
export type QuizQuestion = { question: string; answer: string; explanation: string; type: string; citations: Citation[] };
export type Quiz = { id: string; subjectId: string; title: string; analysis: string; limitations: string; questions: QuizQuestion[]; createdAt: string; scores: Record<string, boolean>; mode?:'practice'|'exam'; teacherProfileId?:string; teacherLabel?:string; analysisCitations?:Citation[]; patterns?:{feature:string;application:string;citations:Citation[]}[]; attempts?:Record<string,{answer:string;reflection:string}> };
export function setQuizAttempt(quiz:Quiz,index:number,patch:Partial<{answer:string;reflection:string}>):Quiz{
 if(!Number.isInteger(index)||index<0||index>=quiz.questions.length)return quiz;
 const previous=quiz.attempts?.[index]||{answer:'',reflection:''};return {...quiz,attempts:{...quiz.attempts,[index]:{answer:(patch.answer??previous.answer).slice(0,10000),reflection:(patch.reflection??previous.reflection).slice(0,10000)}}};
}
export type StudyState = { version: 1; chatThreads?:ChatThread[]; availability?:AvailabilityPlan; routines?:StudyRoutine[]; routineRecords?:RoutineRecord[]; topicLab?:TopicLab; teacherProfiles?:TeacherProfile[]; profile: { name: string; grade: string; dailyMinutes: number; weekendMinutes: number; sessionMinutes: number; school?:string; classNumber?:number; studentGrade?:number; notifications?:boolean }; timetable?:{source?:'manual'|'comcigan'|'neis';weekStart?:string;upstreamUpdatedAt?:string;cells:{day:number;period:number;subject:string}[];updatedAt:string;school:string;grade:number;classNumber:number;changes:{day:number;period:number;before:string;after:string}[]}; subjects: Subject[]; assessments: Assessment[]; sessions: Session[]; materials: Material[]; answers: Answer[]; quizzes: Quiz[]; onboarded: boolean; demo: boolean };
export const COLORS = ['#6965db','#db935b','#4f9b91','#d77791','#5f93ca','#9b81bd','#a39c4f','#88929f'];
export const DEFAULT_NAMES = ['국어','수학','영어','한국사','통합사회','통합과학'];
export function uid() { return globalThis.crypto.randomUUID(); }
export function todayKST(now = new Date()) { return new Intl.DateTimeFormat('en-CA', { timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit' }).format(now); }
export function validDate(s: unknown): s is string { return typeof s==='string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(s)) && new Date(s+'T00:00:00Z').toISOString().slice(0,10)===s; }
export function addDays(date: string, n: number) { const d=new Date(date+'T00:00:00Z'); d.setUTCDate(d.getUTCDate()+n); return d.toISOString().slice(0,10); }
export function dayDiff(a: string,b: string) { return Math.round((Date.parse(b+'T00:00:00Z')-Date.parse(a+'T00:00:00Z'))/86400000); }
export function dayLabel(date: string) { if(!validDate(date)) return '날짜 미정'; return new Intl.DateTimeFormat('ko-KR',{month:'long',day:'numeric',weekday:'short',timeZone:'UTC'}).format(new Date(date+'T00:00:00Z')); }
export function duration(n:number) { return n<60?`${n}분`:`${Math.floor(n/60)}시간${n%60?` ${n%60}분`:''}`; }
export function dday(date:string,today=todayKST()) { if(!validDate(date))return '시험 미등록';const d=dayDiff(today,date); return d===0?'D-DAY':d>0?`D-${d}`:`${-d}일 지남`; }
export function initialState(): StudyState { return {version:1,profile:{name:'',grade:'고등학교 1학년',dailyMinutes:120,weekendMinutes:180,sessionMinutes:30},subjects:[],assessments:[],sessions:[],materials:[],answers:[],quizzes:[],onboarded:false,demo:false}; }
export function subjectCompletedMinutes(state:StudyState,subjectId:string){return state.sessions.filter(s=>s.kind==='subject'&&s.sourceId===subjectId&&s.done).reduce((minutes,s)=>minutes+s.minutes,0);}
export function removeAssessment(state:StudyState,assessmentId:string):StudyState{return {...state,assessments:state.assessments.filter(t=>t.id!==assessmentId),sessions:state.sessions.filter(s=>s.kind!=='task'||s.sourceId!==assessmentId)};}
export function dailyCapacity(state:StudyState,date:string) { if(state.availability?.enabled)return availabilityForDay(state.availability,date).minutes||0;const day=new Date(date+'T00:00:00Z').getUTCDay(); return day===0||day===6?state.profile.weekendMinutes:state.profile.dailyMinutes; }
export function buildPlan(state:StudyState,today=todayKST()) {
  const done=state.sessions.filter(s=>s.done);
  const jobs = [
    ...state.subjects.filter(s=>validDate(s.examDate)).map(s=>({id:s.id,subjectId:s.id,title:s.scope.trim()||`${s.name} 시험 범위 복습`,deadline:addDays(s.examDate,-1),minutes:s.minutes,kind:'subject' as const,confidence:s.confidence})),
    ...state.assessments.filter(t=>!t.done&&validDate(t.due)).map(t=>({id:t.id,subjectId:t.subjectId,title:t.title,deadline:t.prepareBy||t.due,minutes:t.minutes,kind:'task' as const,confidence:1}))
  ].map(j=>({...j,remaining:Math.max(0,j.minutes-done.filter(s=>s.sourceId===j.id&&s.kind===j.kind).reduce((a,s)=>a+s.minutes,0))}));
  const sessions:Session[]=[...done];
  const maxDays=Math.min(366,Math.max(0,...jobs.map(j=>dayDiff(today,j.deadline)+1)));
  const counts=new Map<string,number>();
  for(let d=0;d<maxDays&&sessions.length<20000;d++){
    const date=addDays(today,d);
    const windowMode=state.availability?.enabled===true;
    const slots=windowMode?freeStudyWindows(state.availability!,date,done).sort((a,b)=>Number(a.laptop==='allowed')-Number(b.laptop==='allowed')||a.start-b.start):[{start:0,end:0,laptop:'allowed',label:'',windowId:''}];
    for(const slot of slots){
    let cursor=slot.start;
    let capacity=windowMode?(slot.end-cursor)/60000:Math.max(0,dailyCapacity(state,date)-done.filter(s=>s.date===date).reduce((a,s)=>a+s.minutes,0));
    const cutoff=(j:typeof jobs[number])=>{const t=j.kind==='task'?state.assessments.find(t=>t.id===j.id):undefined;return Date.parse(j.deadline+'T'+(t&&j.deadline===t.due?(t.dueTime||'23:59')+':00':'23:59:59')+'+09:00')+(t&&j.deadline===t.due?0:1000);};
    while(capacity>0&&sessions.length<20000){
      const candidates=jobs.filter(j=>j.remaining>0&&j.deadline>=date&&(!windowMode||((j.kind!=='task'||state.assessments.find(t=>t.id===j.id)?.requiresLaptop===false||slot.laptop==='allowed')&&cutoff(j)-cursor>=60000)));
      if(!candidates.length) break;
      candidates.sort((a,b)=>{
        const score=(j:typeof a)=>j.remaining/Math.max(1,dayDiff(date,j.deadline)+1)*(1+(5-j.confidence)*.08)*(j.kind==='task'?1.2:1);
        return score(b)-score(a)||a.deadline.localeCompare(b.deadline)||a.id.localeCompare(b.id);
      });
      const job=candidates[0];
      const minutes=Math.min(state.profile.sessionMinutes,capacity,job.remaining,windowMode?Math.floor((cutoff(job)-cursor)/60000):Infinity);
      const key=`${date}:${job.id}`; const index=(counts.get(key)||0)+1; counts.set(key,index);
      let id=`${key}:${index}`; while(done.some(s=>s.id===id)) { counts.set(key,(counts.get(key)||0)+1); id=`${key}:${counts.get(key)}`; }
      sessions.push({id,sourceId:job.id,kind:job.kind,date,subjectId:job.subjectId,title:job.title,minutes,done:false,...(windowMode?{startsAt:koreaTime(cursor),availabilityLabel:slot.label}:{})});
      capacity-=minutes; job.remaining-=minutes;cursor+=minutes*60000;
    }
    }
  }
  return {limitReached:sessions.length>=20000&&jobs.some(j=>j.remaining>0),sessions:sessions.sort((a,b)=>a.date.localeCompare(b.date)),shortages:jobs.filter(j=>j.remaining>0).map(j=>({sourceId:j.id,title:j.title,minutes:j.remaining,deadline:j.deadline,subjectId:j.subjectId}))};
}
export function replan(state:StudyState,today=todayKST()):StudyState { return {...state,sessions:buildPlan(state,today).sessions}; }
export function demoState(today=todayKST()):StudyState {
  const s=initialState();s.onboarded=true;s.demo=true;s.profile.name='나';
  s.subjects=DEFAULT_NAMES.slice(0,4).map((name,i)=>({id:`demo-sub-${i}`,name,color:COLORS[i],examDate:addDays(today,12+i),scope:['문학 작품 분석 · 문법 개념','함수의 극한 · 연속','2~4과 본문 · 핵심 어법','근대 국가 수립 운동'][i],minutes:[420,600,360,240][i],confidence:[3,2,3,4][i],teacher:''}));
  s.assessments=[{id:'demo-task-1',subjectId:s.subjects[0].id,title:'문학 작품 비평문',due:addDays(today,3),minutes:90,done:false,note:'작품 속 갈등과 나의 관점을 연결해 쓰기'},{id:'demo-task-2',subjectId:s.subjects[2].id,title:'영어 발표 준비',due:addDays(today,6),minutes:60,done:false,note:'발표문 작성과 말하기 연습'}];
  s.materials=[{id:'demo-material-1',subjectId:s.subjects[1].id,name:'시연용_함수의_극한.pdf',kind:'lesson',createdAt:new Date().toISOString(),size:0,warning:'직접 작성한 시연 자료입니다. 실제 선생님 자료가 아닙니다.',sections:[{page:1,text:'함수의 극한은 x가 a에 가까워질 때 f(x)가 가까워지는 값이다. 좌극한과 우극한이 모두 존재하고 서로 같으면 그 점에서 극한이 존재한다. 극한값과 함숫값은 서로 다를 수 있다.'},{page:2,text:'함수 f가 x=a에서 연속이려면 f(a)가 정의되고, x가 a로 갈 때 f(x)의 극한이 존재하며, 그 극한값이 f(a)와 같아야 한다. 세 가지 조건을 모두 확인한다. 연습: f(x)=(x²-1)/(x-1)의 x=1에서의 극한값은 2이며, x=1에서 정의되지 않아 그대로는 연속이 아니다.'}]}];
  return replan(s,today);
}
export function validateState(value:unknown):value is StudyState{try{return validStateShape(value);}catch{return false;}}
function validStateShape(value:unknown): value is StudyState {
  if(!value||typeof value!=='object')return false;const v=value as StudyState;
  if(v.version!==1||!v.profile||typeof v.onboarded!=='boolean'||typeof v.demo!=='boolean')return false;
  if(v.topicLab!==undefined){const t=v.topicLab;if(!t||typeof t!=='object'||typeof t.interest!=='string'||t.interest.length>300||typeof t.subject!=='string'||t.subject.length>40||typeof t.constraints!=='string'||t.constraints.length>400||typeof t.refinement!=='string'||t.refinement.length>300||!Number.isInteger(t.days)||t.days<1||t.days>180||!Array.isArray(t.ideas)||![0,3].includes(t.ideas.length)||!t.ideas.every(validTopicIdea)||typeof t.updatedAt!=='string')return false;}
  if(typeof v.profile.name!=='string'||v.profile.name.length>40||typeof v.profile.grade!=='string')return false;
  if(![v.profile.dailyMinutes,v.profile.weekendMinutes].every(n=>Number.isInteger(n)&&n>=0&&n<=720)||!Number.isInteger(v.profile.sessionMinutes)||v.profile.sessionMinutes<1||v.profile.sessionMinutes>720)return false;
  if(!Array.isArray(v.subjects)||v.subjects.length>30||!v.subjects.every(s=>s&&typeof s.id==='string'&&typeof s.name==='string'&&s.name.length>0&&s.name.length<=40&&/^#[\da-f]{6}$/i.test(s.color)&&(s.examDate===''||validDate(s.examDate))&&typeof s.scope==='string'&&typeof s.teacher==='string'&&Number.isInteger(s.minutes)&&s.minutes>=0&&s.minutes<=60000&&Number.isInteger(s.confidence)&&s.confidence>=1&&s.confidence<=5))return false;
  const ids=new Set(v.subjects.map(s=>s.id));if(ids.size!==v.subjects.length)return false;
  if(v.teacherProfiles!==undefined&&(!Array.isArray(v.teacherProfiles)||!v.teacherProfiles.every(p=>p&&typeof p.id==='string'&&ids.has(p.subjectId)&&typeof p.name==='string'&&p.name.trim().length>0&&p.name.length<=50&&Array.isArray(p.pastIds)&&Array.isArray(p.lessonIds)&&[...p.pastIds,...p.lessonIds].every(id=>typeof id==='string'&&id.length<=100)&&!p.pastIds.some(id=>p.lessonIds.includes(id)))||new Set(v.teacherProfiles.map(p=>p.id)).size!==v.teacherProfiles.length))return false;
  if(!Array.isArray(v.assessments)||v.assessments.length>500||!v.assessments.every(t=>t&&typeof t.id==='string'&&ids.has(t.subjectId)&&typeof t.title==='string'&&t.title.length>0&&validDate(t.due)&&Number.isInteger(t.minutes)&&t.minutes>0&&t.minutes<=60000&&typeof t.done==='boolean'&&typeof t.note==='string'&&(t.prepareBy===undefined||validDate(t.prepareBy)&&t.prepareBy<=t.due)))return false;
  if(!Array.isArray(v.sessions)||v.sessions.length>20000||!v.sessions.every(s=>s&&typeof s.id==='string'&&ids.has(s.subjectId)&&typeof s.sourceId==='string'&&['subject','task'].includes(s.kind)&&validDate(s.date)&&typeof s.title==='string'&&Number.isInteger(s.minutes)&&s.minutes>0&&s.minutes<=720&&typeof s.done==='boolean'))return false;
  if(!Array.isArray(v.materials)||v.materials.length>100||!v.materials.every(m=>m&&typeof m.id==='string'&&ids.has(m.subjectId)&&typeof m.name==='string'&&['lesson','exam'].includes(m.kind)&&Array.isArray(m.sections)&&m.sections.length<=500&&m.sections.every(p=>Number.isInteger(p.page)&&p.page>0&&typeof p.text==='string'&&p.text.length<=100000)))return false;
  if(v.chatThreads!==undefined&&(!Array.isArray(v.chatThreads)||v.chatThreads.length>1000||new Set(v.chatThreads.map(t=>t.id)).size!==v.chatThreads.length||!v.chatThreads.every(t=>t&&typeof t.id==='string'&&t.id.length<=100&&ids.has(t.subjectId)&&typeof t.title==='string'&&t.title.length>0&&t.title.length<=80&&typeof t.archived==='boolean'&&(t.taskId===undefined||typeof t.taskId==='string'&&t.taskId.length<=100))))return false;
  if(Array.isArray(v.answers)&&!v.answers.every(a=>a&&(a.chatId===undefined||(v.chatThreads||[]).some(t=>t.id===a.chatId&&t.subjectId===a.subjectId&&t.taskId===a.taskId))))return false;
  if(!Array.isArray(v.answers)||v.answers.length>10000||!v.answers.every(a=>a&&typeof a.text==='string'&&typeof a.question==='string'&&ids.has(a.subjectId)&&Array.isArray(a.citations)))return false;
  if(!Array.isArray(v.quizzes)||v.quizzes.length>100||!v.quizzes.every(q=>q&&typeof q.id==='string'&&ids.has(q.subjectId)&&typeof q.title==='string'&&typeof q.analysis==='string'&&typeof q.limitations==='string'&&Array.isArray(q.questions)&&q.questions.length<=20&&q.questions.every(p=>p&&typeof p.question==='string'&&typeof p.answer==='string'&&typeof p.explanation==='string'&&Array.isArray(p.citations))&&q.scores&&typeof q.scores==='object'))return false;
  const string=(value:unknown,max:number)=>typeof value==='string'&&value.length<=max;
  const citations=(values:unknown)=>Array.isArray(values)&&values.every(c=>c&&string(c.materialId,100)&&Number.isInteger(c.page)&&c.page>=1&&string(c.quote,500));
  const unique=(values:{id:string}[])=>new Set(values.map(v=>v.id)).size===values.length;
  if(![v.assessments,v.sessions,v.materials,v.quizzes].every(unique))return false;
  if(!v.assessments.every(t=>(t.requiresLaptop===undefined||typeof t.requiresLaptop==='boolean')&&(t.journal===undefined||string(t.journal,50000))&&(t.category===undefined||['assessment','research','other'].includes(t.category))&&(t.dueTime===undefined||/^([01]\d|2[0-3]):[0-5]\d$/.test(t.dueTime))&&(t.reminderMinutes===undefined||Number.isInteger(t.reminderMinutes)&&t.reminderMinutes>=-1&&t.reminderMinutes<=525600)&&(t.steps===undefined||Array.isArray(t.steps)&&t.steps.every(s=>s&&string(s.id,100)&&string(s.title,300)&&typeof s.done==='boolean'))&&(t.aiNotes===undefined||Array.isArray(t.aiNotes)&&t.aiNotes.every(n=>n&&string(n.id,100)&&string(n.title,2000)&&string(n.text,50000)&&string(n.createdAt,100)))&&(t.sources===undefined||Array.isArray(t.sources)&&t.sources.every(s=>s&&string(s.id,200)&&string(s.title,2000)&&typeof s.url==='string'&&/^https?:\/\/[^\s]+$/i.test(s.url)&&string(s.authors,2000)&&string(s.year,40)&&string(s.abstract,30000)&&string(s.provider,100)))))return false;
  if(!v.answers.every(a=>citations(a.citations))||!v.quizzes.every(q=>(q.analysisCitations===undefined||citations(q.analysisCitations))&&(q.patterns===undefined||Array.isArray(q.patterns)&&q.patterns.length<=4&&q.patterns.every(p=>p&&string(p.feature,2000)&&string(p.application,2000)&&citations(p.citations)))))return false;
  if(!v.quizzes.every(q=>!Array.isArray(q.scores)&&Object.entries(q.scores).every(([i,score])=>/^\d+$/.test(i)&&Number(i)<q.questions.length&&typeof score==='boolean')&&q.questions.every(p=>citations(p.citations))&&(q.attempts===undefined||q.attempts&&typeof q.attempts==='object'&&!Array.isArray(q.attempts)&&Object.entries(q.attempts).every(([i,a])=>/^\d+$/.test(i)&&Number(i)<q.questions.length&&a&&string(a.answer,10000)&&string(a.reflection,10000)))))return false;
  if(v.timetable!==undefined){const t=v.timetable;if(!t||(t.source!==undefined&&!['manual','comcigan','neis'].includes(t.source))||(t.weekStart!==undefined&&!validDate(t.weekStart))||(t.upstreamUpdatedAt!==undefined&&!string(t.upstreamUpdatedAt,100))||!string(t.school,60)||!Number.isInteger(t.grade)||t.grade<1||t.grade>3||!Number.isInteger(t.classNumber)||t.classNumber<1||t.classNumber>40||!string(t.updatedAt,100)||!Array.isArray(t.cells)||t.cells.length>60||!t.cells.every(c=>c&&Number.isInteger(c.day)&&c.day>=0&&c.day<5&&Number.isInteger(c.period)&&c.period>=1&&c.period<=12&&string(c.subject,40))||!Array.isArray(t.changes)||!t.changes.every(c=>c&&Number.isInteger(c.day)&&c.day>=0&&c.day<5&&Number.isInteger(c.period)&&c.period>=1&&c.period<=12&&string(c.before,40)&&string(c.after,40)))return false;}
  if(!v.sessions.every(s=>(s.startsAt===undefined||typeof s.startsAt==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:00\+09:00$/.test(s.startsAt)&&Number.isFinite(Date.parse(s.startsAt)))&&(s.availabilityLabel===undefined||typeof s.availabilityLabel==='string'&&s.availabilityLabel.length<=160)))return false; if(!validRoutineState(v))return false;
  if(v.availability!==undefined&&!validAvailability(v.availability))return false;
  return true;
}

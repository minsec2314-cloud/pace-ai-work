import type {Answer,StudyState} from './study.ts';
export function chatAnswers(state:StudyState,subjectId:string,taskId:string|undefined,chatId:string){return state.answers.filter(a=>a.subjectId===subjectId&&a.taskId===taskId&&(chatId==='legacy'?!a.chatId:a.chatId===chatId));}
export function chatHistory(answers:Answer[]){return answers.slice(-3).flatMap(a=>[{role:'user' as const,content:a.question},{role:'assistant' as const,content:a.text}]);}
export function appendChatAnswer(state:StudyState,answer:Answer):StudyState{if(state.answers.length>=10000)throw Error('대화 보관 한도입니다. 백업 후 정리해 주세요. 기존 대화를 자동 삭제하지 않습니다.');return {...state,answers:[...state.answers,answer]};}

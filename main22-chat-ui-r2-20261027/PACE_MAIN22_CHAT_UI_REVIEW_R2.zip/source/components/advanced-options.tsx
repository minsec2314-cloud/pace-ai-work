"use client";
import {useState,type ReactNode} from 'react';
export default function AdvancedOptions({title,children}:{title:string;children:ReactNode}){const [open,setOpen]=useState(false);return <details open={open} onToggle={e=>setOpen(e.currentTarget.open)} onInvalidCapture={()=>setOpen(true)}><summary>{title} · 자세히 설정</summary>{children}</details>;}

import UserGuide from '../../components/user-guide';
export default UserGuide;

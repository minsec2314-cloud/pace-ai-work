import type { Source } from './study.ts';
export function textOnly(input:unknown,max=4000){return typeof input==='string'?input.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').trim().slice(0,max):'';}
type CrossrefWork={DOI?:string;title?:string[];author?:{given?:string;family?:string}[];published?:{'date-parts'?:number[][]};abstract?:string;type?:string};
// A DOI suffix is an opaque identifier. Encode each path segment so ? and #
// remain part of that identifier rather than changing the resolver URL.
export function crossrefSources(works:CrossrefWork[]):Source[]{return works.filter(w=>w.DOI&&/^10\.\d{4,9}\//.test(w.DOI)&&w.title?.[0]).map(w=>({id:w.DOI!,title:textOnly(w.title![0],400),url:`https://doi.org/${w.DOI!.split('/').map(part=>encodeURIComponent(part)).join('/')}`,authors:(w.author||[]).slice(0,4).map(a=>[a.given,a.family].filter(Boolean).join(' ')).join(', ')||'저자 정보 없음',year:String(w.published?.['date-parts']?.[0]?.[0]||'연도 미확인'),abstract:textOnly(w.abstract),provider:'Crossref'}));}
export async function searchResearch(query:string,fetcher:typeof fetch=fetch):Promise<Source[]>{
 if(query.trim().length<2||query.length>200)throw new Error('검색어를 2~200자로 입력해 주세요.');
 const url=new URL('https://api.crossref.org/works');url.searchParams.set('query.bibliographic',query.trim());url.searchParams.set('rows','7');url.searchParams.set('select','DOI,title,author,published,abstract,type');
 const response=await fetcher(url,{headers:{'User-Agent':'PaceStudyResearch/1.0','Accept':'application/json'},signal:AbortSignal.timeout(20000)});
 if(!response.ok)throw new Error(response.status===429?'학술 검색 요청이 많습니다. 잠시 후 다시 시도해 주세요.':'학술 검색 서버에 연결하지 못했습니다.');
 const data=await response.json() as {message:{items:CrossrefWork[]}};return crossrefSources(data.message.items);
}

import test from 'node:test';
import assert from 'node:assert/strict';
import {crossrefSources} from '../lib/research.ts';

for(const doi of ['10.1234/plain','10.1234/a?b','10.1234/a#b','10.1234/a?b#c','10.1234/part/with spaces']){
 test(`DOI resolver preserves the full identifier: ${doi}`,()=>{
  const [source]=crossrefSources([{DOI:doi,title:['Synthetic study']}]);
  const url=new URL(source.url);
  assert.equal(url.origin,'https://doi.org');
  assert.equal(url.search,'');assert.equal(url.hash,'');
  assert.equal(decodeURIComponent(url.pathname.slice(1)),doi);
  assert.equal(source.id,doi);
 });
}

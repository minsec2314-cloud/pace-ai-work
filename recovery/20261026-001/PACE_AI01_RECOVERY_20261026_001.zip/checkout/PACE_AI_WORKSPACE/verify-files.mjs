import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const baseline=JSON.parse(fs.readFileSync(path.join(root,'BASELINE.json'),'utf8'));
let failed=0;
for(const item of [...baseline.files,...(baseline.handoffFiles||[])]){
  if(item.path.includes('..')||item.path.includes('\\')||path.isAbsolute(item.path))throw Error('Invalid manifest path');
  try{
    const bytes=fs.readFileSync(path.join(root,item.path));
    if(createHash('sha256').update(bytes).digest('hex')!==item.sha256){console.error('Changed:',item.path);failed++;}
  }catch{console.error('Missing:',item.path);failed++;}
}
console.log(JSON.stringify({bundleId:baseline.bundleId,sourceCommit:baseline.sourceCommit,files:baseline.files.length,failed}));
process.exitCode=failed?1:0;

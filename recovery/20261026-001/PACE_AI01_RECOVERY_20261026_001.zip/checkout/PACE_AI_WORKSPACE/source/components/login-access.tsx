import { LogIn, AlertCircle } from 'lucide-react';

export const SIGN_IN_URL='/signin-with-chatgpt?return_to=%2F';

// Keep the sign-in action available even if a rendered page has stale session
// information. Every protected API still checks the actual request's identity.
export function LoginLink({compact=false}:{compact?:boolean}) {
 return <a className={`login-action ${compact?'compact':''}`} href={SIGN_IN_URL} target="_top"><LogIn size={16}/><span>ChatGPT 로그인</span></a>;
}

export function AIErrorNotice({message}:{message:string}) {
 const needsLogin=message.includes('로그인');
 return <div className="notice error ai-error-action" role="alert"><AlertCircle size={17}/><div><p>{message}</p>{needsLogin&&<p className="login-help">ChatGPT 계정으로 이 사이트에 로그인해 주세요. Groq API 키를 다시 입력할 필요는 없어요.</p>}</div>{needsLogin&&<LoginLink/>}</div>;
}

"use client";
import { useEffect, useState } from "react";
import { Download, ArrowUpRight, PenLine, LoaderCircle } from "lucide-react";
import { createStudyBackup } from "../lib/ink-storage";
import type { InkBook } from "../lib/ink";
import type { StudyState } from "../lib/study";

export default function InkLibrary({ state }: { state: StudyState }) {
  const [books, setBooks] = useState<InkBook[]>([]),
    [loading, setLoading] = useState(true),
    [error, setError] = useState("");
  useEffect(() => {
    let cancelled = false;
    createStudyBackup(state)
      .then((backup) => {
        if (!cancelled)
          setBooks(
            (backup.handwriting || []).sort((a, b) =>
              b.updatedAt.localeCompare(a.updatedAt),
            ),
          );
      })
      .catch((e) => {
        if (!cancelled)
          setError(
            e instanceof Error ? e.message : "손글씨 목록을 읽지 못했습니다.",
          );
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);
  function download(book: InkBook) {
    const title =
      state.assessments.find((t) => t.id === book.taskId)?.title || book.title;
    const url = URL.createObjectURL(
        new Blob([JSON.stringify({ ...book, title })], {
          type: "application/json",
        }),
      ),
      a = document.createElement("a");
    a.href = url;
    a.download = `${title.replace(/[<>:"/\\|?*\u0000-\u001f]/g, " ").slice(0, 100) || "손글씨"}.pace-note.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  }
  return (
    <div className="ink-library">
      <h3>
        <PenLine size={16} />
        보관한 손글씨
      </h3>
      {loading ? (
        <p>
          <LoaderCircle size={14} className="spin" />
          목록을 불러오는 중
        </p>
      ) : error ? (
        <p role="alert">{error}</p>
      ) : !books.length ? (
        <p>활동에서 손글씨 노트를 쓰면 여기에 모여요.</p>
      ) : (
        <>
          <p>
            활동을 삭제해도 필기는 남겨 두었어요. 다른 활동의 ‘필기 노트
            불러오기’로 옮길 수 있습니다.
          </p>
          <ul>
            {books.map((book) => {
              const task = state.assessments.find((t) => t.id === book.taskId);
              return (
                <li key={book.id}>
                  <div>
                    <strong>{task?.title || book.title}</strong>
                    <small>
                      {book.pages.length}쪽 ·{" "}
                      {book.pages.reduce((n, p) => n + p.strokes.length, 0)}획
                      {!task ? " · 보관된 활동" : ""}
                    </small>
                  </div>
                  {task && (
                    <a
                      href={`?activity=${encodeURIComponent(book.taskId)}`}
                      className="ink-icon"
                      aria-label={`${task.title} 손글씨 열기`}
                      onClick={() => {
                        try {
                          localStorage.setItem("pace-note-mode", "ink");
                        } catch {}
                      }}
                    >
                      <ArrowUpRight size={17} />
                    </a>
                  )}
                  <button
                    className="ink-icon"
                    aria-label={`${task?.title || book.title} 필기 백업`}
                    onClick={() => download(book)}
                  >
                    <Download size={17} />
                  </button>
                </li>
              );
            })}
          </ul>
        </>
      )}
    </div>
  );
}

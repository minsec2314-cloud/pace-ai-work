import {AlertCircle,FileSearch} from 'lucide-react';
import {materialReadiness} from '../lib/material-readiness';
import type {Material} from '../lib/study';

export default function MaterialReadiness({materials,onOpen}:{materials:Material[];onOpen:(id:string,page:number)=>void}) {
 const problems=materials.map(material=>({material,...materialReadiness(material)})).filter(m=>m.rejected.length);
 if(!problems.length)return null;
 const readable=materials.reduce((n,m)=>n+materialReadiness(m).readable,0);
 return <section className="panel material-readiness" aria-label="자료 읽기 확인"><h2><AlertCircle size={19}/>{readable?'일부 쪽은 다시 읽어야 해요':'자료를 먼저 다시 읽어야 해요'}</h2><p>{readable?`현재 읽을 수 있는 ${readable}쪽만 문제 생성에 사용합니다. 깨진 쪽은 근거에서 제외돼요.`:'선택한 자료에 읽을 수 있는 쪽이 없어 문제를 만들 수 없습니다. 아래에서 원문을 열고 필요한 쪽을 복구해 주세요.'}</p>{problems.map(p=><article key={p.material.id}><div><strong>{p.material.name}</strong><p>전체 {p.total}쪽 중 사용 가능 {p.readable}쪽 · 다시 읽기 {p.rejected.length}쪽</p></div><button type="button" className="btn secondary small" onClick={()=>onOpen(p.material.id,p.rejected[0])}><FileSearch size={16}/>원문 열고 다시 읽기</button></article>)}<ol><li>원문 이미지가 보이면 ‘이 쪽 AI로 읽기’를 이용하거나 ‘직접 수정’을 누르세요.</li><li>원본의 수식·조건을 대조한 뒤 ‘확인한 텍스트 저장’을 누르세요.</li><li>이 화면으로 돌아오면 저장한 쪽을 문제 생성에 사용할 수 있습니다.</li></ol><p className="form-note">자료와 수정 내용은 지금 이용하는 브라우저에 저장됩니다. 다른 주소의 개발 화면이나 다른 기기와 자동 동기화되지 않아요. 문자 인식 결과는 검토가 필요합니다.</p></section>;
}

'use client';
import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Download, Printer, X } from 'lucide-react';
import FormattedText from './formatted-text';
import type { Citation, Material, Quiz } from '../lib/study';

export function QuizPaper({quiz,materials,answers=true,space=true}:{quiz:Quiz;materials:Material[];answers?:boolean;space?:boolean}) {
 const references=(items:Citation[])=>items.map((c,i)=><div className="paper-reference" key={i}><strong>{materials.find(m=>m.id===c.materialId)?.name||'참고 자료'} · {c.page}쪽</strong><FormattedText text={c.quote}/></div>);
 return <article className="quiz-paper">
  <header className="paper-heading"><p>PACE · 나의 학습 문제집</p><h1>{quiz.title}</h1><div><span>{quiz.mode==='exam'?'선생님 자료 기반 예상 문제':'자료 기반 연습 문제'}{quiz.teacherLabel?` · ${quiz.teacherLabel}`:''}</span><span>총 {quiz.questions.length}문제</span></div><p className="paper-name">이름 ____________________　　날짜 ____________________</p></header>
  <section aria-label="문제">{quiz.questions.map((q,i)=><section className="paper-question" key={i}><h2>{i+1}번 <small>{q.type}</small></h2><FormattedText text={q.question}/>{space&&<div className="paper-workspace" aria-label="풀이 공간"/>}</section>)}</section>
  {answers&&<section className="paper-solutions" aria-label="정답과 해설"><h2 className="paper-section-title">정답과 해설</h2>{quiz.questions.map((q,i)=><section className="paper-solution" key={i}><h3>{i+1}번</h3><div className="paper-answer"><strong>정답</strong><FormattedText text={q.answer}/></div><FormattedText text={q.explanation}/>{references(q.citations)}</section>)}{quiz.analysis&&<section className="paper-context"><h3>{quiz.mode==='exam'?'자료에서 관찰한 출제 특징':'학습 내용'}</h3><FormattedText text={quiz.analysis}/>{references(quiz.analysisCitations||[])}{quiz.patterns?.map((p,i)=><section key={i}><h4>관찰 {i+1}</h4><FormattedText text={p.feature}/><FormattedText text={p.application}/>{references(p.citations)}</section>)}</section>}</section>}
  <footer className="paper-footer"><p>AI가 만든 학습용 문제입니다. 실제 시험 출제를 보장하지 않으며, 정답과 해설은 원문과 함께 확인하세요.</p>{quiz.limitations&&<FormattedText text={quiz.limitations}/>}</footer>
 </article>;
}

export default function QuizPDF({quiz,materials}:{quiz:Quiz;materials:Material[]}) {
 const [open,setOpen]=useState(false),[answers,setAnswers]=useState(true),[space,setSpace]=useState(true),[busy,setBusy]=useState(false),[error,setError]=useState('');
 useEffect(()=>{
  if(!open)return;
  const previousTitle=document.title,previousOverflow=document.body.style.overflow;
  document.title=quiz.title.replace(/[<>:"/\\|?*\u0000-\u001f]/g,' ').slice(0,120)||'페이스 문제집';
  document.body.style.overflow='hidden';
  const escape=(e:KeyboardEvent)=>{if(e.key==='Escape')setOpen(false);};
  document.addEventListener('keydown',escape);
  return()=>{document.title=previousTitle;document.body.style.overflow=previousOverflow;document.removeEventListener('keydown',escape);};
 },[open,quiz.title]);
 async function save(){
  setBusy(true);setError('');
  try {
   await Promise.race([document.fonts.ready,new Promise((_,reject)=>setTimeout(()=>reject(new Error('글꼴 준비 시간이 초과됐어요. 잠시 후 다시 눌러 주세요.')),15000))]);
   await new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve())));
   window.print();
  }catch(e){setError(e instanceof Error?e.message:'PDF 저장 창을 열지 못했어요. 브라우저의 인쇄 메뉴를 이용해 주세요.');}
  finally{setBusy(false);}
 }
 return <><button className="text-btn" onClick={()=>setOpen(true)}><Download size={15}/>PDF 내려받기</button>{open&&createPortal(<div id="quiz-pdf-root" role="dialog" aria-modal="true" aria-label="문제집 PDF 미리보기">
  <div className="paper-toolbar"><div><strong>문제집 PDF</strong><p>저장 창의 대상을 ‘PDF로 저장’으로 선택하세요. A4 세로 · 배율 100%를 권장해요.</p></div><label><input type="checkbox" checked={answers} onChange={e=>setAnswers(e.target.checked)}/>정답 · 해설 포함</label><label><input type="checkbox" checked={space} onChange={e=>setSpace(e.target.checked)}/>풀이 공간</label><button className="btn" disabled={busy} onClick={()=>void save()}><Printer size={16}/>{busy?'글꼴 준비 중…':'PDF 저장 · 인쇄'}</button><button className="icon-btn" aria-label="PDF 미리보기 닫기" onClick={()=>setOpen(false)}><X size={20}/></button>{error&&<p role="alert">{error}</p>}</div>
  <QuizPaper quiz={quiz} materials={materials} answers={answers} space={space}/>
 </div>,document.body)}</>;
}

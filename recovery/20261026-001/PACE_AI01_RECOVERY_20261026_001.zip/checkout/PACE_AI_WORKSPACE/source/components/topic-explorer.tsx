'use client';
import {useState,type FormEvent} from 'react';
import {Sparkles,ArrowRight,LoaderCircle,Lightbulb,Check} from 'lucide-react';
import FormattedText from './formatted-text';
import type {TopicIdea,TopicLab} from '../lib/topics';
import type {StudyState} from '../lib/study';

export default function TopicExplorer({state,onChange,onChoose,status}:{state:StudyState;onChange:(lab:TopicLab)=>void;onChoose:(idea:TopicIdea,lab:TopicLab)=>void;status:boolean|null}){
 const lab=state.topicLab||{interest:'',subject:'융합 · 자유 탐구',constraints:'',days:14,refinement:'',ideas:[],updatedAt:''};
 const [consent,setConsent]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const change=(patch:Partial<TopicLab>)=>onChange({...lab,...patch});
 async function generate(e:FormEvent){e.preventDefault();if(busy||!consent||!lab.interest.trim())return;setBusy(true);setError('');
  try{const question=JSON.stringify({grade:state.profile.grade.slice(0,40),interest:lab.interest,subject:lab.subject,availableDays:lab.days,constraints:lab.constraints,additionalConditions:lab.refinement,previousIdeas:lab.ideas.map(i=>i.title.slice(0,80))});
   const r=await fetch('/api/ai',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:'topics',subject:lab.subject,question,materials:[]}),signal:AbortSignal.timeout(65000)});
   const data=await r.json() as {ideas?:TopicIdea[];error?:string};if(!r.ok||!data.ideas)throw new Error(data.error||'주제 후보를 만들지 못했습니다.');
   onChange({...lab,ideas:data.ideas,updatedAt:new Date().toISOString()});
  }catch(e){setError(e instanceof Error?e.message:'AI에 연결하지 못했습니다. 이전 후보는 그대로 남겨 두었어요.');}finally{setBusy(false);}
 }
 return <><div className="page-heading"><div><span className="eyebrow">FROM CURIOSITY TO A QUESTION</span><h1>무엇을 탐구할지부터, 함께.</h1><p>아직 제목이 없어도 괜찮아요. 작은 관심사에서 실행할 수 있는 질문을 찾아요.</p></div><span className="tag">활동 등록 전에도 시작</span></div>
 <div className="topic-layout"><form id="topic-exploration" className="panel topic-form" onSubmit={generate}><h2><Lightbulb size={19}/>나의 출발점</h2>
 <label className="field"><span>궁금한 것 · 관심 있는 것</span><textarea required maxLength={300} rows={3} value={lab.interest} onChange={e=>change({interest:e.target.value})} placeholder="예: 학교 교실마다 왜 소음이 다를까? 음악이 공부에 미치는 영향이 궁금해."/></label>
 <div className="topic-seeds">{['학교 생활 속 불편','환경과 에너지','수학으로 보는 일상','문학과 사회'].map(s=><button type="button" key={s} onClick={()=>change({interest:s})}>{s}</button>)}</div>
 <div className="form-grid"><label className="field"><span>연결하고 싶은 과목</span><select value={lab.subject} onChange={e=>change({subject:e.target.value})}>{Array.from(new Set(['융합 · 자유 탐구',...state.subjects.map(s=>s.name),'수학','물리학','화학','생명과학','지구과학','정보','국어','영어','사회','역사'])).map(s=><option key={s}>{s}</option>)}</select></label><label className="field"><span>활용 가능한 기간 (일)</span><input required type="number" min={1} max={180} value={lab.days} onChange={e=>change({days:Math.max(1,Math.min(180,Number(e.target.value)||1))})}/></label></div>
 <label className="field"><span>도구 · 비용 · 평가 기준 (선택)</span><textarea maxLength={400} rows={3} value={lab.constraints} onChange={e=>change({constraints:e.target.value})} placeholder="예: 휴대폰과 노트북 사용 가능, 실험실 사용 어려움, 비용 1만원 이내, 비교 실험이 필요함"/></label>
 <label className="checkbox-label"><input type="checkbox" checked={consent} onChange={e=>setConsent(e.target.checked)}/>입력한 관심사·조건·학년을 Groq AI에 보내는 데 동의해요.</label>
 <button className="btn full" type="submit" disabled={busy||!consent||!lab.interest.trim()||status===false}>{busy?<LoaderCircle size={17} className="spin"/>:<Sparkles size={17}/>} {busy?'실행할 수 있는 질문을 찾고 있어요…':lab.ideas.length?'조건에 맞게 다시 제안받기':'탐구 주제 3가지 찾아보기'}</button>
 <p className="form-note">활동과 일정은 후보를 고른 뒤 확인해서 등록해요. AI의 제안은 실제 자료 검색 결과가 아닙니다.</p>{error&&<p role="alert" className="danger-text">{error}</p>}</form>
 <section className="topic-results" aria-live="polite">{!lab.ideas.length?<div className="panel topic-welcome"><Sparkles size={30}/><h2>‘관심 있다’에서 ‘탐구한다’로.</h2><p>관심사 → 탐구 질문 → 방법 비교 → 주제 선택 → 일정과 노트</p><ol><li>아직 주제를 정하거나 활동을 만들 필요 없어요.</li><li>서로 다른 후보의 방법과 준비물을 비교해요.</li><li>마음에 드는 주제를 고르면 첫 할 일이 함께 만들어져요.</li></ol></div>:<><div className="section-heading"><div><h2>나에게 맞는 탐구 후보 3가지</h2><p>정답을 고르는 게 아니라, 내가 궁금한 질문을 골라요.</p></div><span className="tag">자동 저장됨</span></div>{lab.ideas.map((idea,i)=><article className="panel topic-card" key={i}><span className="eyebrow">IDEA {String(i+1).padStart(2,'0')}</span><h2>{idea.title}</h2><div className="topic-question"><FormattedText text={idea.question}/></div><FormattedText text={idea.why}/><details><summary>방법 · 준비물 · 첫 할 일 살펴보기</summary><h3>어떻게 알아볼까?</h3><FormattedText text={idea.method}/><h3>필요한 도구와 데이터</h3><FormattedText text={idea.supplies}/><h3>첫 세 걸음</h3><ul>{idea.firstSteps.map((s,j)=><li key={j}><Check size={14}/><FormattedText text={s}/></li>)}</ul><h3>미리 확인할 점</h3><FormattedText text={idea.cautions}/></details><button className="btn" type="button" onClick={()=>onChoose(idea,lab)}>이 주제로 탐구 시작하기<ArrowRight size={16}/></button></article>)}<div className="panel topic-refine"><h2>조금 더 나에게 맞게.</h2><label className="field"><span>추가하거나 바꾸고 싶은 조건</span><textarea maxLength={300} value={lab.refinement} onChange={e=>change({refinement:e.target.value})} placeholder="예: 실험 없이 공개 데이터만 쓰고 싶어. 2번 주제를 더 좁혀 줘."/></label><button className="btn secondary" form="topic-exploration" type="submit" disabled={busy||!consent}>이 조건으로 다시 탐색<Sparkles size={16}/></button></div></>}</section></div></>;
}

"use client";
import { useEffect, useState } from "react";
import { duration } from "../lib/study";

export default function MinutesInput({
  value,
  onChange,
  min = 0,
  max = 720,
  presets = [30, 60, 120, 180],
  label,
}: {
  value: number;
  onChange: (n: number) => void;
  min?: number;
  max?: number;
  presets?: number[];
  label: string;
}) {
  const [text, setText] = useState(String(value));
  useEffect(() => setText(String(value)), [value]);
  const valid =
    /^\d+$/.test(text) && Number(text) >= min && Number(text) <= max;
  return (
    <div className="minutes-input">
      <div className="minutes-entry">
        <input
          aria-label={label}
          required
          type="number"
          inputMode="numeric"
          min={min}
          max={max}
          step={1}
          value={text}
          onChange={(e) => {
            const next = e.target.value;
            setText(next);
            if (/^\d+$/.test(next)) {
              const n = Number(next);
              if (Number.isInteger(n) && n >= min && n <= max) onChange(n);
            }
          }}
          onBlur={() => {
            if (valid) setText(String(Number(text)));
          }}
        />
        <span>분</span>
        <small>{valid ? duration(Number(text)) : `${min}~${max}분 입력`}</small>
      </div>
      <div className="minutes-presets" aria-label={`${label} 빠른 선택`}>
        {presets
          .filter((n) => n >= min && n <= max)
          .map((n) => (
            <button
              type="button"
              key={n}
              aria-pressed={valid && Number(text) === n}
              onClick={() => {
                setText(String(n));
                onChange(n);
              }}
            >
              {duration(n)}
            </button>
          ))}
      </div>
    </div>
  );
}

'use client';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import katex from 'katex';
import { prepareMarkdown } from '../lib/format';

type HtmlNode={type?:string;tagName?:string;properties?:{className?:string[];[key:string]:unknown};children?:HtmlNode[];value?:string};
// CommonMark treats closing punctuation followed by a Korean particle as an
// emphasis boundary failure. Recover only balanced bold text left by the parser.
function koreanEmphasis(){return (tree:HtmlNode)=>{
 const visit=(node:HtmlNode)=>{if(!node.children)return;node.children=node.children.flatMap(child=>{
  if(child.type!=='text'||!child.value){visit(child);return [child];}
  const parts:HtmlNode[]=[];let offset=0;const pattern=/\*\*(\S(?:[^\n]*?\S)?)\*\*/g;
  for(const match of child.value.matchAll(pattern)){if(match.index!>offset)parts.push({type:'text',value:child.value.slice(offset,match.index)});parts.push({type:'strong',children:[{type:'text',value:match[1]}]});offset=match.index!+match[0].length;}
  if(!parts.length)return [child];if(offset<child.value.length)parts.push({type:'text',value:child.value.slice(offset)});return parts;
 });};visit(tree);
};}
function readableMathFailure(){return (tree:HtmlNode)=>{
 const plain=(node:HtmlNode):string=>node.value??node.children?.map(plain).join('')??'';
 const visit=(node:HtmlNode)=>{const classes=node.properties?.className||[];
 if(classes.some(c=>['language-math','math-inline','math-display'].includes(c))){
  try{katex.renderToString(plain(node),{throwOnError:true,strict:'ignore',trust:false,maxExpand:500,maxSize:20});}
  catch{node.tagName='span';node.properties={className:['math-unavailable'],role:'note'};node.children=[{type:'text',value:'수식을 표시하지 못했어요. 답변을 다시 요청하거나 원문을 확인해 주세요.'}];}
 }else node.children?.forEach(visit);};visit(tree);
};}
export default function FormattedText({text,className=''}:{text:string;className?:string}){
 return <div className={`formatted-text ${className}`}><Markdown skipHtml remarkPlugins={[remarkGfm,remarkMath,koreanEmphasis]} rehypePlugins={[readableMathFailure,[rehypeKatex,{strict:'ignore',trust:false,maxExpand:500,maxSize:20}]]} components={{
  a:({children,href})=><a href={href} target="_blank" rel="noopener noreferrer">{children}</a>,
  img:()=>null,
  table:({children})=><div className="markdown-table-scroll"><table>{children}</table></div>,
 }}>{prepareMarkdown(text||'')}</Markdown></div>;
}

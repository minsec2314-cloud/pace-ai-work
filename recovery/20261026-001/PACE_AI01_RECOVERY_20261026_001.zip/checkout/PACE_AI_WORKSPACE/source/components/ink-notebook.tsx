"use client";
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type PointerEvent as ReactPointerEvent,
} from "react";
import {
  PenLine,
  Highlighter,
  Eraser,
  Hand,
  Undo2,
  Redo2,
  Plus,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Download,
  Upload,
  FileImage,
  FileText,
  LoaderCircle,
  Check,
  AlertCircle,
  ZoomIn,
  ZoomOut,
  Trash2,
  RotateCcw,
  X,
} from "lucide-react";
import {
  newInkBook,
  newInkPage,
  inkId,
  validInkBook,
  normalizeInkPoint,
  eraseInk,
  eraseInkPath,
  zoomInk,
  constrainInkView,
  replaceInkPage,
  pointCount,
  PAPER_WIDTH,
  PAPER_HEIGHT,
  MAX_INK_PAGES,
  MAX_BOOK_POINTS,
  INK_COLORS,
  type InkBook,
  type InkPage,
  type InkPoint,
  type InkStroke,
  type InkView,
} from "../lib/ink";
import {
  loadInkBook,
  saveInkBook,
  InkConflictError,
  recordInkDraft,
  acknowledgeInkDraft,
  trackInkWrite,
  discardInkDraft,
} from "../lib/ink-storage";
import { paintPaper, paintStroke } from "../lib/ink-render";
import { getOriginal, storeOriginal } from "../lib/storage";
import { renderPDFPage } from "../lib/materials";
import type { Material } from "../lib/study";
import {
  inkPointerTool,
  inkPenContact,
  type InkInputTool,
} from "../lib/ink-input";

type Tool = InkInputTool;
type History = { before: InkPage; after: InkPage };
const filename = (s: string) =>
  s.replace(/[<>:"/\\|?*\u0000-\u001f]/g, " ").slice(0, 110) || "필기노트";
function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob),
    a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

export default function InkNotebook({
  taskId,
  title,
  materials,
}: {
  taskId: string;
  title: string;
  materials: Material[];
}) {
  const [book, setBook] = useState<InkBook | null>(null),
    [loading, setLoading] = useState(true),
    [saveStatus, setSaveStatus] = useState<"saved" | "saving" | "error">(
      "saved",
    ),
    [error, setError] = useState(""),
    [conflict, setConflict] = useState(false),
    [notice, setNotice] = useState("");
  const bookRef = useRef<InkBook | null>(null),
    revision = useRef(0),
    saveQueue = useRef(Promise.resolve()),
    blocked = useRef(false),
    alive = useRef(true);
  const [tool, setTool] = useState<Tool>("pen"),
    [buttonEraser, setButtonEraser] = useState(false),
    [color, setColor] = useState(INK_COLORS[0]),
    [penWidth, setPenWidth] = useState(3),
    [markerWidth, setMarkerWidth] = useState(22),
    [fingerInk, setFingerInk] = useState(false),
    [pressure, setPressure] = useState(true),
    [full, setFull] = useState(false),
    [historyTick, setHistoryTick] = useState(0),
    [confirmClear, setConfirmClear] = useState<
      "clear" | "delete" | "reload" | null
    >(null),
    [incoming, setIncoming] = useState<InkBook | null>(null);
  const histories = useRef(
      new Map<string, { undo: History[]; redo: History[] }>(),
    ),
    importInput = useRef<HTMLInputElement>(null),
    originalInput = useRef<HTMLInputElement>(null),
    confirmation = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    if (confirmClear || incoming) confirmation.current?.showModal();
  }, [confirmClear, incoming]);
  const viewport = useRef<HTMLDivElement>(null),
    paperCanvas = useRef<HTMLCanvasElement>(null),
    inkCanvas = useRef<HTMLCanvasElement>(null),
    previewCanvas = useRef<HTMLCanvasElement>(null),
    [size, setSize] = useState({ width: 0, height: 0 });
  const [view, setView] = useState<InkView>({ scale: 0.7, x: 28, y: 20 }),
    viewRef = useRef(view),
    fitDone = useRef(false),
    previousSize = useRef({ width: 0, height: 0 });
  const [background, setBackground] = useState<HTMLImageElement | null>(null),
    [backgroundBusy, setBackgroundBusy] = useState(false),
    [backgroundError, setBackgroundError] = useState(""),
    [backgroundReload, setBackgroundReload] = useState(0),
    [pdfMaterial, setPdfMaterial] = useState(""),
    [pdfPage, setPdfPage] = useState(1),
    [showPDF, setShowPDF] = useState(false);
  const active =
      book?.pages.find((p) => p.id === book.activePageId) || book?.pages[0],
    activeRef = useRef(active);
  activeRef.current = active;
  const draft = useRef<{
      id: number;
      pointerType: string;
      before: InkPage;
      stroke?: InkStroke;
      erased?: InkStroke[];
      lastErase?: InkPoint;
    } | null>(null),
    touches = useRef(new Map<number, { x: number; y: number }>()),
    gesture = useRef<{
      view: InkView;
      cx: number;
      cy: number;
      distance: number;
    } | null>(null),
    pan = useRef<{ id: number; x: number; y: number; view: InkView } | null>(
      null,
    ),
    lastPen = useRef(0),
    touchedGesture = useRef(false),
    frame = useRef<number | null>(null);
  const preferenceReady = useRef(false);
  useEffect(() => {
    try {
      const p = JSON.parse(
        localStorage.getItem("pace-ink-preferences") || "null",
      );
      if (p) {
        if (INK_COLORS.includes(p.color)) setColor(p.color);
        if (
          typeof p.penWidth === "number" &&
          p.penWidth >= 1 &&
          p.penWidth <= 10
        )
          setPenWidth(p.penWidth);
        if (
          typeof p.markerWidth === "number" &&
          p.markerWidth >= 10 &&
          p.markerWidth <= 44
        )
          setMarkerWidth(p.markerWidth);
        if (typeof p.fingerInk === "boolean") setFingerInk(p.fingerInk);
        if (typeof p.pressure === "boolean") setPressure(p.pressure);
      }
    } catch {}
    preferenceReady.current = true;
  }, []);
  useEffect(() => {
    if (!preferenceReady.current) return;
    try {
      localStorage.setItem(
        "pace-ink-preferences",
        JSON.stringify({ color, penWidth, markerWidth, fingerInk, pressure }),
      );
    } catch {}
  }, [color, penWidth, markerWidth, fingerInk, pressure]);
  const pdfs = materials.filter((m) => /\.pdf$/i.test(m.name));

  useEffect(() => {
    alive.current = true;
    let cancelled = false;
    loadInkBook(`activity:${taskId}`)
      .then((saved) => {
        if (cancelled) return;
        const next = saved || newInkBook(taskId, title);
        revision.current = next.revision;
        bookRef.current = next;
        setBook(next);
      })
      .catch((e) => {
        if (!cancelled) {
          setError(
            e instanceof Error ? e.message : "필기 노트를 읽지 못했습니다.",
          );
          blocked.current = true;
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
      alive.current = false;
    };
  }, [taskId]);
  const persist = useCallback((next: InkBook) => {
    if (!validInkBook(next)) {
      setError(
        "노트의 필기량이 한도에 도달했습니다. 백업 후 새 활동에 노트를 이어 써 주세요.",
      );
      return;
    }
    bookRef.current = next;
    setBook(next);
    recordInkDraft(next, revision.current);
    if (blocked.current) {
      setSaveStatus("error");
      return;
    }
    setSaveStatus("saving");
    saveQueue.current = saveQueue.current
      .then(async () => {
        if (blocked.current) return;
        const saved = await saveInkBook(next, revision.current);
        revision.current = saved.revision;
        acknowledgeInkDraft(next, saved.revision);
        if (alive.current && bookRef.current === next) setSaveStatus("saved");
      })
      .catch((e) => {
        blocked.current = true;
        if (alive.current) {
          setSaveStatus("error");
          setConflict(e instanceof InkConflictError);
          setError(
            e instanceof Error
              ? e.message
              : "기기에 저장하지 못했습니다. 현재 노트를 먼저 백업해 주세요.",
          );
        }
      });
    trackInkWrite(saveQueue.current);
  }, []);
  function selectTool(next: Tool) {
    finishDraft();
    if (
      next === "highlighter" &&
      tool !== "highlighter" &&
      color === INK_COLORS[0]
    )
      setColor(INK_COLORS[5]);
    else if (
      next === "pen" &&
      tool === "highlighter" &&
      color === INK_COLORS[5]
    )
      setColor(INK_COLORS[0]);
    setTool(next);
  }
  function historyFor(id: string) {
    let h = histories.current.get(id);
    if (!h) {
      h = { undo: [], redo: [] };
      histories.current.set(id, h);
    }
    return h;
  }
  function commitPage(next: InkPage, remember = true) {
    const current = bookRef.current,
      before = current?.pages.find((p) => p.id === next.id);
    if (!current || !before) return;
    if (remember) {
      const h = historyFor(next.id);
      h.undo.push({ before, after: next });
      if (h.undo.length > 60) h.undo.shift();
      h.redo = [];
      setHistoryTick((v) => v + 1);
    }
    persist(replaceInkPage(current, next));
  }
  function undo() {
    const current = bookRef.current;
    if (!current) return;
    const h = historyFor(current.activePageId),
      entry = h.undo.pop();
    if (!entry) return;
    h.redo.push(entry);
    persist(replaceInkPage(current, entry.before));
    setHistoryTick((v) => v + 1);
  }
  function redo() {
    const current = bookRef.current;
    if (!current) return;
    const h = historyFor(current.activePageId),
      entry = h.redo.pop();
    if (!entry) return;
    h.undo.push(entry);
    persist(replaceInkPage(current, entry.after));
    setHistoryTick((v) => v + 1);
  }
  function changeView(next: InkView) {
    const bounded = constrainInkView(next, size.width, size.height);
    viewRef.current = bounded;
    setView(bounded);
  }
  function fitPage(whole = false) {
    const scale = whole
      ? Math.min(
          (size.width - 36) / PAPER_WIDTH,
          (size.height - 36) / PAPER_HEIGHT,
        )
      : (size.width - 36) / PAPER_WIDTH;
    changeView({ scale: Math.max(0.15, Math.min(4, scale)), x: 18, y: 18 });
  }
  function changePage(id: string) {
    finishDraft();
    const current = bookRef.current;
    if (current) {
      persist({ ...current, activePageId: id });
      fitPage();
    }
  }
  function addPage() {
    finishDraft();
    const current = bookRef.current;
    if (!current) return;
    if (current.pages.length >= MAX_INK_PAGES) {
      setNotice(
        "한 노트에는 60쪽까지 저장할 수 있어요. 새 활동에 노트를 이어 써 주세요.",
      );
      return;
    }
    const page = newInkPage(current.pages.length + 1);
    persist({
      ...current,
      pages: [...current.pages, page],
      activePageId: page.id,
    });
    fitPage();
  }

  useEffect(() => {
    const el = viewport.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      const r = entries[0].contentRect;
      setSize({ width: r.width, height: r.height });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [loading]);
  useEffect(() => {
    if (!book || size.width <= 0 || size.height <= 0) return;
    const wasFitted =
      previousSize.current.width > 0 &&
      Math.abs(
        viewRef.current.scale -
          Math.max(
            0.15,
            Math.min(4, (previousSize.current.width - 36) / PAPER_WIDTH),
          ),
      ) < 0.01;
    previousSize.current = size;
    if (!fitDone.current || wasFitted) {
      fitDone.current = true;
      fitPage();
    } else changeView(viewRef.current);
  }, [size.width, size.height, Boolean(book)]);
  useEffect(() => {
    fitDone.current = false;
    if (!full) return;
    const old = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const escape = (e: KeyboardEvent) => {
      if (e.key === "Escape") setFull(false);
    };
    document.addEventListener("keydown", escape);
    return () => {
      document.body.style.overflow = old;
      document.removeEventListener("keydown", escape);
    };
  }, [full]);
  useEffect(() => {
    let cancelled = false;
    setBackground(null);
    setBackgroundError("");
    const source = active?.background;
    if (!source) {
      setBackgroundBusy(false);
      return;
    }
    setBackgroundBusy(true);
    getOriginal(source.materialId)
      .then(async (file) => {
        if (!file)
          throw new Error(
            "이 기기에 PDF 원본이 없습니다. 같은 PDF를 다시 연결하면 필기와 함께 볼 수 있어요.",
          );
        return renderPDFPage(file, source.page);
      })
      .then(
        (url) =>
          new Promise<HTMLImageElement>((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = () =>
              reject(new Error("PDF 이미지를 표시하지 못했습니다."));
            img.src = url;
          }),
      )
      .then((img) => {
        if (!cancelled) setBackground(img);
      })
      .catch((e) => {
        if (!cancelled)
          setBackgroundError(
            e instanceof Error ? e.message : "PDF를 열지 못했습니다.",
          );
      })
      .finally(() => {
        if (!cancelled) setBackgroundBusy(false);
      });
    return () => {
      cancelled = true;
    };
  }, [
    active?.background?.materialId,
    active?.background?.page,
    backgroundReload,
  ]);
  function context(canvas: HTMLCanvasElement | null) {
    if (!canvas) return null;
    const ratio = Math.min(2, window.devicePixelRatio || 1);
    if (
      canvas.width !== Math.round(PAPER_WIDTH * ratio) ||
      canvas.height !== Math.round(PAPER_HEIGHT * ratio)
    ) {
      canvas.width = Math.round(PAPER_WIDTH * ratio);
      canvas.height = Math.round(PAPER_HEIGHT * ratio);
    }
    const ctx = canvas.getContext("2d");
    ctx?.setTransform(
      canvas.width / PAPER_WIDTH,
      0,
      0,
      canvas.height / PAPER_HEIGHT,
      0,
      0,
    );
    return ctx;
  }
  function paintCommitted(strokes: InkStroke[]) {
    const ctx = context(inkCanvas.current);
    if (!ctx) return;
    ctx.clearRect(0, 0, PAPER_WIDTH, PAPER_HEIGHT);
    for (const s of strokes) paintStroke(ctx, s);
  }
  function clearPreview() {
    const ctx = context(previewCanvas.current);
    ctx?.clearRect(0, 0, PAPER_WIDTH, PAPER_HEIGHT);
  }
  useEffect(() => {
    if (!active) return;
    const ctx = context(paperCanvas.current);
    if (ctx) paintPaper(ctx, active, background || undefined);
  }, [active?.id, active?.paper, active?.background, background, loading]);
  useEffect(() => {
    if (active) {
      paintCommitted(active.strokes);
      clearPreview();
    }
  }, [active?.id, active?.strokes, loading]);
  function requestDraftPaint() {
    if (frame.current !== null) return;
    frame.current = requestAnimationFrame(() => {
      frame.current = null;
      const current = draft.current,
        ctx = context(previewCanvas.current);
      if (!ctx) return;
      ctx.clearRect(0, 0, PAPER_WIDTH, PAPER_HEIGHT);
      if (current?.stroke) paintStroke(ctx, current.stroke);
    });
  }
  useEffect(
    () => () => {
      if (frame.current !== null) cancelAnimationFrame(frame.current);
    },
    [],
  );
  function finishDraft(cancel = false) {
    const d = draft.current;
    draft.current = null;
    if (!d) return;
    clearPreview();
    if (cancel) {
      paintCommitted(d.before.strokes);
      return;
    }
    if (d.stroke?.points.length) {
      commitPage({ ...d.before, strokes: [...d.before.strokes, d.stroke] });
    } else if (d.erased && d.erased.length !== d.before.strokes.length) {
      commitPage({ ...d.before, strokes: d.erased });
    }
  }
  const finishRef = useRef(finishDraft);
  finishRef.current = finishDraft;
  useEffect(() => {
    const handler = () => {
      if (document.visibilityState === "hidden") finishRef.current();
    };
    document.addEventListener("visibilitychange", handler);
    return () => {
      document.removeEventListener("visibilitychange", handler);
      finishRef.current();
    };
  }, []);
  function local(e: { clientX: number; clientY: number }) {
    const r = viewport.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }
  function pagePoint(
    e: { clientX: number; clientY: number; pressure: number },
    fallback = 0.5,
  ) {
    const p = local(e),
      v = viewRef.current;
    return normalizeInkPoint(
      (p.x - v.x) / v.scale,
      (p.y - v.y) / v.scale,
      pressure ? e.pressure || fallback : 0.5,
    );
  }
  function beginPinch() {
    const a = [...touches.current.values()];
    if (a.length < 2) return;
    finishDraft(true);
    pan.current = null;
    touchedGesture.current = true;
    gesture.current = {
      view: { ...viewRef.current },
      cx: (a[0].x + a[1].x) / 2,
      cy: (a[0].y + a[1].y) / 2,
      distance: Math.max(1, Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y)),
    };
  }
  function pointerDown(e: ReactPointerEvent<HTMLDivElement>) {
    if (
      !activeRef.current ||
      !bookRef.current ||
      loading ||
      (e.pointerType === "mouse" && e.button !== 0)
    )
      return;
    e.preventDefault();
    e.currentTarget.focus({ preventScroll: true });
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {}
    const p = local(e);
    if (e.pointerType === "touch") {
      if (
        e.width > 36 ||
        e.height > 36 ||
        draft.current?.pointerType === "pen" ||
        Date.now() - lastPen.current < 300
      )
        return;
      touches.current.set(e.pointerId, p);
      if (touches.current.size >= 2) {
        beginPinch();
        return;
      }
      if (!fingerInk && tool !== "hand") return;
    }
    if (e.pointerType === "pen") {
      lastPen.current = Date.now();
      setButtonEraser(inkPointerTool("pen", e) === "eraser");
      if (draft.current?.pointerType === "touch") finishDraft(true);
      touches.current.clear();
      gesture.current = null;
      pan.current = null;
      if (!inkPenContact(e)) return;
    }
    if (inkPointerTool(tool, e) === "hand") {
      pan.current = {
        id: e.pointerId,
        x: p.x,
        y: p.y,
        view: { ...viewRef.current },
      };
      return;
    }
    if (draft.current || (e.pointerType === "touch" && touchedGesture.current))
      return;
    startPointerDraft(e);
  }
  function startPointerDraft(e: ReactPointerEvent<HTMLDivElement>) {
    if (!activeRef.current) return;
    try {
      if (!e.currentTarget.hasPointerCapture(e.pointerId))
        e.currentTarget.setPointerCapture(e.pointerId);
    } catch {}
    const p = local(e);
    const v = viewRef.current,
      x = (p.x - v.x) / v.scale,
      y = (p.y - v.y) / v.scale;
    if (x < 0 || x > PAPER_WIDTH || y < 0 || y > PAPER_HEIGHT) return;
    const erase = inkPointerTool(tool, e) === "eraser";
    const before = activeRef.current;
    if (erase) {
      const erased = eraseInk(before.strokes, x, y, 18 / viewRef.current.scale);
      draft.current = {
        id: e.pointerId,
        pointerType: e.pointerType,
        before,
        erased,
        lastErase: pagePoint(e),
      };
      paintCommitted(erased);
    } else {
      draft.current = {
        id: e.pointerId,
        pointerType: e.pointerType,
        before,
        stroke: {
          id: inkId(),
          tool: tool === "highlighter" ? "highlighter" : "pen",
          color,
          width: tool === "highlighter" ? markerWidth : penWidth,
          points: [pagePoint(e)],
        },
      };
      requestDraftPaint();
    }
  }
  function pointerMove(e: ReactPointerEvent<HTMLDivElement>) {
    if (e.pointerType === "pen") {
      lastPen.current = Date.now();
      setButtonEraser(inkPointerTool("pen", e) === "eraser");
      if (!inkPenContact(e)) {
        if (draft.current?.id === e.pointerId) finishDraft();
        if (pan.current?.id === e.pointerId) pan.current = null;
        return;
      }
      const effective = inkPointerTool(tool, e);
      const current = draft.current;
      if (
        current?.id === e.pointerId &&
        (current.erased ? "eraser" : current.stroke?.tool) !== effective
      )
        finishDraft();
      if (pan.current?.id === e.pointerId && effective !== "hand")
        pan.current = null;
      if (!draft.current && !pan.current) {
        if (effective === "hand") {
          const p = local(e);
          pan.current = {
            id: e.pointerId,
            x: p.x,
            y: p.y,
            view: { ...viewRef.current },
          };
        } else startPointerDraft(e);
        return;
      }
    }
    if (e.pointerType === "touch") {
      if (!touches.current.has(e.pointerId)) return;
      touches.current.set(e.pointerId, local(e));
      if (
        draft.current?.pointerType === "pen" ||
        Date.now() - lastPen.current < 300
      )
        return;
      if (touches.current.size >= 2) {
        const a = [...touches.current.values()],
          g = gesture.current;
        if (!g) {
          beginPinch();
          return;
        }
        const cx = (a[0].x + a[1].x) / 2,
          cy = (a[0].y + a[1].y) / 2,
          dist = Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y),
          scaled = zoomInk(
            g.view,
            (g.view.scale * dist) / g.distance,
            g.cx,
            g.cy,
          );
        changeView({
          ...scaled,
          x: scaled.x + cx - g.cx,
          y: scaled.y + cy - g.cy,
        });
        return;
      }
    }
    const drag = pan.current;
    if (drag?.id === e.pointerId) {
      const p = local(e);
      changeView({
        ...drag.view,
        x: drag.view.x + p.x - drag.x,
        y: drag.view.y + p.y - drag.y,
      });
      return;
    }
    const d = draft.current;
    if (!d || d.id !== e.pointerId) return;
    if (d.erased) {
      const p = pagePoint(e);
      const next = eraseInkPath(
        d.erased,
        d.lastErase || p,
        p,
        18 / viewRef.current.scale,
      );
      d.lastErase = p;
      if (next.length !== d.erased.length) {
        d.erased = next;
        paintCommitted(next);
      }
      return;
    }
    if (!d.stroke) return;
    const native = e.nativeEvent,
      samples = native.getCoalescedEvents?.() || [],
      events = samples.length ? samples : [native];
    for (const sample of events) {
      const last = d.stroke.points.at(-1)!,
        next = pagePoint(sample, last[2]);
      if (
        Math.hypot(next[0] - last[0], next[1] - last[1]) > 0.25 ||
        Math.abs(next[2] - last[2]) > 0.05
      )
        d.stroke.points.push(next);
      if (d.stroke.points.length >= 15990) {
        finishDraft();
        setNotice("긴 획을 저장했습니다. 펜을 떼고 이어서 써 주세요.");
        break;
      }
    }
    requestDraftPaint();
  }
  function pointerEnd(e: ReactPointerEvent<HTMLDivElement>) {
    if (draft.current?.id === e.pointerId) {
      if (e.type === "pointerup" && e.pointerType !== "pen") pointerMove(e);
      finishDraft();
    }
    if (pan.current?.id === e.pointerId) pan.current = null;
    if (e.pointerType === "touch") {
      touches.current.delete(e.pointerId);
      if (touches.current.size < 2) gesture.current = null;
      if (!touches.current.size) touchedGesture.current = false;
    }
    if (e.pointerType === "pen") {
      lastPen.current = Date.now();
      setButtonEraser(false);
    }
    try {
      if (e.currentTarget.hasPointerCapture(e.pointerId))
        e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {}
  }
  useEffect(() => {
    const el = viewport.current;
    if (!el) return;
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      const r = el.getBoundingClientRect(),
        v = viewRef.current;
      if (e.ctrlKey || e.metaKey) {
        const next = zoomInk(
          v,
          v.scale * Math.exp(-e.deltaY * 0.005),
          e.clientX - r.left,
          e.clientY - r.top,
        );
        const bounded = constrainInkView(next, el.clientWidth, el.clientHeight);
        viewRef.current = bounded;
        setView(bounded);
      } else {
        const next = constrainInkView(
          { ...v, x: v.x - e.deltaX, y: v.y - e.deltaY },
          el.clientWidth,
          el.clientHeight,
        );
        viewRef.current = next;
        setView(next);
      }
    };
    el.addEventListener("wheel", wheel, { passive: false });
    return () => el.removeEventListener("wheel", wheel);
  }, [loading]);
  function exportNotebook() {
    finishDraft();
    const current = bookRef.current;
    if (current)
      downloadBlob(
        new Blob(
          [JSON.stringify({ ...current, revision: revision.current, title })],
          { type: "application/json" },
        ),
        `${filename(title)}.pace-note.json`,
      );
  }
  async function exportPNG() {
    finishDraft();
    if (!active) return;
    const current =
      bookRef.current?.pages.find((p) => p.id === active.id) || active;
    const canvas = document.createElement("canvas");
    canvas.width = PAPER_WIDTH * 2;
    canvas.height = PAPER_HEIGHT * 2;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(2, 2);
    paintPaper(ctx, current, background || undefined);
    for (const s of current.strokes) paintStroke(ctx, s);
    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, "image/png"),
    );
    if (!blob) {
      setNotice("이미지로 내보내지 못했습니다. 노트 백업을 이용해 주세요.");
      return;
    }
    downloadBlob(blob, `${filename(title)}_${filename(current.name)}.png`);
    if (current.background && !background)
      setNotice("PDF 원본을 불러오지 못해 필기선만 이미지로 내보냈습니다.");
  }
  async function importNotebook(file?: File) {
    if (!file) return;
    try {
      if (file.size > 35 * 1024 * 1024)
        throw new Error("노트 백업은 35MB 이하만 읽을 수 있어요.");
      const value: unknown = JSON.parse(await file.text());
      if (!validInkBook(value))
        throw new Error(
          "페이스 손글씨 노트 백업 형식이 아닙니다. 기존 노트는 바꾸지 않았습니다.",
        );
      setIncoming(value);
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "백업을 읽지 못했습니다.");
    }
    if (importInput.current) importInput.current.value = "";
  }
  async function reloadStoredNotebook() {
    try {
      const saved =
        (await loadInkBook(`activity:${taskId}`, true)) ||
        newInkBook(taskId, title);
      discardInkDraft(saved.id);
      blocked.current = false;
      revision.current = saved.revision;
      bookRef.current = saved;
      histories.current.clear();
      setBook(saved);
      setConflict(false);
      setError("");
      setSaveStatus("saved");
      setConfirmClear(null);
      setHistoryTick((v) => v + 1);
      fitPage();
    } catch (e) {
      setConfirmClear(null);
      setNotice(
        e instanceof Error
          ? e.message
          : "저장본을 읽지 못했습니다. 현재 필기는 유지했습니다.",
      );
    }
  }
  function attachPDF() {
    const m = pdfs.find((m) => m.id === pdfMaterial),
      current = activeRef.current;
    if (
      !m ||
      !current ||
      pdfPage < 1 ||
      !m.sections.some((s) => s.page === pdfPage)
    )
      return;
    commitPage({
      ...current,
      background: { materialId: m.id, page: pdfPage, name: m.name },
    });
    setShowPDF(false);
  }
  async function reconnectPDF(file?: File) {
    const source = activeRef.current?.background;
    if (!file || !source) return;
    try {
      const material = materials.find((m) => m.id === source.materialId);
      if (
        !/\.pdf$/i.test(file.name) ||
        file.size > 20 * 1024 * 1024 ||
        (material && material.size > 0 && file.size !== material.size)
      )
        throw new Error(
          "처음 사용한 것과 같은 20MB 이하의 PDF 원본을 선택해 주세요.",
        );
      await renderPDFPage(file, source.page);
      await storeOriginal(source.materialId, file);
      setBackgroundReload((n) => n + 1);
      setNotice("PDF 원본을 다시 연결했습니다.");
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "원본을 연결하지 못했습니다.");
    }
    if (originalInput.current) originalInput.current.value = "";
  }
  function removePage() {
    if (!book || !active) return;
    if (confirmClear === "clear") commitPage({ ...active, strokes: [] });
    else if (book.pages.length > 1) {
      const pages = book.pages.filter((p) => p.id !== active.id);
      persist({ ...book, pages, activePageId: pages[0].id });
      fitPage();
    }
    setConfirmClear(null);
  }

  if (loading)
    return (
      <section className="panel ink-loading">
        <LoaderCircle className="spin" size={20} />
        손글씨 노트를 불러오는 중
      </section>
    );
  if (!book || !active)
    return (
      <section className="panel ink-error">
        <AlertCircle />
        <p>{error || "노트를 열지 못했습니다."}</p>
        <button
          className="btn secondary"
          onClick={() => window.location.reload()}
        >
          새로고침
        </button>
      </section>
    );
  const index = book.pages.findIndex((p) => p.id === active.id),
    history = historyFor(active.id);
  const usedPoints = pointCount(book);
  void historyTick;
  return (
    <section
      className={`ink-notebook ${full ? "ink-fullscreen" : ""}`}
      aria-label={`${title} 손글씨 노트`}
      onKeyDown={(e) => {
        if (
          (e.target as HTMLElement).closest(
            "input,textarea,select,[contenteditable=true]",
          )
        )
          return;
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
          e.preventDefault();
          e.shiftKey ? redo() : undo();
        } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") {
          e.preventDefault();
          redo();
        } else if (!e.ctrlKey && !e.metaKey && !e.altKey) {
          const shortcut = {
            p: "pen",
            e: "eraser",
            h: "highlighter",
            v: "hand",
          }[e.key.toLowerCase()] as Tool | undefined;
          if (shortcut) selectTool(shortcut);
        }
      }}
    >
      <div className="ink-heading">
        <div>
          <span className="ink-eyebrow">나의 생각을 자유롭게</span>
          <h2>손글씨 노트</h2>
        </div>
        <div className="ink-save" role="status">
          {buttonEraser ? (
            <>
              <Eraser size={14} />
              버튼 지우개
            </>
          ) : saveStatus === "saving" ? (
            <>
              <LoaderCircle size={14} className="spin" />
              저장 중
            </>
          ) : saveStatus === "error" ? (
            <>
              <AlertCircle size={14} />
              저장 확인 필요
            </>
          ) : (
            <>
              <Check size={14} />이 기기에 저장됨
            </>
          )}
        </div>
        <button
          className="ink-icon"
          title={full ? "전체 화면 닫기" : "필기에 집중하기"}
          aria-label={full ? "필기 전체 화면 닫기" : "필기 전체 화면 열기"}
          onClick={() => setFull((v) => !v)}
        >
          {full ? <Minimize2 size={19} /> : <Maximize2 size={19} />}
        </button>
      </div>
      <div className="ink-toolbar" role="toolbar" aria-label="필기 도구">
        <div className="ink-tool-group">
          {(
            [
              { key: "pen", label: "펜", icon: PenLine },
              { key: "highlighter", label: "형광펜", icon: Highlighter },
              { key: "eraser", label: "획 지우개", icon: Eraser },
              { key: "hand", label: "이동", icon: Hand },
            ] as const
          ).map((t) => (
            <button
              key={t.key}
              className={`ink-tool ${(buttonEraser ? "eraser" : tool) === t.key ? "selected" : ""}`}
              aria-label={t.label}
              aria-pressed={(buttonEraser ? "eraser" : tool) === t.key}
              onClick={() => selectTool(t.key)}
            >
              <t.icon size={19} />
              <span>{t.label}</span>
            </button>
          ))}
        </div>
        <div className="ink-tool-group ink-colors" aria-label="펜 색상">
          {INK_COLORS.map((c, i) => (
            <button
              key={c}
              className={color === c ? "selected" : ""}
              style={{ "--ink-color": c } as React.CSSProperties}
              aria-label={`펜 색 ${["검정", "보라", "파랑", "초록", "빨강", "노랑"][i]}`}
              aria-pressed={color === c}
              onClick={() => setColor(c)}
            >
              <span />
              {color === c && <Check size={12} />}
            </button>
          ))}
        </div>
        <label className="ink-width">
          굵기
          <input
            aria-label="필기 굵기"
            type="range"
            min={tool === "highlighter" ? 10 : 1}
            max={tool === "highlighter" ? 44 : 10}
            step={tool === "highlighter" ? 2 : 0.5}
            value={tool === "highlighter" ? markerWidth : penWidth}
            onChange={(e) =>
              tool === "highlighter"
                ? setMarkerWidth(Number(e.target.value))
                : setPenWidth(Number(e.target.value))
            }
          />
          <span>{tool === "highlighter" ? markerWidth : penWidth}</span>
        </label>
        <div className="ink-tool-group">
          <button
            className="ink-icon"
            aria-label="필기 실행 취소"
            disabled={!history.undo.length}
            onClick={undo}
          >
            <Undo2 size={19} />
          </button>
          <button
            className="ink-icon"
            aria-label="필기 다시 실행"
            disabled={!history.redo.length}
            onClick={redo}
          >
            <Redo2 size={19} />
          </button>
        </div>
      </div>
      <div className="ink-options">
        <label>
          <input
            type="checkbox"
            checked={fingerInk}
            onChange={(e) => {
              finishDraft();
              setFingerInk(e.target.checked);
            }}
          />
          손가락으로도 쓰기
        </label>
        <label>
          <input
            type="checkbox"
            checked={pressure}
            onChange={(e) => setPressure(e.target.checked)}
          />
          필압 반영
        </label>
        <span>
          {fingerInk
            ? "한 손가락 필기 · 두 손가락 이동/확대"
            : "펜·마우스로 필기 · 두 손가락 이동/확대"}
        </span>
        <div className="ink-zoom">
          <button
            className="ink-icon"
            aria-label="필기 축소"
            onClick={() =>
              changeView(
                zoomInk(
                  viewRef.current,
                  viewRef.current.scale / 1.25,
                  size.width / 2,
                  size.height / 2,
                ),
              )
            }
          >
            <ZoomOut size={17} />
          </button>
          <span>
            {Math.round(
              (view.scale / Math.max(0.15, (size.width - 36) / PAPER_WIDTH)) *
                100,
            )}
            %
          </span>
          <button
            className="ink-icon"
            aria-label="필기 확대"
            onClick={() =>
              changeView(
                zoomInk(
                  viewRef.current,
                  viewRef.current.scale * 1.25,
                  size.width / 2,
                  size.height / 2,
                ),
              )
            }
          >
            <ZoomIn size={17} />
          </button>
          <button className="ink-text-button" onClick={() => fitPage()}>
            너비 맞춤
          </button>
          <button className="ink-text-button" onClick={() => fitPage(true)}>
            한 쪽 보기
          </button>
        </div>
      </div>
      {error && (
        <div className="ink-warning" role="alert">
          <AlertCircle size={17} />
          <span>{error}</span>
          <button className="ink-text-button" onClick={exportNotebook}>
            현재 노트 백업
          </button>
          {conflict && (
            <button
              className="ink-text-button"
              onClick={() => setConfirmClear("reload")}
            >
              저장본 다시 열기
            </button>
          )}
          {!conflict && (
            <button
              className="ink-text-button"
              onClick={() => {
                blocked.current = false;
                setError("");
                persist(bookRef.current!);
              }}
            >
              다시 저장
            </button>
          )}
        </div>
      )}
      {notice && (
        <div className="ink-warning" role="status">
          <span>{notice}</span>
          <button
            className="ink-icon"
            aria-label="필기 안내 닫기"
            onClick={() => setNotice("")}
          >
            <X size={15} />
          </button>
        </div>
      )}
      <div className="ink-workspace">
        <aside className="ink-pages" aria-label="노트 페이지">
          {book.pages.map((p, i) => (
            <button
              className={p.id === active.id ? "selected" : ""}
              key={p.id}
              aria-label={`${i + 1}쪽 ${p.name}`}
              aria-current={p.id === active.id ? "page" : undefined}
              onClick={() => changePage(p.id)}
            >
              <span className={`ink-page-mini ${p.paper}`}>
                {p.background ? <FileText size={21} /> : <PenLine size={20} />}
                <small>{p.strokes.length ? "필기 있음" : "빈 페이지"}</small>
              </span>
              <span>{p.name}</span>
            </button>
          ))}
          <button className="ink-add-page" onClick={addPage}>
            <Plus size={18} />새 페이지
          </button>
        </aside>
        <div
          className="ink-stage"
          ref={viewport}
          tabIndex={0}
          role="application"
          aria-label="손글씨 필기 영역. 펜으로 쓰거나 두 손가락으로 이동하세요."
          onPointerDown={pointerDown}
          onPointerMove={pointerMove}
          onPointerUp={pointerEnd}
          onPointerCancel={pointerEnd}
          onPointerLeave={(e) => {
            if (
              e.pointerType === "pen" &&
              !e.currentTarget.hasPointerCapture(e.pointerId)
            )
              setButtonEraser(false);
          }}
          onLostPointerCapture={pointerEnd}
          onContextMenu={(e) => e.preventDefault()}
        >
          <div
            className="ink-paper"
            style={{
              width: PAPER_WIDTH,
              height: PAPER_HEIGHT,
              transform: `translate(${view.x}px,${view.y}px) scale(${view.scale})`,
            }}
          >
            <canvas ref={paperCanvas} aria-hidden="true" />
            <canvas ref={inkCanvas} aria-hidden="true" />
            <canvas ref={previewCanvas} aria-hidden="true" />
          </div>
          {backgroundBusy && (
            <div className="ink-stage-status">
              <LoaderCircle size={18} className="spin" />
              PDF 원문을 여는 중
            </div>
          )}
        </div>
      </div>
      <div className="ink-page-controls">
        <button
          className="ink-icon"
          aria-label="이전 필기 페이지"
          disabled={index === 0}
          onClick={() => changePage(book.pages[index - 1].id)}
        >
          <ChevronLeft size={18} />
        </button>
        <label>
          쪽 이름
          <input
            aria-label="필기 쪽 이름"
            value={active.name}
            maxLength={120}
            onChange={(e) =>
              commitPage({ ...active, name: e.target.value }, false)
            }
          />
        </label>
        <span>
          {index + 1} / {book.pages.length}쪽 · {active.strokes.length}획
        </span>
        <button
          className="ink-icon"
          aria-label="다음 필기 페이지"
          disabled={index === book.pages.length - 1}
          onClick={() => changePage(book.pages[index + 1].id)}
        >
          <ChevronRight size={18} />
        </button>
        <label className="ink-paper-select">
          용지
          <select
            aria-label="필기 용지"
            value={active.paper}
            disabled={Boolean(active.background)}
            onChange={(e) =>
              commitPage({
                ...active,
                paper: e.target.value as InkPage["paper"],
              })
            }
          >
            <option value="lined">줄 노트</option>
            <option value="grid">모눈</option>
            <option value="dots">점선 노트</option>
            <option value="blank">무지</option>
          </select>
        </label>
        <button
          className="ink-text-button"
          onClick={() => setShowPDF((v) => !v)}
        >
          <FileText size={15} />
          PDF 위에 필기
        </button>
        <button
          className="ink-icon"
          aria-label="현재 쪽 필기 지우기"
          disabled={!active.strokes.length}
          onClick={() => setConfirmClear("clear")}
        >
          <RotateCcw size={17} />
        </button>
        <button
          className="ink-icon"
          aria-label="현재 필기 페이지 삭제"
          disabled={book.pages.length === 1}
          onClick={() => setConfirmClear("delete")}
        >
          <Trash2 size={17} />
        </button>
      </div>
      {showPDF && (
        <div className="ink-pdf-picker">
          <label>
            배경 PDF
            <select
              aria-label="필기 배경 PDF"
              value={pdfMaterial}
              onChange={(e) => {
                setPdfMaterial(e.target.value);
                setPdfPage(1);
              }}
            >
              <option value="">자료에서 고르기</option>
              {pdfs.map((m) => (
                <option value={m.id} key={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            쪽
            <select
              aria-label="필기 배경 PDF 쪽"
              value={pdfPage}
              onChange={(e) => setPdfPage(Number(e.target.value))}
            >
              {(pdfs.find((m) => m.id === pdfMaterial)?.sections || []).map(
                (s) => (
                  <option value={s.page} key={s.page}>
                    {s.page}쪽
                  </option>
                ),
              )}
            </select>
          </label>
          <button
            className="btn secondary"
            disabled={!pdfMaterial}
            onClick={attachPDF}
          >
            이 쪽을 배경으로
          </button>
          {active.background && (
            <button
              className="ink-text-button"
              onClick={() => {
                const { background: _, ...page } = active;
                commitPage(page);
                setShowPDF(false);
              }}
            >
              PDF 배경 빼기
            </button>
          )}
          {!pdfs.length && (
            <p>이 과목의 PDF를 자료실에 추가하면 배경으로 고를 수 있어요.</p>
          )}
          <p>
            원본은 바꾸지 않고 필기를 따로 저장합니다. 기존 필기 위치는
            유지돼요.
          </p>
        </div>
      )}
      {active.background && (
        <div
          className={`ink-background-note ${backgroundError ? "has-error" : ""}`}
        >
          <FileText size={15} />
          <span>
            {active.background.name} · {active.background.page}쪽
            {backgroundError && ` — ${backgroundError}`}
          </span>
          {backgroundError && (
            <button
              className="ink-text-button"
              onClick={() => originalInput.current?.click()}
            >
              PDF 다시 연결
            </button>
          )}
        </div>
      )}
      <div className="ink-export">
        <button
          className="ink-text-button"
          onClick={() => void exportPNG()}
          disabled={backgroundBusy}
        >
          <FileImage size={16} />
          현재 쪽 PNG
        </button>
        <button className="ink-text-button" onClick={exportNotebook}>
          <Download size={16} />
          필기 노트 백업
        </button>
        <button
          className="ink-text-button"
          onClick={() => importInput.current?.click()}
        >
          <Upload size={16} />
          필기 노트 불러오기
        </button>
        <span>
          {usedPoints > MAX_BOOK_POINTS * 0.8 &&
            "필기량이 많아요. 백업 후 새 활동에 이어 써 주세요. · "}
          이 브라우저에 자동 저장 · 다른 기기는 백업 파일로 옮겨 주세요. S펜
          버튼을 누르는 동안만 획 지우개로 바뀝니다. 손글씨의 AI 문자 인식은
          지원하지 않아요.
        </span>
        <input
          type="file"
          accept=".json"
          hidden
          ref={importInput}
          onChange={(e) => void importNotebook(e.target.files?.[0])}
        />
        <input
          type="file"
          accept=".pdf"
          hidden
          ref={originalInput}
          onChange={(e) => void reconnectPDF(e.target.files?.[0])}
        />
      </div>
      {(confirmClear || incoming) && (
        <dialog
          ref={confirmation}
          className="ink-confirm"
          role="alertdialog"
          aria-modal="true"
          aria-label={
            incoming
              ? "필기 노트 불러오기 확인"
              : confirmClear === "reload"
                ? "필기 저장본 복구 확인"
                : "필기 지우기 확인"
          }
          onKeyDown={(e) => e.stopPropagation()}
          onCancel={() => {
            setConfirmClear(null);
            setIncoming(null);
          }}
        >
          <div>
            <h3>
              {incoming
                ? "이 활동의 손글씨 노트를 바꿀까요?"
                : confirmClear === "clear"
                  ? "현재 쪽의 필기를 지울까요?"
                  : confirmClear === "reload"
                    ? "다른 창에서 저장한 노트를 다시 열까요?"
                    : "이 필기 페이지를 삭제할까요?"}
            </h3>
            <p>
              {incoming
                ? `${incoming.pages.length}쪽의 노트로 바꿉니다. 지금 노트가 필요하면 먼저 백업해 주세요. PDF 원본은 백업에 포함되지 않습니다.`
                : confirmClear === "clear"
                  ? "배경은 유지합니다. 실행 취소로 되돌릴 수 있어요."
                  : confirmClear === "reload"
                    ? "현재 창에서 저장하지 못한 수정은 바뀝니다. 필요한 필기는 먼저 ‘현재 노트 백업’ 파일로 보관해 주세요."
                    : "이 쪽의 필기가 함께 삭제됩니다. 필요한 내용은 먼저 백업해 주세요."}
            </p>
            <div>
              <button
                className="btn secondary"
                onClick={() => {
                  setConfirmClear(null);
                  setIncoming(null);
                }}
              >
                취소
              </button>
              <button
                className="btn"
                onClick={() => {
                  if (incoming && bookRef.current) {
                    const next = {
                      ...incoming,
                      id: bookRef.current.id,
                      taskId,
                      revision: revision.current,
                      title,
                    };
                    histories.current.clear();
                    persist(next);
                    setHistoryTick((v) => v + 1);
                    setIncoming(null);
                    fitPage();
                  } else if (confirmClear === "reload")
                    void reloadStoredNotebook();
                  else removePage();
                }}
              >
                {incoming
                  ? "노트 불러오기"
                  : confirmClear === "clear"
                    ? "필기 지우기"
                    : confirmClear === "reload"
                      ? "저장본으로 바꾸기"
                      : "페이지 삭제"}
              </button>
            </div>
          </div>
        </dialog>
      )}
    </section>
  );
}

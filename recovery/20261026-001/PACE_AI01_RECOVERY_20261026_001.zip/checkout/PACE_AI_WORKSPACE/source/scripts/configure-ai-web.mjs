import http from 'node:http';
import { randomBytes } from 'node:crypto';
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
const token=randomBytes(24).toString('hex');
const host='127.0.0.1';const port=4174;const origin=`http://${host}:${port}`;
const html=`<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>페이스 · AI 키 연결</title><style>body{font:16px/1.7 system-ui,sans-serif;background:#f6f5fc;color:#29273b;margin:0;display:grid;place-items:center;min-height:100vh}main{background:white;max-width:480px;margin:24px;padding:40px;border-radius:24px;border:1px solid #e8e6f0;box-shadow:0 20px 80px #3934520c}h1{font-size:26px;margin:0 0 16px}p{color:#686479}label{display:block;font-weight:600}input{box-sizing:border-box;width:100%;padding:14px;border:1px solid #d9d4e5;border-radius:10px;margin:10px 0 16px;font:inherit}button{background:#6560ce;border:0;border-radius:10px;color:white;padding:13px 20px;font:inherit;cursor:pointer;width:100%}small{display:block;margin-top:18px;color:#797587}#result{margin-top:16px;white-space:pre-line}</style><main><h1>페이스에 AI 연결하기</h1><p>성인 운영자가 발급한 Groq API 키를 아래에 붙여넣으세요. 이 컴퓨터의 비공개 설정 파일에 저장하며, 채팅에는 표시되지 않습니다.</p><form><label for="key">Groq API 키</label><input id="key" type="password" autocomplete="off" placeholder="gsk_로 시작하는 키" required><button>키 저장하고 마치기</button></form><div id="result" role="status"></div><small>무료 플랜을 유지하세요. 결제 수단을 등록할 필요가 없습니다.<br>키 저장 후에는 이 창을 닫고 다른 일을 하셔도 됩니다.</small></main><script>document.querySelector('form').onsubmit=async e=>{e.preventDefault();const key=document.querySelector('#key');const button=document.querySelector('button');button.disabled=true;try{const r=await fetch('/save/${token}',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:key.value.trim()})});const data=await r.json();document.querySelector('#result').textContent=data.message;if(r.ok){key.value='';document.querySelector('form').remove();}else button.disabled=false;}catch{document.querySelector('#result').textContent='저장하지 못했습니다. 개발 대화에 알려 주세요.';button.disabled=false;}};</script></html>`;
const server=http.createServer(async(req,res)=>{
 const security={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; frame-ancestors 'none'; form-action 'self'"};
 const reply=(status,body,type='application/json')=>{res.writeHead(status,{...security,'Content-Type':type+'; charset=utf-8'});res.end(typeof body==='string'?body:JSON.stringify(body));};
 if(req.headers.host!==`${host}:${port}`)return reply(403,{message:'허용되지 않은 주소입니다.'});
 if(req.method==='GET'&&req.url===`/${token}`)return reply(200,html,'text/html');
 if(req.method==='POST'&&req.url===`/save/${token}`&&req.headers.origin===origin){
  try{let text='';for await(const part of req){text+=part;if(text.length>1024)return reply(413,{message:'키 길이를 확인해 주세요.'});}const key=JSON.parse(text).key;if(typeof key!=='string'||!/^gsk_[A-Za-z0-9_-]{20,250}$/.test(key))return reply(400,{message:'gsk_로 시작하는 Groq API 키인지 확인해 주세요.'});writeFileSync(fileURLToPath(new URL('../.dev.vars',import.meta.url)),`GROQ_API_KEY=${key}\n`,{mode:0o600});reply(200,{message:'키를 이 컴퓨터에 저장했습니다. 이제 창을 닫고 다른 일을 하셔도 됩니다. AI 연결과 테스트는 제가 진행하겠습니다.'});console.log('API key saved. Value was not logged.');setTimeout(()=>server.close(),1500);}catch{reply(400,{message:'저장하지 못했습니다. 키를 확인해 주세요.'});}return;
 }
 reply(404,{message:'설정 페이지가 아닙니다.'});
});
server.listen(port,host,()=>console.log(`KEY_SETUP_URL=${origin}/${token}`));
setTimeout(()=>server.close(),30*60*1000).unref();

import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { generateAI } from '../lib/ai.ts';
const key=readFileSync('.dev.vars','utf8').match(/^GROQ_API_KEY=(.+)$/m)?.[1]?.trim();
if(!key)throw new Error('Configure the local key first.');
const source='https://www.suneung.re.kr/boardCnts/view.do?boardID=1500234&boardSeq=5093800&lev=0&m=0403&s=suneung';
// Equations transcribed after visually checking the official odd-numbered form.
// The answer key is never included in model requests.
const cases=[
 {id:1,prompt:'9^(1/4) × 3^(-1/2)의 값을 구해줘.',expected:'1'},
 {id:2,prompt:'f(x)=3x^3+4x+1일 때, h가 0으로 갈 때 [f(1+h)-f(1)]/h의 극한값을 구해줘.',expected:'13'},
 {id:3,prompt:'수열 a_n에 대해 k=1부터 4까지 (2a_k-k)의 합이 0이다. k=1부터 4까지 a_k의 합을 구해줘.',expected:'5'},
 {id:4,prompt:'f(x)는 x<1이면 3x-2, x>=1이면 x^2-3x+a이다. 실수 전체에서 연속일 때 a를 구해줘.',expected:'3'},
 {id:5,prompt:'f(x)=(x+2)(2x^2-x-2)일 때 f\'(1)을 구해줘.',expected:'8'},
 {id:6,prompt:'1보다 큰 실수 a,b에 대해 log_a(b)=3, log_3(b/a)=1/2이다. log_9(ab)의 값을 구해줘.',expected:'1/2'},
 {id:7,prompt:'두 곡선 y=x^2+3, y=-(1/5)x^2+3과 직선 x=2로 둘러싸인 부분의 넓이를 구해줘.',expected:'16/5'},
 {id:9,prompt:'a>0이고 f(x)=x^3+3ax^2-9a^2x+4이다. 직선 y=5가 이 함수의 그래프에 접할 때 f(2)를 구해줘.',expected:'14'},
 {id:13,prompt:'f(x)=x^2-4x-3의 점 (1,-6)에서의 접선을 l, g(x)=(x^3-2x)f(x)의 점 (1,6)에서의 접선을 m이라 하자. l,m과 y축이 만드는 도형의 넓이를 구해줘.',expected:'49'}
];
const dir='.sites-runtime/benchmarks';mkdirSync(dir,{recursive:true});
const results=[];
for(const c of cases){const started=Date.now();try{const result=await generateAI({mode:'ask',subject:'수학',question:c.prompt+' 마지막 줄은 정답만 숫자 또는 분수로 적어줘.',materials:[]},key);const last=result.text.trim().split('\n').filter(Boolean).at(-1);results.push({id:c.id,expected:c.expected,lastLine:last,response:result.text,elapsedMs:Date.now()-started,status:'answered'});console.log(JSON.stringify({question:c.id,expected:c.expected,lastLine:last,elapsedMs:Date.now()-started}));}catch(e){results.push({id:c.id,expected:c.expected,error:e.message,status:'failed'});console.log(JSON.stringify({question:c.id,error:e.message}));}writeFileSync(dir+'/live-results.json',JSON.stringify({source,model:'openai/gpt-oss-120b',runAt:new Date().toISOString(),method:'Official equations transcribed after visual check; official answers withheld from requests. Text-only evaluation; not PDF OCR accuracy.',results},null,2));}

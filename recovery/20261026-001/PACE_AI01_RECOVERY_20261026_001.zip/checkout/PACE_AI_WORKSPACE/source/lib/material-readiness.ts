import type {Material} from './study';

// Match evidence filtering in the AI context builder. Never hide corrupt math
// glyphs to make an unreadable source appear usable.
export function readableText(text:string):boolean {
 return Boolean(text.trim())&&(text.match(/[\uE000-\uF8FF]/g)||[]).length<=Math.max(2,text.length*.01);
}

export function materialReadiness(material:Pick<Material,'sections'>) {
 const rejected=material.sections.filter(s=>!readableText(s.text)).map(s=>s.page);
 return {total:material.sections.length,readable:material.sections.length-rejected.length,rejected};
}

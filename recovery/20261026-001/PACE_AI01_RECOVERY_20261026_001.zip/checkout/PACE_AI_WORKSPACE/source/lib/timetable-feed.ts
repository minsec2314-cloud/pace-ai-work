import {addDays,todayKST,validDate} from './study.ts';
import type {TimetableCell} from './timetable';
export type TimetableFeed={cells:TimetableCell[];source:'comcigan'|'neis';weekStart:string;upstreamUpdatedAt:string;checkedAt:string};
export function schoolWeek(week:number,now=new Date()){
 const today=todayKST(now),day=new Date(today+'T00:00:00Z').getUTCDay();return addDays(today,-((day+6)%7)+week*7);
}
export function parseSchoolFeed(data:unknown,source:TimetableFeed['source'],expectedWeek:string,now=new Date()):TimetableFeed{
 const d=data as {week_start?:unknown;update_date?:unknown;timetable?:unknown};
 if(!d||typeof d.week_start!=='string'||d.week_start.replace(/(\d{4})(\d{2})(\d{2})/,'$1-$2-$3')!==expectedWeek||!validDate(expectedWeek)||!Array.isArray(d.timetable)||d.timetable.length!==5)throw new Error('요청한 주와 일치하는 시간표를 받지 못했습니다.');
 const cells:TimetableCell[]=[];
 for(let day=0;day<5;day++){const row=d.timetable[day];if(!Array.isArray(row)||row.length>12)throw new Error('시간표 형식을 확인하지 못했습니다.');const seen=new Set<number>();for(const item of row){if(!item||!Number.isInteger(item.period)||item.period<1||item.period>12||typeof item.subject!=='string'||item.subject.length>40||seen.has(item.period))throw new Error('시간표 교시 정보를 확인하지 못했습니다.');seen.add(item.period);cells.push({day,period:item.period,subject:item.cancelled?'휴강':item.subject});}}
 if(!cells.some(c=>c.subject))throw new Error('이 주에는 공개된 수업 정보가 없습니다.');
 return {cells,source,weekStart:expectedWeek,upstreamUpdatedAt:typeof d.update_date==='string'?d.update_date.slice(0,100):'',checkedAt:now.toISOString()};
}

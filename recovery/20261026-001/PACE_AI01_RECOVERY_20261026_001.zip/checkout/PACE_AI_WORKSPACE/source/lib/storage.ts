import { initialState, validateState, type StudyState } from "./study.ts";
const DB = "pace-study-v1";
export function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    let abandoned = false;
    const r = indexedDB.open(DB, 3);
    r.onupgradeneeded = () => {
      if (!r.result.objectStoreNames.contains("state"))
        r.result.createObjectStore("state");
      if (!r.result.objectStoreNames.contains("files"))
        r.result.createObjectStore("files");
      if (!r.result.objectStoreNames.contains("ink"))
        r.result.createObjectStore("ink");
    };
    r.onsuccess = () => {
      if (abandoned) {
        r.result.close();
        return;
      }
      r.result.onversionchange = () => r.result.close();
      resolve(r.result);
    };
    r.onerror = () => reject(r.error);
    r.onblocked = () => {
      abandoned = true;
      reject(
        new Error(
          "다른 페이스 창을 닫고 새로고침하면 필기 저장소를 준비할 수 있어요.",
        ),
      );
    };
  });
}
export async function loadState(): Promise<StudyState> {
  const db = await openDB();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction("state", "readonly");
      const r = tx.objectStore("state").get("main");
      r.onsuccess = () => {
        if (r.result === undefined) resolve(initialState());
        else if (validateState(r.result)) resolve(r.result);
        else
          reject(
            new Error(
              "저장 자료 형식을 읽을 수 없습니다. 자동으로 덮어쓰지 않았습니다.",
            ),
          );
      };
      r.onerror = () => reject(r.error);
    });
  } finally {
    db.close();
  }
}
export async function saveState(state: StudyState) {
  const db = await openDB();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction("state", "readwrite");
      tx.objectStore("state").put(state, "main");
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}
export async function storeOriginal(id: string, file: Blob) {
  const db = await openDB();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction("files", "readwrite");
      tx.objectStore("files").put(file, id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}
export async function getOriginal(id: string): Promise<Blob | undefined> {
  const db = await openDB();
  try {
    return await new Promise((resolve, reject) => {
      const r = db
        .transaction("files", "readonly")
        .objectStore("files")
        .get(id);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  } finally {
    db.close();
  }
}
export async function deleteOriginal(id: string) {
  const db = await openDB();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction("files", "readwrite");
      tx.objectStore("files").delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}

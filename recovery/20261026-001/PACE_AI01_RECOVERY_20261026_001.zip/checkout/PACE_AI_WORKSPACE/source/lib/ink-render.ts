import { PAPER_WIDTH, PAPER_HEIGHT, type InkStroke, type InkPage } from "./ink";
export function paintStroke(ctx: CanvasRenderingContext2D, stroke: InkStroke) {
  const p = stroke.points;
  if (!p.length) return;
  ctx.save();
  ctx.strokeStyle = stroke.color;
  ctx.fillStyle = stroke.color;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.globalAlpha = stroke.tool === "highlighter" ? 0.25 : 1;
  if (stroke.tool === "highlighter") {
    ctx.lineWidth = stroke.width;
    ctx.beginPath();
    ctx.moveTo(p[0][0], p[0][1]);
    for (let i = 1; i < p.length; i++) ctx.lineTo(p[i][0], p[i][1]);
    if (p.length === 1) {
      ctx.lineTo(p[0][0] + 0.01, p[0][1]);
    }
    ctx.stroke();
  } else {
    const radius = (pressure: number) =>
      (stroke.width * (0.5 + 0.9 * pressure)) / 2;
    ctx.beginPath();
    ctx.arc(p[0][0], p[0][1], radius(p[0][2]), 0, Math.PI * 2);
    ctx.fill();
    for (let i = 1; i < p.length; i++) {
      ctx.lineWidth = radius((p[i - 1][2] + p[i][2]) / 2) * 2;
      ctx.beginPath();
      ctx.moveTo(p[i - 1][0], p[i - 1][1]);
      ctx.lineTo(p[i][0], p[i][1]);
      ctx.stroke();
    }
  }
  ctx.restore();
}
export function paintPaper(
  ctx: CanvasRenderingContext2D,
  page: InkPage,
  image?: HTMLImageElement,
) {
  ctx.save();
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, PAPER_WIDTH, PAPER_HEIGHT);
  if (image) {
    const fit = Math.min(
        PAPER_WIDTH / image.naturalWidth,
        PAPER_HEIGHT / image.naturalHeight,
      ),
      w = image.naturalWidth * fit,
      h = image.naturalHeight * fit;
    ctx.drawImage(image, (PAPER_WIDTH - w) / 2, (PAPER_HEIGHT - h) / 2, w, h);
  } else if (!page.background) {
    ctx.strokeStyle = "#e5e6f1";
    ctx.fillStyle = "#d9dbe9";
    ctx.lineWidth = 1;
    if (page.paper === "lined" || page.paper === "grid") {
      ctx.beginPath();
      for (let y = 70; y < PAPER_HEIGHT; y += 36) {
        ctx.moveTo(35, y);
        ctx.lineTo(PAPER_WIDTH - 35, y);
      }
      if (page.paper === "grid")
        for (let x = 35; x < PAPER_WIDTH; x += 36) {
          ctx.moveTo(x, 35);
          ctx.lineTo(x, PAPER_HEIGHT - 35);
        }
      ctx.stroke();
    }
    if (page.paper === "dots")
      for (let x = 42; x < PAPER_WIDTH; x += 28)
        for (let y = 42; y < PAPER_HEIGHT; y += 28) {
          ctx.beginPath();
          ctx.arc(x, y, 1.2, 0, Math.PI * 2);
          ctx.fill();
        }
  }
  ctx.restore();
}

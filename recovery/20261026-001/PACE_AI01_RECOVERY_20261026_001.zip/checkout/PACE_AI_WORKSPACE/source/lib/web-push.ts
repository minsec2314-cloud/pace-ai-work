import {buildPushPayload,type PushSubscription} from '@block65/webcrypto-web-push';
export type AlarmEnv={DB?:D1Database;VAPID_PUBLIC_KEY?:string;VAPID_PRIVATE_KEY?:string;VAPID_SUBJECT?:string;ALARM_TICK_KEY?:string};
export function validPushSubscription(value:unknown):value is PushSubscription{
 try{const s=value as PushSubscription;if(!s||typeof s.endpoint!=='string'||s.endpoint.length>2048)return false;const url=new URL(s.endpoint);const allowed=url.hostname==='fcm.googleapis.com'||url.hostname==='updates.push.services.mozilla.com'||url.hostname.endsWith('.push.services.mozilla.com')||url.hostname==='web.push.apple.com'||url.hostname.endsWith('.push.apple.com');return allowed&&url.protocol==='https:'&&!url.username&&!url.password&&!url.hash&&(!url.port||url.port==='443')&&!!s.keys&&typeof s.keys.p256dh==='string'&&typeof s.keys.auth==='string'&&/^[A-Za-z0-9_-]{87}={0,2}$/.test(s.keys.p256dh)&&/^[A-Za-z0-9_-]{22}={0,2}$/.test(s.keys.auth);}catch{return false;}
}
export async function sendPush(env:AlarmEnv,subscription:unknown,message:{title:string;body:string;tag:string}){
 if(!env.VAPID_PUBLIC_KEY||!env.VAPID_PRIVATE_KEY||!env.VAPID_SUBJECT)throw new Error('푸시 서버 키가 없습니다.');
 if(!validPushSubscription(subscription))throw new Error('지원하지 않는 알림 주소입니다.');
 const payload=await buildPushPayload({data:JSON.stringify({...message,url:'/'}),options:{ttl:3600}},subscription,{publicKey:env.VAPID_PUBLIC_KEY,privateKey:env.VAPID_PRIVATE_KEY,subject:env.VAPID_SUBJECT});
 const r=await fetch(subscription.endpoint,{...payload,redirect:'error',signal:AbortSignal.timeout(10000)});return r.status;
}

// Normalize model math delimiters before the Markdown syntax parser sees them.
// Code blocks are kept intact; math is never evaluated as JavaScript or HTML.
function typesetSimpleExpressions(text:string):string{
 const atom="(?:[A-Za-z\\u0370-\\u03ff](?:['′])?|-?\\d+(?:\\.\\d+)?)";
 const expression=new RegExp(`(?<![A-Za-z\\u0370-\\u03ff0-9_/])${atom}(?:[ \\u00a0\\u202f]*[*/÷^][ \\u00a0\\u202f]*${atom})+(?![A-Za-z\\u0370-\\u03ff0-9_/])`,'gu');
 return text.split(/(https?:\/\/[^\s)]+)/g).map(part=>part.startsWith('http')?part:part.replace(expression,raw=>{
  if(/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(raw))return raw;
  const tokens=raw.match(/[A-Za-z\u0370-\u03ff](?:['′])?|-?\d+(?:\.\d+)?|[*/÷^]/g)!;let i=0;
  const power=():string=>{const base=tokens[i++];if(tokens[i]==='^'){i++;return `${base}^{${power()}}`;}return base;};
  let math=power();while(i<tokens.length){const operator=tokens[i++],right=power();math=operator==='*'?`${math}\\times ${right}`:`\\frac{${math}}{${right}}`;}
  return `$${math}$`;
 })).join('');
}
export function prepareMarkdown(text:string):string {
 const blocks=text.split(/(```[\s\S]*?```|`[^`\n]+`)/g);
 return blocks.map(part=>{
  if(/^```(?:math|latex|tex)\s*\n/i.test(part))return part.replace(/^```(?:math|latex|tex)\s*\n/i,()=>'$$\n').replace(/```$/,()=>'\n$$');
  if(part.startsWith('`'))return part;
  part=part.replace(/\\+n(?![A-Za-z])/g,'\n');
  return part.replace(/\\\[([\s\S]*?)\\\]/g,(_,math:string)=>`\n\n$$\n${math.trim()}\n$$\n\n`).replace(/\\\(([\s\S]*?)\\\)/g,(_,math:string)=>`$${math.trim()}$`);
 }).join('').split(/(\$\$[\s\S]*?\$\$|\$[^$\n]+\$|```[\s\S]*?```|`[^`\n]+`)/g).map(part=>{
  if(part.startsWith('$')||part.startsWith('`'))return part;
  return part.split('\n').map(line=>{const math=line.trim();if(!/\\(?:frac|dfrac|sqrt|text|mathrm|lambda|theta|pi|alpha|beta|times|cdot|,|;)/.test(math))return typesetSimpleExpressions(line);
   const remainder=math.replace(/\\(?:text|mathrm)\{[^{}]*\}/g,'').replace(/\\[A-Za-z]+/g,'').replace(/[\s\dA-Za-zΑ-ω\\{}()[\].,+\-*/=<>_^'|:;%!]/g,'');
   return remainder===''?`$${math}$`:line;
  }).join('\n');
 }).join('');
}

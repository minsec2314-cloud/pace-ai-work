export type InkInputTool = "pen" | "highlighter" | "eraser" | "hand";
export type InkPointerState = {
  pointerType: string;
  buttons: number;
  pressure: number;
};

// Pointer Events: barrel button = 2; eraser end = 32. A barrel button
// pressed in hover is not pen contact and must never erase the document.
export function inkPointerTool(
  selected: InkInputTool,
  event: InkPointerState,
): InkInputTool {
  return event.pointerType === "pen" && (event.buttons & 34) !== 0
    ? "eraser"
    : selected;
}
export function inkPenContact(event: InkPointerState) {
  return (
    event.pointerType === "pen" &&
    ((event.buttons & 33) !== 0 || event.pressure > 0)
  );
}

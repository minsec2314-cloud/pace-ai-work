import type { Section } from './study';
export async function extractFile(file:File):Promise<{sections:Section[];warning?:string}>{
 if(file.size>20*1024*1024)throw new Error('파일은 20MB 이하로 넣어 주세요. 큰 PDF는 필요한 부분만 나누어 주세요.');
 const ext=file.name.toLowerCase().split('.').pop();
 if(ext==='ppt')throw new Error('PPT는 PowerPoint에서 PDF 또는 PPTX로 저장한 뒤 넣어 주세요.');
 if(ext==='pdf'){
  const pdfjs=await import('pdfjs-dist');pdfjs.GlobalWorkerOptions.workerSrc='/pdf.worker.min.mjs';
  const pdf=await pdfjs.getDocument({data:new Uint8Array(await file.arrayBuffer()),cMapUrl:'/pdf-cmaps/',cMapPacked:true,standardFontDataUrl:'/pdf-fonts/'}).promise;
  try{
   if(pdf.numPages>300)throw new Error('PDF는 300쪽 이하로 나누어 주세요.');
   const sections:Section[]=[];let total=0;
   for(let page=1;page<=pdf.numPages;page++){
    const content=await(await pdf.getPage(page)).getTextContent();
    const text=content.items.map(item=>'str'in item?item.str+('hasEOL'in item&&item.hasEOL?'\n':' '):'').join('').trim();
    if(text.length>100000)throw new Error(`${page}쪽의 글자가 너무 많습니다. 필요한 부분을 나누거나 텍스트 자료로 넣어 주세요.`);
    total+=text.length;if(total>1500000)throw new Error('텍스트가 너무 많습니다. 시험 범위에 해당하는 부분만 나누어 넣어 주세요.');
    sections.push({page,text});
   }
   if(!sections.some(s=>s.text.length>10))return {sections,warning:'스캔·사진 PDF로 보입니다. 원문을 열고 필요한 쪽만 AI 문자 인식으로 읽은 뒤 직접 확인하거나, 텍스트를 입력해 주세요.'};
   const corrupted=sections.filter(s=>(s.text.match(/[\uE000-\uF8FF]/g)||[]).length>Math.max(2,s.text.length*.01));
   if(corrupted.length)return {sections,warning:`${corrupted.length}쪽에서 깨진 수식·글자 기호가 감지됐습니다. 해당 쪽은 AI 근거 검색에서 제외합니다. 원문을 열어 AI 문자 인식 또는 직접 수정 후 확인해 주세요.`};
   const empty=sections.filter(s=>s.text.length<10).length;
   return {sections,warning:empty?`${empty}쪽에서 글자를 충분히 읽지 못했습니다. 이미지·수식·표의 배치가 빠질 수 있으니 추출 내용을 확인해 주세요.`:'그림과 수식, 표의 배치는 텍스트에 완전히 반영되지 않을 수 있습니다.'};
  }finally{await pdf.destroy();}
 }
 if(ext==='pptx'){
  const {unzipSync,strFromU8}=await import('fflate');
  const zip=unzipSync(new Uint8Array(await file.arrayBuffer()),{filter:f=>/^ppt\/slides\/slide\d+\.xml$/.test(f.name)&&f.originalSize<=2*1024*1024});
  const names=Object.keys(zip).sort((a,b)=>Number(a.match(/slide(\d+)/)?.[1])-Number(b.match(/slide(\d+)/)?.[1]));
  if(!names.length||names.length>300)throw new Error('읽을 수 있는 슬라이드가 없거나 300장을 넘습니다. PDF로 저장해 다시 넣어 주세요.');
  let total=0;const sections=names.map(name=>{const xml=new DOMParser().parseFromString(strFromU8(zip[name]),'application/xml');if(xml.querySelector('parsererror'))throw new Error('슬라이드 파일이 손상되었습니다.');const text=Array.from(xml.getElementsByTagNameNS('*','p')).map(p=>Array.from(p.getElementsByTagNameNS('*','t')).map(t=>t.textContent||'').join('')).filter(Boolean).join('\n');if(text.length>100000)throw new Error('슬라이드 한 장의 글자가 너무 많습니다. 필요한 범위만 나누어 주세요.');total+=text.length;if(total>1500000)throw new Error('자료가 너무 큽니다. 나누어 넣어 주세요.');return {page:Number(name.match(/slide(\d+)/)?.[1]),text};});
  if(!sections.some(s=>s.text.trim().length>10))throw new Error('슬라이드에서 글자를 찾지 못했습니다. 이미지 자료는 텍스트로 직접 추가해 주세요.');
  return {sections,warning:'슬라이드의 텍스트를 읽었습니다. 그림·수식·발표자 메모는 포함되지 않습니다.'};
 }
 if(ext==='txt') {const text=await file.text();if(!text.trim())throw new Error('빈 파일입니다.');if(text.length>1500000)throw new Error('텍스트가 너무 큽니다.');const sections:Section[]=[];for(let offset=0;offset<text.length;){let end=Math.min(text.length,offset+100000);if(end<text.length&&/[\uD800-\uDBFF]/.test(text[end-1]))end--;sections.push({page:sections.length+1,text:text.slice(offset,end)});offset=end;}return {sections,warning:sections.length>1?'긴 텍스트를 10만 자 이하의 부분으로 나누어 보관했습니다. 쪽 번호는 텍스트를 나눈 순서입니다.':undefined};}
 throw new Error('PDF, PPTX, TXT 파일을 지원합니다.');
}

export async function renderPDFPage(file:Blob,pageNumber:number):Promise<string>{
 const pdfjs=await import('pdfjs-dist');pdfjs.GlobalWorkerOptions.workerSrc='/pdf.worker.min.mjs';
 const task=pdfjs.getDocument({data:new Uint8Array(await file.arrayBuffer()),cMapUrl:'/pdf-cmaps/',cMapPacked:true,standardFontDataUrl:'/pdf-fonts/'});
 let timer:ReturnType<typeof setTimeout>|undefined;
 const timeout=new Promise<never>((_,reject)=>{timer=setTimeout(()=>{reject(new Error('원문 이미지가 30초 안에 열리지 않았습니다. 원본을 내려받아 확인하거나 PDF를 필요한 쪽만 나누어 다시 넣어 주세요.'));void task.destroy().catch(()=>{});},30000);});
 try{return await Promise.race([(async()=>{const pdf=await task.promise;const page=await pdf.getPage(pageNumber);const viewport=page.getViewport({scale:Math.min(2.5,2300/page.getViewport({scale:1}).width)});const canvas=document.createElement('canvas');canvas.width=viewport.width;canvas.height=viewport.height;await page.render({canvas,viewport}).promise;const data=canvas.toDataURL('image/jpeg',.92);if(data.length>4000000)throw new Error('페이지 이미지가 너무 큽니다. 원본에서 필요한 부분을 나누어 주세요.');return data;})(),timeout]);}finally{clearTimeout(timer);void task.destroy().catch(()=>{});}
}

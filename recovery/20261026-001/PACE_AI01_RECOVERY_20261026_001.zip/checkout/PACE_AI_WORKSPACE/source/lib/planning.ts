import {addDays,dayDiff,validDate,type StudyState} from './study.ts';

// Uses the same inputs as buildPlan. It audits saved sessions rather than
// presenting a newly calculated plan as if it had already been saved.
export function preparationAudit(state:StudyState,today:string){
 const jobs=[...state.subjects.filter(s=>validDate(s.examDate)).map(s=>({id:s.id,kind:'subject' as const,title:s.scope||`${s.name} 시험 복습`,subjectId:s.id,target:s.minutes,deadline:addDays(s.examDate,-1),confidence:s.confidence,nextStep:'등록한 시험 범위를 복습해요.'})),...state.assessments.filter(t=>!t.done).map(t=>({id:t.id,kind:'task' as const,title:t.title,subjectId:t.subjectId,target:t.minutes,deadline:t.prepareBy||t.due,confidence:1,nextStep:t.steps?.find(x=>!x.done)?.title||'활동 노트에서 준비할 일을 작은 단계로 나눠 보세요.'}))];
 return jobs.map(j=>{const own=state.sessions.filter(s=>s.sourceId===j.id&&s.kind===j.kind);const completed=own.filter(s=>s.done).reduce((n,s)=>n+s.minutes,0);const remaining=Math.max(0,j.target-completed);const scheduled=own.filter(s=>!s.done&&s.date>=today&&s.date<=j.deadline).reduce((n,s)=>n+s.minutes,0);const days=Math.max(0,dayDiff(today,j.deadline)+1);return {...j,completed,remaining,scheduled,shortage:Math.max(0,remaining-scheduled),days,average:days?Math.ceil(remaining/days):null};});
}

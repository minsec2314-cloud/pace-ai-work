import {sendPush,type AlarmEnv} from './web-push';
export async function runAlarmScheduler(env:AlarmEnv,now=Date.now(),source='cron'){
 if(!env.DB)throw new Error('알람 저장소 연결이 필요합니다.');
 const db=env.DB;
 await db.prepare('INSERT INTO scheduler_health (key,last_run,run_count) VALUES (?, ?, 1) ON CONFLICT(key) DO UPDATE SET last_run=excluded.last_run,run_count=run_count+1').bind(source,now).run();
 await db.prepare("UPDATE alarm_schedules SET status='missed',updated_at=? WHERE status='pending' AND fire_at<?").bind(now,now-86400000).run();
 const {results:alarms}=await db.prepare("SELECT id,user_id,title,fire_at FROM alarm_schedules WHERE status='pending' AND fire_at<=? ORDER BY fire_at LIMIT 20").bind(now).all<{id:string;user_id:string;title:string;fire_at:number}>();let accepted=0,failed=0;
 for(const alarm of alarms){const {results:devices}=await db.prepare('SELECT id,subscription_json FROM push_devices WHERE user_id=? AND enabled=1 LIMIT 5').bind(alarm.user_id).all<{id:string;subscription_json:string}>();if(!devices.length)continue;
  const outcomes=await Promise.all(devices.map(async device=>{const id=`${alarm.id}:${alarm.fire_at}:${device.id}`;
   await db.prepare("INSERT OR IGNORE INTO alarm_deliveries (id,alarm_id,user_id,device_id,scheduled_for,status,attempts,updated_at) VALUES (?,?,?,?,?,'pending',0,?)").bind(id,alarm.id,alarm.user_id,device.id,alarm.fire_at,now).run();
   const old=await db.prepare('SELECT status,attempts,updated_at FROM alarm_deliveries WHERE id=?').bind(id).first<{status:string;attempts:number;updated_at:number}>();if(old?.status==='sent'||old?.status==='gone')return true;if(old&&old.attempts>=3)return false;
   const claimed=await db.prepare("UPDATE alarm_deliveries SET status='sending',attempts=attempts+1,updated_at=? WHERE id=? AND (status IN ('pending','failed') OR (status='sending' AND updated_at<?)) RETURNING id").bind(now,id,now-120000).first();if(!claimed)return false;
   try{const status=await sendPush(env,JSON.parse(device.subscription_json),{title:'페이스 · '+alarm.title,body:'예약한 알림 시간이에요. 활동과 준비 계획을 확인해 주세요.',tag:id});const gone=status===404||status===410;const ok=status>=200&&status<300;await db.prepare('UPDATE alarm_deliveries SET status=?,updated_at=? WHERE id=?').bind(ok?'sent':gone?'gone':'failed',now,id).run();if(gone)await db.prepare('UPDATE push_devices SET enabled=0 WHERE id=? AND user_id=?').bind(device.id,alarm.user_id).run();if(ok)accepted++;else if(!gone)failed++;return ok||gone;}catch{failed++;await db.prepare("UPDATE alarm_deliveries SET status='failed',updated_at=? WHERE id=?").bind(now,id).run();return false;}
  }));
  if(outcomes.every(Boolean))await db.prepare("UPDATE alarm_schedules SET status='sent',updated_at=? WHERE id=? AND user_id=? AND status='pending' AND fire_at=?").bind(now,alarm.id,alarm.user_id,alarm.fire_at).run();
 }
 return {checkedAt:now,checked:alarms.length,accepted,failed};
}

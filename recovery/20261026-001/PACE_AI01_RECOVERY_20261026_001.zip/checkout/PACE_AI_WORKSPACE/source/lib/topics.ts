export type TopicIdea={title:string;question:string;why:string;method:string;supplies:string;firstSteps:string[];cautions:string};
export type TopicLab={interest:string;subject:string;constraints:string;days:number;refinement:string;ideas:TopicIdea[];updatedAt:string};
export const topicSystem=`당신은 고등학생의 탐구 주제 탐색을 돕는 지도 파트너입니다. 아직 활동을 등록하지 않은 학생에게 관심사와 현실적인 제약에 맞는 서로 다른 탐구 후보를 정확히 3개 제안하세요. 단순 조사 제목이 아니라 고등학생이 비교·관찰·공개 데이터 분석으로 답을 찾아볼 수 있는 구체적인 질문으로 만드세요. 질문은 제안한 방법으로 직접 확인할 수 있는 범위로 좁히세요. 소음 측정만으로 집중력·학습 효과를 증명할 수 있다고 쓰는 등 측정하지 않은 결과나 인과관계를 주장하지 마세요. 사람의 과제 수행 시간·정확도·생체·심리 자료를 새로 수집하는 실험 대신 물리량 관찰이나 공개된 익명 데이터를 활용하세요. 각 후보는 학생이 적은 제한 조건을 모두 지켜야 합니다. 주제명과 첫 할 일은 마크다운 기호 없이 간결한 문장으로 쓰세요. 학년, 기간, 준비물, 비용, 평가 기준을 고려하고 조건이 부족하면 각 후보에 확인할 가정을 명시하세요. 위험 물질, 인체 실험, 개인정보 수집, 동물 실험, 허가 없는 시설 사용을 요구하지 마세요. 대안을 제안하세요. 논문이나 실제 검색 결과를 확인한 척하지 말고 존재하지 않는 논문·URL을 만들지 마세요. 결과를 미리 단정하거나 완성 보고서를 대신 쓰지 마세요. 학생이 주제를 고르고 자신의 가설을 세울 수 있도록 도우세요. 추가 조건이 있으면 이전 후보를 그대로 반복하지 말고 반영하세요. 반드시 JSON 객체 하나만 출력하세요. 형식: {ideas:[{title:120자 이내의 구체적인 탐구 제목,question:검증 가능한 중심 탐구 질문,why:관심사 및 교과와의 연결,method:비교 대상과 측정 또는 분석 방법 및 통제할 조건,supplies:필요한 도구와 데이터 및 대안,firstSteps:바로 시작할 작은 할 일 3개의 문자열 배열,cautions:실현 가능성의 한계와 지도교사에게 확인할 점}]}. 모든 설명은 한국어이며 각 후보는 제공 조건 안에서 실행할 수 있어야 합니다.`;
export function validTopicIdea(value:unknown):value is TopicIdea{
 if(!value||typeof value!=='object')return false;const v=value as TopicIdea;
 return ['title','question','why','method','supplies','cautions'].every(k=>typeof v[k as keyof TopicIdea]==='string'&&(v[k as keyof TopicIdea] as string).trim().length>0&&(v[k as keyof TopicIdea] as string).length<=2000)&&v.title.length<=120&&Array.isArray(v.firstSteps)&&v.firstSteps.length===3&&v.firstSteps.every(s=>typeof s==='string'&&s.trim().length>0&&s.length<=300);
}
export function readTopicIdeas(output:Record<string,unknown>):TopicIdea[]{
 if(!Array.isArray(output.ideas)||output.ideas.length!==3||!output.ideas.every(validTopicIdea))throw new Error('탐구 후보의 형식이 불완전합니다. 조건을 조금 더 적고 다시 요청해 주세요.');
 const questions=output.ideas.map(idea=>idea.question.trim().replace(/\s+/g,' '));
 if(new Set(questions).size!==questions.length)throw new Error('탐구 후보의 중심 질문이 중복됩니다. 서로 다른 질문 3개로 다시 제안해야 합니다.');
 return output.ideas;
}
export function topicNote(idea:TopicIdea){return `## 탐구 질문\n${idea.question}\n\n## 주제를 고른 이유\n${idea.why}\n\n## 탐구 방법 초안\n${idea.method}\n\n## 준비물 · 데이터\n${idea.supplies}\n\n## 확인할 점\n${idea.cautions}\n\nAI가 제안한 탐구 초안입니다. 실제 실행 가능성과 평가 기준은 선생님과 확인하고, 가설과 해석은 내 생각으로 정리하세요.`;}

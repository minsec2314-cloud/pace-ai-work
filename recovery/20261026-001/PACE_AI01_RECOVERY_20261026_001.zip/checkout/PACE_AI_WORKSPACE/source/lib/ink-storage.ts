import { openDB } from "./storage.ts";
import { validInkBook, type InkBook } from "./ink.ts";
import { validateState, type StudyState } from "./study.ts";

const drafts = new Map<string, { book: InkBook; revision: number }>(),
  writes = new Set<Promise<unknown>>();
export function recordInkDraft(book: InkBook, revision: number) {
  drafts.set(book.id, { book, revision });
}
export function acknowledgeInkDraft(book: InkBook, revision: number) {
  const entry = drafts.get(book.id);
  if (entry?.book === book) drafts.delete(book.id);
  else if (entry) entry.revision = revision;
}
// Call only after explicitly replacing the unsaved editor from a saved copy.
export function discardInkDraft(id: string) {
  drafts.delete(id);
}
export function trackInkWrite(promise: Promise<unknown>) {
  writes.add(promise);
  void promise.then(
    () => writes.delete(promise),
    () => writes.delete(promise),
  );
}
async function flushInkWrites() {
  while (writes.size) await Promise.allSettled([...writes]);
}
if (typeof window !== "undefined")
  window.addEventListener("beforeunload", (e) => {
    if (drafts.size) {
      e.preventDefault();
      e.returnValue = "";
    }
  });

export class InkConflictError extends Error {
  constructor() {
    super(
      "다른 창에서 이 노트가 변경됐습니다. 현재 필기를 백업한 뒤 저장본을 다시 열어 주세요.",
    );
    this.name = "InkConflictError";
  }
}
export async function loadInkBook(id: string, storedOnly = false): Promise<InkBook | undefined> {
  await flushInkWrites();
  const draft = drafts.get(id);
  if (draft && !storedOnly) return { ...draft.book, revision: draft.revision };
  const db = await openDB();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction("ink", "readonly"),
        r = tx.objectStore("ink").get(id);
      r.onsuccess = () => {
        if (r.result === undefined) resolve(undefined);
        else if (validInkBook(r.result)) resolve(r.result);
        else
          reject(
            new Error("저장한 필기 형식을 읽을 수 없어 덮어쓰지 않았습니다."),
          );
      };
      r.onerror = () => reject(r.error);
    });
  } finally {
    db.close();
  }
}
export async function allInkBooks(): Promise<InkBook[]> {
  const db = await openDB();
  try {
    return await new Promise((resolve, reject) => {
      const r = db.transaction("ink", "readonly").objectStore("ink").getAll();
      r.onsuccess = () => {
        if (r.result.every(validInkBook)) resolve(r.result);
        else
          reject(
            new Error("읽을 수 없는 필기 노트가 있어 백업을 중단했습니다."),
          );
      };
      r.onerror = () => reject(r.error);
    });
  } finally {
    db.close();
  }
}
export async function saveInkBook(
  book: InkBook,
  expectedRevision: number,
): Promise<InkBook> {
  if (!validInkBook(book) || !Number.isSafeInteger(expectedRevision) || expectedRevision < 0 || expectedRevision >= Number.MAX_SAFE_INTEGER)
    throw new Error(
      "필기 데이터가 올바르지 않거나 노트 용량을 넘었습니다. 새 노트를 만들어 주세요.",
    );
  const db = await openDB();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction("ink", "readwrite"),
        store = tx.objectStore("ink"),
        r = store.get(book.id);
      let failure: Error | null = null;
      const saved = {
        ...book,
        revision: expectedRevision + 1,
        updatedAt: new Date().toISOString(),
      };
      r.onsuccess = () => {
        if (r.result !== undefined && !validInkBook(r.result)) {
          failure = new Error("기존 필기 형식을 확인할 수 없어 덮어쓰지 않았습니다. 현재 노트를 백업해 주세요.");
          tx.abort();
          return;
        }
        if ((r.result?.revision || 0) !== expectedRevision) {
          failure = new InkConflictError();
          tx.abort();
          return;
        }
        store.put(saved, book.id);
      };
      tx.oncomplete = () => resolve(saved);
      tx.onabort = () =>
        reject(
          failure || saveFailure(tx.error),
        );
      tx.onerror = () => reject(saveFailure(tx.error));
    });
  } finally {
    db.close();
  }
}
function saveFailure(error: DOMException | null) {
  return error?.name === "QuotaExceededError"
    ? new Error("기기의 저장 공간이 부족합니다. 현재 노트를 먼저 백업한 뒤 브라우저 저장 공간을 확인해 주세요.")
    : error || new Error("필기를 저장하지 못했습니다. 현재 노트를 먼저 백업해 주세요.");
}
export type StudyBackup = StudyState & { handwriting?: InkBook[] };
export function validateStudyBackup(value: unknown): value is StudyBackup {
  if (!validateState(value)) return false;
  const books = (value as StudyBackup).handwriting;
  return (
    books === undefined ||
    (Array.isArray(books) &&
      books.length <= 1000 &&
      books.every(validInkBook) &&
      new Set(books.map((b) => b.id)).size === books.length)
  );
}
export async function createStudyBackup(
  state: StudyState,
): Promise<StudyBackup> {
  await flushInkWrites();
  const books = new Map((await allInkBooks()).map((b) => [b.id, b]));
  for (const [id, entry] of drafts)
    books.set(id, { ...entry.book, revision: entry.revision });
  return { ...state, handwriting: [...books.values()] };
}
// Existing notes not present in an older backup are retained. Imported note
// revisions advance so another open editor cannot silently overwrite a restore.
export async function restoreStudyBackup(
  backup: StudyBackup,
): Promise<StudyState> {
  if (!validateStudyBackup(backup))
    throw new Error(
      "백업의 필기 데이터가 올바르지 않습니다. 기존 기록은 변경하지 않았습니다.",
    );
  await flushInkWrites();
  const { handwriting, ...state } = backup;
  const db = await openDB();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(["state", "ink"], "readwrite");
      tx.objectStore("state").put(state, "main");
      const store = tx.objectStore("ink");
      for (const book of handwriting || []) {
        const r = store.get(book.id);
        r.onsuccess = () =>
          store.put(
            {
              ...book,
              revision: Math.max(book.revision, r.result?.revision || 0) + 1,
            },
            book.id,
          );
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () =>
        reject(tx.error || new Error("백업을 복원하지 못했습니다."));
    });
    for (const book of handwriting || []) drafts.delete(book.id);
    return state;
  } finally {
    db.close();
  }
}

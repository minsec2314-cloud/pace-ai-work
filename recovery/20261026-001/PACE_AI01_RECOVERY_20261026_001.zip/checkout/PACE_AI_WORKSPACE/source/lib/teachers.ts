import type {Material} from './study';
export type TeacherProfile={id:string;subjectId:string;name:string;pastIds:string[];lessonIds:string[]};
export function teacherMaterials(profile:TeacherProfile|undefined,materials:Material[]):Material[]{
 if(!profile)return [];return materials.filter(m=>m.subjectId===profile.subjectId&&(profile.pastIds.includes(m.id)||profile.lessonIds.includes(m.id))).map(m=>({...m,kind:profile.pastIds.includes(m.id)?'exam':'lesson'}));
}
export function assignTeacherMaterial(profile:TeacherProfile,id:string,role:'exam'|'lesson'|'none'):TeacherProfile{return {...profile,pastIds:[...profile.pastIds.filter(x=>x!==id),...(role==='exam'?[id]:[])],lessonIds:[...profile.lessonIds.filter(x=>x!==id),...(role==='lesson'?[id]:[])]};}

export type InkPoint = [number, number, number];
export type InkTool = "pen" | "highlighter";
export type InkStroke = {
  id: string;
  tool: InkTool;
  color: string;
  width: number;
  points: InkPoint[];
};
export type InkPaper = "blank" | "lined" | "grid" | "dots";
export type InkPage = {
  id: string;
  name: string;
  paper: InkPaper;
  strokes: InkStroke[];
  background?: { materialId: string; page: number; name: string };
};
export type InkBook = {
  version: 1;
  id: string;
  taskId: string;
  title: string;
  revision: number;
  updatedAt: string;
  activePageId: string;
  pages: InkPage[];
};
export type InkView = { scale: number; x: number; y: number };
export const PAPER_WIDTH = 1000,
  PAPER_HEIGHT = 1414,
  MAX_INK_PAGES = 60,
  MAX_BOOK_POINTS = 750000;
export const INK_COLORS = [
  "#252838",
  "#7560ba",
  "#1b72bf",
  "#22826b",
  "#c74451",
  "#ecbb43",
];
export function inkId() {
  return globalThis.crypto.randomUUID();
}
export function newInkPage(index = 1): InkPage {
  return { id: inkId(), name: `${index}쪽`, paper: "lined", strokes: [] };
}
export function newInkBook(taskId: string, title: string): InkBook {
  const page = newInkPage();
  return {
    version: 1,
    id: `activity:${taskId}`,
    taskId,
    title,
    revision: 0,
    updatedAt: new Date().toISOString(),
    activePageId: page.id,
    pages: [page],
  };
}
export function pointCount(book: InkBook) {
  return book.pages.reduce(
    (total, p) => total + p.strokes.reduce((n, s) => n + s.points.length, 0),
    0,
  );
}
export function validInkBook(value: unknown): value is InkBook {
  try {
    const b = value as InkBook;
    if (
      !b ||
      b.version !== 1 ||
      typeof b.taskId !== "string" ||
      !b.taskId ||
      b.taskId.length > 100 ||
      b.id !== `activity:${b.taskId}` ||
      typeof b.title !== "string" ||
      b.title.length > 200 ||
      !Number.isSafeInteger(b.revision) ||
      b.revision < 0 ||
      typeof b.updatedAt !== "string" ||
      !Number.isFinite(Date.parse(b.updatedAt)) ||
      !Array.isArray(b.pages) ||
      !b.pages.length ||
      b.pages.length > MAX_INK_PAGES
    )
      return false;
    const ids = new Set<string>();
    let points = 0,
      strokes = 0;
    for (const p of b.pages) {
      if (
        !p ||
        typeof p.id !== "string" ||
        !p.id ||
        p.id.length > 100 ||
        ids.has(p.id) ||
        typeof p.name !== "string" ||
        p.name.length > 120 ||
        !["blank", "lined", "grid", "dots"].includes(p.paper) ||
        !Array.isArray(p.strokes) ||
        p.strokes.length > 5000
      )
        return false;
      ids.add(p.id);
      if (
        p.background &&
        (!p.background.materialId ||
          typeof p.background.materialId !== "string" ||
          p.background.materialId.length > 100 ||
          !Number.isInteger(p.background.page) ||
          p.background.page < 1 ||
          p.background.page > 300 ||
          typeof p.background.name !== "string" ||
          p.background.name.length > 250)
      )
        return false;
      const strokeIds = new Set<string>();
      for (const s of p.strokes) {
        if (
          !s ||
          typeof s.id !== "string" ||
          !s.id ||
          s.id.length > 100 ||
          strokeIds.has(s.id) ||
          !["pen", "highlighter"].includes(s.tool) ||
          !/^#[0-9a-f]{6}$/i.test(s.color) ||
          !Number.isFinite(s.width) ||
          s.width < 0.25 ||
          s.width > 64 ||
          !Array.isArray(s.points) ||
          !s.points.length ||
          s.points.length > 16000
        )
          return false;
        strokeIds.add(s.id);
        strokes++;
        points += s.points.length;
        if (points > MAX_BOOK_POINTS || strokes > 20000) return false;
        for (const point of s.points)
          if (
            !Array.isArray(point) ||
            point.length !== 3 ||
            !point.every(Number.isFinite) ||
            point[0] < 0 ||
            point[0] > PAPER_WIDTH ||
            point[1] < 0 ||
            point[1] > PAPER_HEIGHT ||
            point[2] < 0 ||
            point[2] > 1
          )
            return false;
      }
    }
    return ids.has(b.activePageId);
  } catch {
    return false;
  }
}
export function normalizeInkPoint(
  x: number,
  y: number,
  pressure: number,
): InkPoint {
  return [
    Math.round(Math.max(0, Math.min(PAPER_WIDTH, x)) * 100) / 100,
    Math.round(Math.max(0, Math.min(PAPER_HEIGHT, y)) * 100) / 100,
    Math.round(
      Math.max(0.05, Math.min(1, Number.isFinite(pressure) ? pressure : 0.5)) *
        100,
    ) / 100,
  ];
}
export function segmentDistance(
  x: number,
  y: number,
  a: InkPoint,
  b: InkPoint,
) {
  const dx = b[0] - a[0],
    dy = b[1] - a[1],
    den = dx * dx + dy * dy,
    t = den
      ? Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / den))
      : 0;
  return Math.hypot(x - a[0] - t * dx, y - a[1] - t * dy);
}
export function strokeHit(
  stroke: InkStroke,
  x: number,
  y: number,
  radius: number,
) {
  const r = radius + stroke.width / 2;
  const p = stroke.points;
  if (p.length === 1) return Math.hypot(x - p[0][0], y - p[0][1]) <= r;
  for (let i = 1; i < p.length; i++)
    if (segmentDistance(x, y, p[i - 1], p[i]) <= r) return true;
  return false;
}
export function eraseInk(
  strokes: InkStroke[],
  x: number,
  y: number,
  radius: number,
) {
  return strokes.filter((s) => !strokeHit(s, x, y, radius));
}
// Test the swept eraser path, not only each sampled point. Fast pen motion
// can cross a thin stroke entirely between two pointer events.
export function eraseInkPath(
  strokes: InkStroke[],
  from: InkPoint,
  to: InkPoint,
  radius: number,
) {
  const cross = (a: InkPoint, b: InkPoint, c: InkPoint) =>
    (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
  return strokes.filter((s) => {
    const r = radius + s.width * 0.7,
      p = s.points;
    if (p.length === 1) return segmentDistance(p[0][0], p[0][1], from, to) > r;
    for (let i = 1; i < p.length; i++) {
      const a = p[i - 1],
        b = p[i];
      if (
        Math.min(
          segmentDistance(a[0], a[1], from, to),
          segmentDistance(b[0], b[1], from, to),
          segmentDistance(from[0], from[1], a, b),
          segmentDistance(to[0], to[1], a, b),
        ) <= r
      )
        return false;
      if (
        cross(from, to, a) * cross(from, to, b) < 0 &&
        cross(a, b, from) * cross(a, b, to) < 0
      )
        return false;
    }
    return true;
  });
}
export function zoomInk(
  view: InkView,
  scale: number,
  anchorX: number,
  anchorY: number,
): InkView {
  const next = Math.max(0.15, Math.min(4, scale)),
    ratio = next / view.scale;
  return {
    scale: next,
    x: anchorX - (anchorX - view.x) * ratio,
    y: anchorY - (anchorY - view.y) * ratio,
  };
}
export function constrainInkView(
  view: InkView,
  width: number,
  height: number,
): InkView {
  const w = PAPER_WIDTH * view.scale,
    h = PAPER_HEIGHT * view.scale;
  return {
    ...view,
    x:
      w <= width
        ? (width - w) / 2
        : Math.max(width - w - 28, Math.min(28, view.x)),
    y:
      h <= height
        ? (height - h) / 2
        : Math.max(height - h - 28, Math.min(28, view.y)),
  };
}
export function replaceInkPage(book: InkBook, page: InkPage): InkBook {
  return {
    ...book,
    pages: book.pages.map((p) => (p.id === page.id ? page : p)),
    updatedAt: new Date().toISOString(),
  };
}

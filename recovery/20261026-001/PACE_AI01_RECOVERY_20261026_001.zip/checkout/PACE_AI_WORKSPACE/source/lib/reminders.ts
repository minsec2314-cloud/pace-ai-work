import type { Assessment, StudyState } from './study.ts';
export function taskDueAt(t:Assessment){return new Date(`${t.due}T${t.dueTime||'23:59'}:00+09:00`).getTime();}
export function dueReminders(state:StudyState,now=Date.now()){return state.assessments.filter(t=>!t.done&&(t.reminderMinutes??1440)>=0).map(t=>({task:t,at:taskDueAt(t)-(t.reminderMinutes??1440)*60000,key:`${t.id}:${t.due}:${t.dueTime||'23:59'}:${t.reminderMinutes??1440}`})).filter(r=>now>=r.at&&now<=taskDueAt(r.task)+300000);}
function escapeICS(s:string){return s.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/;/g,'\\;').replace(/,/g,'\\,');}
function utcStamp(ms:number){return new Date(ms).toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z$/,'Z');}
function foldICS(line:string){const encoder=new TextEncoder();let output='';let current='';for(const char of line){if(encoder.encode(current+char).length>73){output+=current+'\r\n ';current=char;}else current+=char;}return output+current;}
export function exportCalendar(state:StudyState,now=Date.now()){
 const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//PACE Study//KO','CALSCALE:GREGORIAN','METHOD:PUBLISH'];
 for(const task of state.assessments.filter(t=>!t.done)){
  const due=taskDueAt(task);if(!Number.isFinite(due))continue;
  lines.push('BEGIN:VEVENT',`UID:${task.id}@pace-study`,`DTSTAMP:${utcStamp(now)}`,`DTSTART:${utcStamp(due-30*60000)}`,`DTEND:${utcStamp(due)}`,`SUMMARY:${escapeICS(task.title+' 마감')}`,`DESCRIPTION:${escapeICS(`${state.subjects.find(s=>s.id===task.subjectId)?.name||''}\n${task.note}\n페이스에서 준비 기록을 확인하세요.`)}`);
  if((task.reminderMinutes??1440)>=0)lines.push('BEGIN:VALARM','ACTION:DISPLAY',`DESCRIPTION:${escapeICS(task.title+' 마감 알림')}`,`TRIGGER;RELATED=END:-PT${task.reminderMinutes??1440}M`,'END:VALARM');
  lines.push('END:VEVENT');
 }
 lines.push('END:VCALENDAR');return lines.map(foldICS).join('\r\n')+'\r\n';
}

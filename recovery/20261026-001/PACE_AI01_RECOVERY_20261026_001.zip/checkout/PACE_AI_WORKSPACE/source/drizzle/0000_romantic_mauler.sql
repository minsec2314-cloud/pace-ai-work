CREATE TABLE `alarm_deliveries` (
	`id` text PRIMARY KEY NOT NULL,
	`alarm_id` text NOT NULL,
	`user_id` text NOT NULL,
	`device_id` text NOT NULL,
	`scheduled_for` integer NOT NULL,
	`status` text NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `deliveries_alarm` ON `alarm_deliveries` (`alarm_id`);--> statement-breakpoint
CREATE TABLE `alarm_schedules` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`title` text NOT NULL,
	`fire_at` integer NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`repeat` text DEFAULT 'none' NOT NULL,
	`task_id` text,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `alarms_due` ON `alarm_schedules` (`status`,`fire_at`);--> statement-breakpoint
CREATE INDEX `alarms_user` ON `alarm_schedules` (`user_id`);--> statement-breakpoint
CREATE TABLE `push_devices` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`subscription_json` text NOT NULL,
	`created_at` integer NOT NULL,
	`enabled` integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `devices_user` ON `push_devices` (`user_id`);--> statement-breakpoint
CREATE TABLE `scheduler_health` (
	`key` text PRIMARY KEY NOT NULL,
	`last_run` integer NOT NULL,
	`run_count` integer DEFAULT 0 NOT NULL
);

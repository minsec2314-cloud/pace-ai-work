import test from "node:test";
import assert from "node:assert/strict";
import {
  newInkBook,
  newInkPage,
  validInkBook,
  normalizeInkPoint,
  eraseInk,
  eraseInkPath,
  zoomInk,
  constrainInkView,
  replaceInkPage,
  PAPER_WIDTH,
  PAPER_HEIGHT,
} from "../lib/ink.ts";
const stroke = (id = "s") => ({
  id,
  tool: "pen",
  color: "#252838",
  width: 3,
  points: [
    [100, 100, 0.2],
    [300, 300, 0.9],
  ],
});
function filled() {
  const b = newInkBook("task-1", "탐구 생각");
  b.pages[0].strokes = [stroke()];
  return b;
}

test("handwriting backup preserves pressure, pages and PDF references through JSON", () => {
  const b = filled();
  b.pages.push({
    ...newInkPage(2),
    paper: "grid",
    background: { materialId: "pdf", page: 12, name: "수학.pdf" },
  });
  const copy = JSON.parse(JSON.stringify(b));
  assert(validInkBook(copy));
  assert.deepEqual(copy, b);
});
test("rejects damaged handwriting before it reaches the canvas or database", () => {
  for (const damage of [
    (b) => (b.pages[0].strokes[0].points[0][0] = NaN),
    (b) => (b.pages[0].strokes[0].points[0][1] = Infinity),
    (b) => (b.pages[0].strokes[0].points[0][2] = 2),
    (b) => (b.pages[0].strokes[0].color = "url(bad)"),
    (b) => (b.pages[0].strokes[0].width = -1),
    (b) => b.pages.push(b.pages[0]),
    (b) => b.pages[0].strokes.push(b.pages[0].strokes[0]),
    (b) => (b.activePageId = "missing"),
    (b) => (b.taskId = "other"),
    (b) => (b.pages = []),
    (b) => (b.pages[0].background = { materialId: "p", page: 0, name: "p" }),
    (b) => (b.pages[0].strokes[0].points = null),
  ]) {
    const b = filled();
    damage(b);
    assert.equal(validInkBook(b), false);
  }
  assert.equal(validInkBook(null), false);
  assert.equal(validInkBook({ pages: [null] }), false);
});
test("ink coordinates and pressure stay bounded and compact", () => {
  assert.deepEqual(normalizeInkPoint(-7, 9999, 3), [0, PAPER_HEIGHT, 1]);
  assert.deepEqual(
    normalizeInkPoint(10.1234, 20.5654, NaN),
    [10.12, 20.57, 0.5],
  );
});
test("eraser hits between sparse sampled points, erases taps, and leaves nearby strokes intact", () => {
  const a = stroke(),
    tap = { ...stroke("tap"), points: [[500, 500, 0.5]] };
  assert.deepEqual(eraseInk([a, tap], 200, 200, 4), [tap]);
  assert.deepEqual(eraseInk([a, tap], 500, 500, 4), [a]);
  assert.equal(eraseInk([a], 250, 100, 4)[0], a);
  assert.equal(a.points.length, 2);
});
test("fast eraser removes crossed strokes even when both event endpoints miss", () => {
  const a = stroke(),
    from = [300, 100, 0.5],
    to = [100, 300, 0.5];
  assert.equal(eraseInk([a], ...from.slice(0, 2), 4).length, 1);
  assert.equal(eraseInk([a], ...to.slice(0, 2), 4).length, 1);
  assert.deepEqual(eraseInkPath([a], from, to, 4), []);
  assert.equal(eraseInkPath([a], [500, 500, 0.5], [600, 600, 0.5], 4)[0], a);
});
test("zoom keeps the page coordinate beneath the fingers fixed", () => {
  const v = { scale: 0.7, x: -120, y: -80 },
    x = 420,
    y = 220,
    n = zoomInk(v, 1.4, x, y);
  assert.equal((x - n.x) / n.scale, (x - v.x) / v.scale);
  assert.equal((y - n.y) / n.scale, (y - v.y) / v.scale);
  assert.equal(zoomInk(v, 100, x, y).scale, 4);
  assert.equal(zoomInk(v, 0, x, y).scale, 0.15);
});
test("viewport cannot lose the sheet even after extreme panning", () => {
  const v = constrainInkView({ scale: 2, x: 99999, y: -99999 }, 700, 500);
  assert(v.x <= 28);
  assert(v.y >= 500 - PAPER_HEIGHT * 2 - 28);
  const fit = constrainInkView({ scale: 0.2, x: 90, y: 90 }, 700, 500);
  assert.equal(fit.x, (700 - PAPER_WIDTH * 0.2) / 2);
  assert.equal(fit.y, (500 - PAPER_HEIGHT * 0.2) / 2);
});
test("page changes preserve other pages and the undo snapshot", () => {
  const b = filled(),
    second = newInkPage(2);
  b.pages.push(second);
  const first = b.pages[0],
    updated = replaceInkPage(b, { ...first, strokes: [] });
  assert.equal(first.strokes.length, 1);
  assert.equal(updated.pages[0].strokes.length, 0);
  assert.equal(updated.pages[1], second);
  assert.equal(b.pages[0], first);
});

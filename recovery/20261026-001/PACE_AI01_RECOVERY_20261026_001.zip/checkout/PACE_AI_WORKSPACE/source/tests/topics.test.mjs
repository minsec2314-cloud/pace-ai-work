import test from 'node:test';import assert from 'node:assert/strict';
import {readTopicIdeas,topicNote} from '../lib/topics.ts';
import {generateAI,validateAIInput} from '../lib/ai.ts';
import {initialState,validateState} from '../lib/study.ts';
const idea={title:'교실 소음과 시간대 비교',question:'교실 소음은 시간대별로 어떻게 다른가?',why:'학교 생활과 물리의 파동 개념을 연결한다.',method:'같은 기기와 위치로 하루 세 번 측정하고 날짜별로 비교한다.',supplies:'휴대폰 소음 측정 앱. 절대 소음 수치보다 상대 변화로 비교한다.',firstSteps:['측정할 장소 정하기','같은 조건 정리하기','선생님과 계획 확인하기'],cautions:'대화를 녹음하지 않고 다른 사람의 개인정보를 수집하지 않는다.'};
const distinctIdeas=[idea,{...idea,title:'장소별 소음 비교',question:'교실 소음은 장소별로 어떻게 다른가?'},{...idea,title:'요일별 소음 비교',question:'교실 소음은 요일별로 어떻게 다른가?'}];
test('topic exploration does not require an activity or uploaded material',()=>{const input=validateAIInput({mode:'topics',subject:'물리학',question:'학교 소음, 7일, 휴대폰 사용',materials:[]});assert.equal(input.mode,'topics');assert.equal(input.materials.length,0);assert.equal(readTopicIdeas({ideas:distinctIdeas}).length,3);});
test('malformed or empty candidates never become saved activities',()=>{for(const output of [{ideas:[]},{ideas:[idea]},{ideas:[idea,idea,{...idea,firstSteps:['하나']}]},{ideas:[idea,idea,{...idea,question:''}]}])assert.throws(()=>readTopicIdeas(output));});
test('topic drafts and candidates survive a validated backup before any activity exists',()=>{const state=initialState();state.topicLab={interest:'소음',subject:'물리학',constraints:'휴대폰',days:7,refinement:'측정 중심',ideas:[idea,idea,idea],updatedAt:new Date().toISOString()};assert(validateState(JSON.parse(JSON.stringify(state))));assert.equal(state.assessments.length,0);state.topicLab.days=0;assert(!validateState(state));state.topicLab.days=7;state.topicLab.ideas=[{...idea,firstSteps:null}];assert(!validateState(state));});
test('selected topic preserves method and limits for the research workspace',()=>{const note=topicNote(idea);assert(note.includes(idea.question));assert(note.includes(idea.method));assert(note.includes(idea.cautions));assert(note.includes('AI가 제안한 탐구 초안'));});
test('AI topic request uses exploratory schema and validates its actual response',async()=>{let sent;const fetcher=async(_url,request)=>{sent=JSON.parse(request.body);return Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({ideas:distinctIdeas})}}]});};const result=await generateAI({mode:'topics',subject:'물리학',question:'소음 주제 7일 탐구',materials:[]},'test-only',fetcher);assert.equal(result.ideas.length,3);assert(sent.messages[0].content.includes('정확히 3개'));assert(!sent.messages[0].content.includes('문제집 제목'));assert(sent.messages[0].content.includes('실제 검색 결과를 확인한 척하지'));});

test('topic parser rejects duplicate central questions rather than returning three copies',()=>{
 assert.throws(()=>readTopicIdeas({ideas:[idea,idea,idea]}),/중복|서로 다른/);
 assert.throws(()=>readTopicIdeas({ideas:[idea,{...idea,title:'다른 제목',question:'  '+idea.question+'  '},{...idea,question:'교실 소음은 요일별로 어떻게 다른가?'}]}),/중복|서로 다른/);
});
test('topic parser does not infer duplicates from shared titles or methods alone',()=>{
 const ideas=[idea,{...idea,question:'교실 소음은 장소별로 어떻게 다른가?'},{...idea,question:'교실 소음은 요일별로 어떻게 다른가?'}];
 assert.deepEqual(readTopicIdeas({ideas}),ideas);
});

test('duplicate topic questions trigger one bounded repair before a distinct result is returned',async()=>{
 let calls=0;
 const result=await generateAI({mode:'topics',subject:'물리학',question:'학교 소음, 7일, 휴대폰 사용',materials:[]},'synthetic-only',async()=>{
  calls++;return Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({ideas:calls===1?[idea,idea,idea]:distinctIdeas})}}]});
 });
 assert.equal(calls,2);assert.deepEqual(result.ideas,distinctIdeas);
});
test('persistent duplicate topic questions fail after two calls instead of becoming saved candidates',async()=>{
 let calls=0;
 await assert.rejects(generateAI({mode:'topics',subject:'물리학',question:'학교 소음, 7일, 휴대폰 사용',materials:[]},'synthetic-only',async()=>{
  calls++;return Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({ideas:[idea,idea,idea]})}}]});
 }),e=>e.status===502&&/중복/.test(e.message));
 assert.equal(calls,2);
});

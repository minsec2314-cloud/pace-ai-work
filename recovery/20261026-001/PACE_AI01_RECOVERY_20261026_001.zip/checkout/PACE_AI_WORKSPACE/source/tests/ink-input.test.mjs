import test from "node:test";
import assert from "node:assert/strict";
import { inkPointerTool, inkPenContact } from "../lib/ink-input.ts";

test("barrel hold temporarily erases and release restores the selected pen or highlighter", () => {
  for (const selected of ["pen", "highlighter", "hand"]) {
    const events = [
      { buttons: 1, pressure: 0.4 },
      { buttons: 3, pressure: 0.5 },
      { buttons: 3, pressure: 0.5 },
      { buttons: 1, pressure: 0.4 },
    ].map((e) => ({ ...e, pointerType: "pen" }));
    assert.deepEqual(
      events.map((e) => inkPointerTool(selected, e)),
      [selected, "eraser", "eraser", selected],
    );
    assert(events.every(inkPenContact));
  }
});
test("hovering while holding the button cannot erase or draw", () => {
  const hover = { pointerType: "pen", buttons: 2, pressure: 0 };
  assert.equal(inkPointerTool("pen", hover), "eraser");
  assert.equal(inkPenContact(hover), false);
  assert.equal(inkPenContact({ ...hover, buttons: 3 }), true);
  assert.equal(inkPenContact({ ...hover, buttons: 0 }), false);
});
test("lifting the tip while holding the barrel ends the stroke before pointerup", () => {
  const events = [
    { buttons: 3, pressure: 0.5 },
    { buttons: 2, pressure: 0 },
    { buttons: 2, pressure: 0 },
    { buttons: 0, pressure: 0 },
  ].map((e) => ({ ...e, pointerType: "pen" }));
  assert.deepEqual(events.map(inkPenContact), [true, false, false, false]);
});
test("real eraser tip is supported while mouse right-click is not treated as a pen shortcut", () => {
  assert.equal(
    inkPointerTool("pen", { pointerType: "pen", buttons: 32, pressure: 0.5 }),
    "eraser",
  );
  assert(inkPenContact({ pointerType: "pen", buttons: 32, pressure: 0.5 }));
  assert.equal(
    inkPointerTool("pen", { pointerType: "mouse", buttons: 3, pressure: 0.5 }),
    "pen",
  );
  assert.equal(
    inkPointerTool("eraser", { pointerType: "pen", buttons: 1, pressure: 0.5 }),
    "eraser",
  );
});

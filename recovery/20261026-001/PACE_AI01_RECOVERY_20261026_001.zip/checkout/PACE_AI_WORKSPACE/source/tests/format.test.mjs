import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import ts from 'typescript';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {prepareMarkdown} from '../lib/format.ts';

const directory=new URL('../.sites-runtime/render-tests/',import.meta.url);
await mkdir(directory,{recursive:true});
const source=(await readFile(new URL('../components/formatted-text.tsx',import.meta.url),'utf8')).replace("'../lib/format'",JSON.stringify(new URL('../lib/format.ts',import.meta.url).href));
const compiled=ts.transpileModule(source,{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const target=new URL('formatted-text.mjs',directory);await writeFile(target,compiled);
const {default:FormattedText}=await import(target.href);
const render=text=>renderToStaticMarkup(React.createElement(FormattedText,{text}));

test('renders emphasis, headings, lists and tables instead of Markdown markers',()=>{
 const html=render('## 핵심\n\n**중요한 개념**입니다.\n\n- 첫 단계\n- 다음 단계\n\n| 개념 | 설명 |\n| --- | --- |\n| 극한 | 가까워짐 |');
 assert.match(html,/<strong>중요한 개념<\/strong>/);assert.match(html,/<h2>핵심<\/h2>/);assert.match(html,/<ul>/);assert.match(html,/<table>/);assert(!html.includes('**'));
});
test('renders Korean emphasis adjacent to particles and punctuation',()=>{
 const html=render('**‘근의 공식’**을 사용해요. **(중요)**입니다.');
 assert(!html.includes('**'));assert.match(html,/<strong>/);
});
test('typesets fractions, radicals, powers and multiplication as mathematical layout',()=>{
 const html=render(String.raw`정답은 $\frac{1+\sqrt{5}}{2}$입니다.\n\n$$x^{2}\times 3$$`);
 assert.match(html,/class="katex"/);assert.match(html,/<math /);assert.match(html,/<mfrac>/);assert.match(html,/<msqrt>/);assert.match(html,/<msup>/);assert(!html.includes('katex-error'));
});
test('typesets a bare LaTeX short answer when the model omits its delimiters',()=>{const html=render(String.raw`2\,\text{m}`);assert.match(html,/class="katex"/);assert(!html.replace(/<annotation[^>]*>[\s\S]*?<\/annotation>/g,'').includes('>2\\,'));assert.equal(prepareMarkdown('`\\frac{1}{2}`'),'`\\frac{1}{2}`');});
test('renders unwrapped simple fractions, multiplication and powers without changing links, code or dates',()=>{const html=render('파장은 v/f이며 x^2와 a*b를 확인한다.');assert.match(html,/<mfrac>/);assert.match(html,/<msup>/);assert.match(html,/×/);assert.equal(prepareMarkdown('`a/b` https://example.com/a/b 2026/10/18'),'`a/b` https://example.com/a/b 2026/10/18');});
test('normalizes alternate math delimiters and math code fences without corrupting ordinary code',()=>{
 assert.equal(prepareMarkdown('```latex\n\\frac{1}{2}\n```'),'$$\n\\frac{1}{2}\n\n$$');
 const html=render(String.raw`\[\frac{1}{2}\] 그리고 \(\sqrt{2}\)`);assert.match(html,/katex-display/);assert.match(html,/<msqrt>/);
 assert.equal(prepareMarkdown('`\\(example\\)`'),'`\\(example\\)`');
});
test('never falls back to exposing malformed TeX or trusting model HTML',()=>{
 const html=render(String.raw`$\unknowncommand{private}$ <script>alert(1)</script> ![tracking](https://example.com/pixel) [bad](javascript:alert(1))`);
 assert(!html.includes('unknowncommand'));assert(!html.includes('<script'));assert(!html.includes('<img'));assert(!html.includes('href="javascript:'));assert.match(html,/수식을 표시하지 못했어요/);
});

// The PDF paper uses the same Markdown/math renderer, and can omit solutions
// without leaving hidden answers in a student handout.
test('PDF paper preserves math and excludes all solutions when unchecked',async()=>{
 const source=(await readFile(new URL('../components/quiz-pdf.tsx',import.meta.url),'utf8')).replace("'./formatted-text'",JSON.stringify(target.href));
 const file=new URL('quiz-pdf.mjs',directory);
 await writeFile(file,ts.transpileModule(source,{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText);
 const {QuizPaper}=await import(file.href);
 const quiz={id:'print-test',subjectId:'math',mode:'exam',teacherLabel:'검증 선생님',title:'한글 문제집',analysis:'관찰 내용',limitations:'학습용',createdAt:'2026-10-18T00:00:00Z',scores:{},questions:[{type:'단답형',question:'**문제** $\\frac{1}{2}$',answer:'정답검증문자',explanation:'해설검증문자',citations:[{materialId:'material',page:3,quote:'원문검증문자'}]}]};
 const paper=answers=>renderToStaticMarkup(React.createElement(QuizPaper,{quiz,materials:[{id:'material',name:'수업 자료.pdf'}],answers,space:false}));
 const student=paper(false);assert.match(student,/한글 문제집/);assert.match(student,/<mfrac>/);assert(!student.includes('**'));assert(!student.includes('정답검증문자'));assert(!student.includes('해설검증문자'));assert(!student.includes('원문검증문자'));
 const teacher=paper(true);assert.match(teacher,/정답검증문자/);assert.match(teacher,/해설검증문자/);assert.match(teacher,/수업 자료.pdf/);assert.match(teacher,/원문검증문자/);
});

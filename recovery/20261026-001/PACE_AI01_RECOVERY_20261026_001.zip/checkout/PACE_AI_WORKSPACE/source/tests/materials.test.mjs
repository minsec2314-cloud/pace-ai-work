import test from 'node:test';import assert from 'node:assert/strict';
import {extractFile} from '../lib/materials.ts';
import {demoState,validateState} from '../lib/study.ts';
test('large text uploads are split losslessly into reloadable sections',async()=>{const text='가'.repeat(99999)+'🔬'+'실험 기록'.repeat(12000);const result=await extractFile(new File([text],'탐구 기록.txt'));assert(result.sections.length>1);assert(result.sections.every(s=>s.text.length<=100000));assert.equal(result.sections.map(s=>s.text).join(''),text);assert(!/[\uD800-\uDBFF]$/.test(result.sections[0].text));const state=demoState();state.materials[0].sections=result.sections;assert(validateState(state));});
test('empty text and old PPT uploads give actionable failures',async()=>{await assert.rejects(extractFile(new File(['   '],'empty.txt')),/빈 파일/);await assert.rejects(extractFile(new File(['test'],'old.ppt')),/PDF 또는 PPTX/);await assert.rejects(extractFile(new File(['x'],'unknown.exe')),/지원/);});

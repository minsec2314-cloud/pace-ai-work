import test from 'node:test';
import assert from 'node:assert/strict';
import {crossrefSources} from '../lib/research.ts';

for(const doi of ['10.1234/plain','10.1234/a?b','10.1234/a#b','10.1234/a?b#c','10.1234/part/with spaces']){
 test(`DOI resolver preserves the full identifier: ${doi}`,()=>{
  const [source]=crossrefSources([{DOI:doi,title:['Synthetic study']}]);
  const url=new URL(source.url);
  assert.equal(url.origin,'https://doi.org');
  assert.equal(url.search,'');assert.equal(url.hash,'');
  assert.equal(decodeURIComponent(url.pathname.slice(1)),doi);
  assert.equal(source.id,doi);
 });
}

import {searchResearch} from '../lib/research.ts';
const validWork={DOI:'10.1234/valid',title:['Valid synthetic study']};
test('one malformed search row does not discard a valid scholarly source',()=>{
 const sources=crossrefSources([null,{DOI:'10.1234/wrong-title',title:'not-an-array'},{DOI:'10.1234/empty',title:['<b> </b>']},validWork]);
 assert.equal(sources.length,1);assert.equal(sources[0].id,validWork.DOI);assert.equal(sources[0].title,validWork.title[0]);
});
test('malformed optional authors do not break a valid source or invent names',()=>{
 for(const author of [{given:'wrong container'},[null,{}, {given:42,family:'Kim'}]]){
  const sources=crossrefSources([{...validWork,author}]);
  assert.equal(sources.length,1);assert.equal(sources[0].authors,Array.isArray(author)?'Kim':'저자 정보 없음');
 }
});
test('an empty DOI suffix cannot become a scholarly resolver link',()=>{
 assert.deepEqual(crossrefSources([{DOI:'10.1234/',title:['Empty DOI']}]),[]);
});
test('malformed search envelope is a readable failure rather than a successful empty result',async()=>{
 let calls=0;
 for(const body of [null,{}, {message:{}},{message:{items:null}},{message:{items:{}}}]){
  await assert.rejects(searchResearch('synthetic study',async()=>{calls++;return Response.json(body);}),e=>e instanceof Error&&/형식/.test(e.message));
 }
 assert.equal(calls,5);
});

test('a non-JSON upstream response reports the search result format failure',async()=>{
 await assert.rejects(searchResearch('synthetic study',async()=>new Response('<html>upstream failure</html>',{headers:{'Content-Type':'text/html'}})),e=>e instanceof Error&&/형식/.test(e.message));
});

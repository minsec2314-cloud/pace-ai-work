import test from 'node:test';
import assert from 'node:assert/strict';
import {reviewQuestions} from '../lib/quiz-review.ts';
const questions=[{question:'함수 f(x)=x³+2x+1의 x=1에서의 미분계수는?',answer:'6',explanation:'잘못 생성한 답',type:'단답형',citations:[{materialId:'m',page:1,quote:'함수'}]}];
test('blind review receives no draft answers and replaces wrong calculation without losing references',async()=>{
 const result=await reviewQuestions(questions,'수학','test',Date.now()+20000,async(_url,r)=>{const payload=JSON.parse(r.body),task=JSON.parse(payload.messages.at(-1).content);assert.equal(task.questions[0].answer,undefined);assert.equal(task.questions[0].explanation,undefined);assert(!r.body.includes('잘못 생성한 답'));return Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({solutions:[{answer:'5',explanation:'도함수는 3x²+2이므로 x=1에서 5이다.'}]})}}]});});
 assert.equal(result[0].answer,'5');assert.deepEqual(result[0].citations,questions[0].citations);assert.equal(questions[0].answer,'6');
});
test('incomplete or unsolved review is never accepted as a checked quiz',async()=>{
 for(const solutions of [[],[{answer:'5',explanation:'',error:'조건 부족'}]])await assert.rejects(reviewQuestions(questions,'수학','test',Date.now()+20000,async()=>Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({solutions})}}]})),e=>e.status===502);
});
test('review quota failure is surfaced without saving unreviewed draft answers',async()=>{
 await assert.rejects(reviewQuestions(questions,'수학','test',Date.now()+20000,async()=>new Response('{}',{status:429})),e=>e.status===429);
});

for(const c of [
 {id:'algebra-equivalent',subject:'수학',question:'x를 두 번 더한 식은?',draft:'2x',review:'x+x'},
 {id:'water-paraphrase',subject:'생명과학',question:'광합성에서 방출되는 산소가 유래하는 반응물은?',draft:'물',review:'물(H₂O)'},
 {id:'water-formula',subject:'생명과학',question:'광합성에서 방출되는 산소가 유래하는 반응물은?',draft:'물',review:'H₂O'},
 {id:'unit-spacing',subject:'물리학',question:'2 kg 물체가 3 m/s²로 가속할 때 알짜힘은?',draft:'6 N',review:'6N'}
])test(`equivalent answer remains accepted: ${c.id}`,async()=>{
 const draft={...questions[0],question:c.question,answer:c.draft};
 const result=await reviewQuestions([draft],c.subject,'synthetic-only',Date.now()+20000,async()=>Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({solutions:[{answer:c.review,explanation:'자작 모의 동치 답'}]})}}]}));
 assert.equal(result[0].answer,c.review);assert.deepEqual(result[0].citations,draft.citations);assert.equal(draft.answer,c.draft);
});

for(const reason of ['content_filter','tool_calls',null,undefined])test(`non-completed review is not a checked quiz: ${String(reason)}`,async()=>{
 await assert.rejects(reviewQuestions(questions,'수학','synthetic-only',Date.now()+20000,async()=>Response.json({choices:[{finish_reason:reason,message:{content:JSON.stringify({solutions:[{answer:'5',explanation:'표면상 완성된 풀이'}]})}}]})),e=>e.status===502);
});

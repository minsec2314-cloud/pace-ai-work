import "fake-indexeddb/auto";
import test from "node:test";
import assert from "node:assert/strict";
import { newInkBook, newInkPage } from "../lib/ink.ts";
import { openDB, loadState, saveState, getOriginal } from "../lib/storage.ts";
import {
  loadInkBook,
  saveInkBook,
  createStudyBackup,
  restoreStudyBackup,
  validateStudyBackup,
  InkConflictError,
  recordInkDraft,
  acknowledgeInkDraft,
  trackInkWrite,
  discardInkDraft,
} from "../lib/ink-storage.ts";
import { demoState } from "../lib/study.ts";
const state = () => demoState("2026-10-19");
const book = (id) => {
  const b = newInkBook(id, "나의 탐구");
  b.pages[0].strokes = [
    {
      id: "line",
      tool: "pen",
      color: "#7560ba",
      width: 3,
      points: [
        [10, 20, 0.1],
        [150, 220, 0.8],
      ],
    },
  ];
  return b;
};

test("version 2 upgrade retains existing text notes and original PDFs", async () => {
  const old = await new Promise((resolve, reject) => {
    const r = indexedDB.open("pace-study-v1", 2);
    r.onupgradeneeded = () => {
      r.result.createObjectStore("state");
      r.result.createObjectStore("files");
    };
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
  const s = state();
  s.assessments[0].journal = "태블릿 기능 추가 전의 글 노트";
  await new Promise((resolve, reject) => {
    const tx = old.transaction(["state", "files"], "readwrite");
    tx.objectStore("state").put(s, "main");
    tx.objectStore("files").put(new Blob(["original PDF"]), "pdf");
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
  old.close();
  const db = await openDB();
  assert.equal(db.version, 3);
  assert(db.objectStoreNames.contains("ink"));
  db.close();
  assert.equal(
    (await loadState()).assessments[0].journal,
    s.assessments[0].journal,
  );
  assert.equal(await (await getOriginal("pdf")).text(), "original PDF");
});
test("saved handwriting survives reload, with activity isolation", async () => {
  const b = book("persist"),
    c = book("separate");
  b.pages.push(newInkPage(2));
  const saved = await saveInkBook(b, 0);
  await saveInkBook(c, 0);
  assert.equal(saved.revision, 1);
  assert.deepEqual(await loadInkBook(b.id), saved);
  assert.equal((await loadInkBook(c.id)).taskId, "separate");
  assert.equal(await loadInkBook("activity:unknown"), undefined);
});
test("two tabs cannot silently overwrite the same note", async () => {
  const b = book("concurrent");
  const result = await Promise.allSettled([
    saveInkBook(b, 0),
    saveInkBook({ ...b, title: "other tab" }, 0),
  ]);
  assert.equal(result.filter((r) => r.status === "fulfilled").length, 1);
  const failed = result.find((r) => r.status === "rejected");
  assert(failed.reason instanceof InkConflictError);
  const saved = await loadInkBook(b.id);
  assert.equal(saved.revision, 1);
  assert.equal(saved.title, "나의 탐구");
});
test("backup contains text and ink, but not original PDF binary", async () => {
  const s = state();
  s.assessments[0].journal = "원래 생각";
  await saveState(s);
  const backup = await createStudyBackup(s),
    copy = JSON.parse(JSON.stringify(backup));
  assert(validateStudyBackup(copy));
  assert(copy.handwriting.some((b) => b.taskId === "persist"));
  assert.equal(copy.assessments[0].journal, "원래 생각");
  assert.equal(copy.files, undefined);
});
test("corrupt imports are rejected without changing existing saved records", async () => {
  const before = await loadState(),
    b = await loadInkBook("activity:persist");
  const invalid = {
    ...state(),
    handwriting: [{ ...b, pages: [{ ...b.pages[0], strokes: [null] }] }],
  };
  assert(!validateStudyBackup(invalid));
  await assert.rejects(restoreStudyBackup(invalid));
  assert.deepEqual(await loadState(), before);
  assert.deepEqual(await loadInkBook(b.id), b);
});
test("restore invalidates stale editors and keeps ink out of the text state record", async () => {
  const b = await loadInkBook("activity:persist");
  const restored = await restoreStudyBackup({
    ...state(),
    handwriting: [{ ...b, title: "복원된 노트" }],
  });
  assert.equal(restored.handwriting, undefined);
  assert.equal((await loadState()).handwriting, undefined);
  const saved = await loadInkBook(b.id);
  assert.equal(saved.title, "복원된 노트");
  assert(saved.revision > b.revision);
  await assert.rejects(saveInkBook(b, b.revision), InkConflictError);
});
test("older text-only backups retain handwritten notes", async () => {
  const b = await loadInkBook("activity:persist");
  await restoreStudyBackup(state());
  assert.deepEqual(await loadInkBook(b.id), b);
});
test("unsaved draft is recoverable in both notebook reopen and whole-app backup", async () => {
  const b = book("unsaved");
  recordInkDraft(b, 0);
  assert.deepEqual(await loadInkBook(b.id), b);
  assert(
    (await createStudyBackup(state())).handwriting.some(
      (x) => x.taskId === "unsaved",
    ),
  );
  acknowledgeInkDraft(b, 1);
  assert.equal(await loadInkBook(b.id), undefined);
});

test("explicit conflict recovery reads the saved copy before releasing an unsaved draft", async () => {
  const saved = await saveInkBook(book("recover"), 0);
  const draft = { ...saved, title: "아직 저장하지 못한 수정" };
  recordInkDraft(draft, saved.revision);
  assert.equal((await loadInkBook(saved.id)).title, draft.title);
  assert.deepEqual(await loadInkBook(saved.id, true), saved);
  discardInkDraft(saved.id);
  assert.deepEqual(await loadInkBook(saved.id), saved);
});
test("backup waits for in-flight handwriting writes before reading the database", async () => {
  const b = book("pending");
  let finish;
  const p = new Promise((resolve) => {
    finish = resolve;
  }).then(() => saveInkBook(b, 0));
  trackInkWrite(p);
  const backup = createStudyBackup(state());
  finish();
  assert(
    (await backup).handwriting.some(
      (x) => x.taskId === "pending" && x.revision === 1,
    ),
  );
});

test("invalid revision cannot create a note that its own loader would reject", async () => {
  for (const revision of [-1, NaN, 1.5, Number.MAX_SAFE_INTEGER]) {
    await assert.rejects(saveInkBook(book("bad-revision"), revision));
  }
  assert.equal(await loadInkBook("activity:bad-revision"), undefined);
});

test("a damaged existing record is never silently replaced by a fresh blank notebook", async () => {
  const b = book("damaged"),
    db = await openDB();
  await new Promise((resolve, reject) => {
    const tx = db.transaction("ink", "readwrite");
    tx.objectStore("ink").put({ id: b.id, pages: null }, b.id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
  db.close();
  await assert.rejects(loadInkBook(b.id), /덮어쓰지/);
  await assert.rejects(saveInkBook(b, 0), /덮어쓰지/);
});

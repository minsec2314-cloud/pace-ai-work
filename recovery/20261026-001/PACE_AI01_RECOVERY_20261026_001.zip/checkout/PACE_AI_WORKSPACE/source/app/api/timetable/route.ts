import {getChatGPTUser} from '../../chatgpt-auth';
import {parseSchoolFeed,schoolWeek,type TimetableFeed} from '../../../lib/timetable-feed';
export const dynamic='force-dynamic';
const cache=new Map<string,{at:number;data:TimetableFeed}>();
export async function GET(request:Request){
 if(!await getChatGPTUser())return Response.json({error:'로그인이 필요합니다.'},{status:401});
 const q=new URL(request.url).searchParams,school=q.get('school')?.trim()||'',grade=Number(q.get('grade')),classNo=Number(q.get('class')),week=Number(q.get('week')||0),source=q.get('source');
 if(!school||school.length>60||!Number.isInteger(grade)||grade<1||grade>3||!Number.isInteger(classNo)||classNo<1||classNo>40||![0,1].includes(week)||!['comcigan','neis'].includes(source||''))return Response.json({error:'학교·학년·반·조회할 주를 확인해 주세요.'},{status:400});
 const expected=schoolWeek(week),key=JSON.stringify([school,grade,classNo,expected,source]);const previous=cache.get(key);
 if(previous&&Date.now()-previous.at<120000)return Response.json({...previous.data,cached:true},{headers:{'Cache-Control':'no-store'}});
 try{
  const url=new URL('https://api.timefor.school/timetable');url.search=new URLSearchParams({schoolname:school,grade:String(grade),classno:String(classNo),week:String(week),source:source!}).toString();
  const r=await fetch(url,{signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('upstream');
  const data=parseSchoolFeed(await r.json(),source as TimetableFeed['source'],expected);if(cache.size>=200)cache.delete(cache.keys().next().value!);cache.set(key,{at:Date.now(),data});
  return Response.json({...data,cached:false},{headers:{'Cache-Control':'no-store'}});
 }catch{return Response.json({error:source==='comcigan'?'컴시간 조회 경로에서 응답을 받지 못했습니다. 저장된 시간표는 유지합니다. 나이스 시간표를 별도로 조회하거나 원본을 확인해 주세요.':'나이스 시간표를 가져오지 못했습니다. 학교의 공개 여부와 정확한 학교명을 확인해 주세요.',source},{status:502,headers:{'Cache-Control':'no-store'}});}
}

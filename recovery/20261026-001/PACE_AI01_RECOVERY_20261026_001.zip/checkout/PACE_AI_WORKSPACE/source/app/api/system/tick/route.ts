import {runAlarmScheduler} from '../../../../lib/alarm-scheduler';
import type {AlarmEnv} from '../../../../lib/web-push';
export const dynamic='force-dynamic';
// Sites access is the outer boundary. A separate scoped secret protects this
// fixed updater even if the site's audience changes later.
let running=false;let lastAt=0;
export async function POST(request:Request){
 const {env}=await import('cloudflare:workers');const settings=env as AlarmEnv;
 if(!settings.ALARM_TICK_KEY)return Response.json({error:'정기 점검 키가 준비되지 않았습니다.'},{status:503});
 const supplied=request.headers.get('X-Pace-Alarm-Key')||'';
 const expected=new TextEncoder().encode(settings.ALARM_TICK_KEY),actual=new TextEncoder().encode(supplied);
 let different=expected.length^actual.length;for(let i=0;i<expected.length;i++)different|=expected[i]^(actual[i]||0);
 if(different)return Response.json({error:'허용되지 않은 점검 요청'},{status:401});
 if(request.headers.get('origin')&&request.headers.get('origin')!==new URL(request.url).origin)return Response.json({error:'허용되지 않은 요청'},{status:403});
 if(Number(request.headers.get('content-length')||0)>0)return Response.json({error:'이 작업은 입력을 받지 않습니다.'},{status:400});
 if(running||Date.now()-lastAt<15000)return Response.json({skipped:true});
 running=true;lastAt=Date.now();try{const source=request.headers.get('X-Pace-Scheduled')==='1'?'cloudtask':'probe';return Response.json(await runAlarmScheduler(settings,Date.now(),source),{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({error:'예약 알림을 점검하지 못했습니다.'},{status:503});}finally{running=false;}
}

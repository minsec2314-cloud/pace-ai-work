import { getChatGPTUser } from '../../chatgpt-auth';
import { AIError, generateAI } from '../../../lib/ai';
export const dynamic='force-dynamic';
const limits=new Map<string,{count:number;start:number}>();
function json(data:unknown,status=200){return Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});}
async function key(){const {env}=await import('cloudflare:workers');return (env as unknown as Record<string,string>).GROQ_API_KEY||'';}
export async function GET(){return json({configured:Boolean(await key()),provider:'Groq',model:'openai/gpt-oss-120b'});}
export async function POST(request:Request){
 const user=await getChatGPTUser();if(!user)return json({error:'AI를 이용하려면 로그인해 주세요.'},401);
 const origin=request.headers.get('origin');if(!origin||origin!==new URL(request.url).origin)return json({error:'허용되지 않은 요청입니다.'},403);
 if(!request.headers.get('content-type')?.includes('application/json'))return json({error:'JSON 요청만 허용합니다.'},415);
 const length=Number(request.headers.get('content-length'));if(length>5000000)return json({error:'선택한 자료가 너무 큽니다.'},413);
 const now=Date.now();for(const [id,v]of limits)if(now-v.start>60000)limits.delete(id);
 const previous=limits.get(user.userId)||{start:now,count:0};if(previous.count>=5)return json({error:'1분에 최대 5번 요청할 수 있어요. 잠시 쉬었다가 다시 시도해 주세요.'},429);
 previous.count++;limits.set(user.userId,previous);
 try{const text=await request.text();if(new TextEncoder().encode(text).length>5000000)return json({error:'선택한 자료가 너무 큽니다.'},413);let body:unknown;try{body=JSON.parse(text);}catch{return json({error:'요청을 읽을 수 없습니다.'},400);}return json(await generateAI(body,await key()));}catch(e){return json({error:e instanceof AIError?e.message:'요청을 처리하지 못했습니다. 잠시 후 다시 시도해 주세요.'},e instanceof AIError?e.status:500);}
}


import { getChatGPTUser } from '../../chatgpt-auth';
import { recognizePage } from '../../../lib/ocr';
import { AIError } from '../../../lib/ai';
export const dynamic='force-dynamic';
const calls=new Map<string,number>();
export async function POST(request:Request){const user=await getChatGPTUser();if(!user)return Response.json({error:'로그인이 필요합니다.'},{status:401});if(request.headers.get('origin')!==new URL(request.url).origin)return Response.json({error:'허용되지 않은 요청입니다.'},{status:403});const now=Date.now();if(now-(calls.get(user.userId)||0)<5000)return Response.json({error:'한 쪽씩 천천히 확인해 주세요.'},{status:429});calls.set(user.userId,now);try{const raw=await request.text();if(raw.length>4100000)throw new AIError('이미지가 너무 큽니다.',413);const data=JSON.parse(raw) as {image:unknown};const {env}=await import('cloudflare:workers');const key=(env as unknown as Record<string,string>).GROQ_API_KEY||'';return Response.json(await recognizePage(data.image,key),{headers:{'Cache-Control':'no-store'}});}catch(e){return Response.json({error:e instanceof AIError?e.message:'이미지 인식을 처리하지 못했습니다.'},{status:e instanceof AIError?e.status:400});}}

export const dynamic='force-dynamic';
export async function GET(){
 try{const {env}=await import('cloudflare:workers');const db=(env as unknown as {DB?:D1Database}).DB;if(!db)return Response.json({configured:false,schedulerReady:false},{headers:{'Cache-Control':'no-store'}});
 const row=await db.prepare("SELECT last_run,run_count FROM scheduler_health WHERE key IN ('cron','cloudtask') ORDER BY last_run DESC LIMIT 1").first<{last_run:number;run_count:number}>();
 return Response.json({configured:true,schedulerReady:Boolean(row&&Date.now()-row.last_run<720000),lastRun:row?.last_run||null,runCount:row?.run_count||0},{headers:{'Cache-Control':'no-store'}});
 }catch{return Response.json({configured:false,schedulerReady:false,error:'알람 서버 준비 상태를 확인하지 못했습니다.'},{status:503,headers:{'Cache-Control':'no-store'}});}
}


self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil(self.clients.openWindow(event.notification.data?.url||'/'));});
self.addEventListener('push',event=>{let data={};try{data=event.data?.json()||{};}catch{}const title=typeof data.title==='string'?data.title.slice(0,180):'페이스 알림';const body=typeof data.body==='string'?data.body.slice(0,500):'예약한 일정을 확인해 주세요.';event.waitUntil(self.registration.showNotification(title,{body,tag:typeof data.tag==='string'?data.tag:'pace-alarm',data:{url:'/'},icon:'/icon.svg'}));});

import {createHash} from 'node:crypto';
import fs from 'node:fs';
const assignment=JSON.parse(fs.readFileSync(new URL('./WORK_ASSIGNMENT.json',import.meta.url),'utf8'));
export const allowedAIPaths=Object.freeze(assignment.peer.allowedFiles);
const digest=b=>createHash('sha256').update(b).digest('hex');
const validPath=p=>typeof p==='string'&&allowedAIPaths.includes(p);
const str=v=>typeof v==='string'&&v.trim().length>0;
export function validateReturn(report,baseline,actualFiles){
 const fail=reason=>{throw Error('반환 계약 불일치: '+reason);};
 if(!report||report.protocolVersion!==2||report.taskId!=='AI-01')fail('작업/프로토콜');
 if(report.bundleId!==baseline.bundleId||report.sourceCommit!==baseline.sourceCommit)fail('기준 버전');
 if(!/^AI-01-[A-Za-z0-9-]{3,100}$/.test(report.submissionId||'')||!Number.isInteger(report.iteration)||report.iteration<1)fail('제출 ID/반복 번호');
 if(report.iteration===1?report.parentSubmissionId!==null:!/^AI-01-[A-Za-z0-9-]{3,100}$/.test(report.parentSubmissionId||''))fail('이전 제출 ID');
 if(report.parentSubmissionId===report.submissionId)fail('제출 순환');
 if(report.patchBase!=='original_bundle'||report.cumulative!==true)fail('누적 패치 기준');
 if(!['checkpoint','ready_for_integration','blocked','rate_limited'].includes(report.status)||!str(report.summary)||!str(report.nextAction))fail('상태/요약/다음 작업');
 if(!Array.isArray(report.limitations)||report.limitations.some(x=>!str(x)))fail('미검증 목록');
 if(!Array.isArray(report.tests)||report.tests.some(t=>!str(t.command)||!['pass','fail','not_run'].includes(t.result)||!str(t.evidence)))fail('검사 기록');
 if(report.status==='ready_for_integration'&&!report.tests.some(t=>t.result==='pass'))fail('실행 검사 없이 통합 완료 주장');
 if(!Array.isArray(report.changedFiles)||report.changedFiles.length>allowedAIPaths.length)fail('변경 파일 목록');
 const seen=new Set();
 for(const f of report.changedFiles){
   if(!validPath(f.path)||seen.has(f.path)||!/^\w{64}$/.test(f.sha256)||!/^[a-f0-9]{64}$/.test(f.sha256))fail('경로/중복/해시');
   seen.add(f.path);
   if(actualFiles){const bytes=actualFiles[`changes/${f.path}`];if(!bytes||digest(bytes)!==f.sha256)fail('실제 변경 파일 해시');}
 }
 if(actualFiles){
   for(const [name,bytes] of Object.entries(actualFiles)){
     if(name.startsWith('changes/')){if(!seen.has(name.slice(8)))fail('보고되지 않은 변경 파일');}
     else if(!['REPORT.json','REPORT.md','RECEIPT.json','CHECKPOINT.json','changes.patch'].includes(name))fail('예상 밖 첨부 파일');
     if(bytes.length>2e6)fail('첨부 파일 크기');
   }
   if(!actualFiles['REPORT.md'])fail('상세 보고서 누락');
   const patch=actualFiles['changes.patch'];
   if(patch){
     const text=Buffer.from(patch).toString('utf8');
     if(/GIT binary patch|Binary files |^deleted file mode /m.test(text))fail('바이너리/삭제 패치');
     const headers=[...text.matchAll(/^(?:---|\+\+\+) (.+)$/gm)].map(m=>m[1]);
     if(!headers.length&&report.changedFiles.length)fail('패치 헤더 누락');
     for(const p of headers){if(p==='/dev/null')continue;if(!/^[ab]\//.test(p)||!seen.has(p.slice(2)))fail('패치 경로');}
   }
 }
 return report;
}

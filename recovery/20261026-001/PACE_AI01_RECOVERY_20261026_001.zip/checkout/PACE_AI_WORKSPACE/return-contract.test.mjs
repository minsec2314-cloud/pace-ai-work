import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {validateReturn} from './return-contract.mjs';
const bytes=Buffer.from('export const example=1;');
const baseline={bundleId:'PACE-AI-01-example-r2',sourceCommit:'a'.repeat(40)};
const report={protocolVersion:2,taskId:'AI-01',...baseline,submissionId:'AI-01-example-001',iteration:1,parentSubmissionId:null,
 patchBase:'original_bundle',cumulative:true,status:'ready_for_integration',summary:'change',nextAction:'review',limitations:['Actual API untested'],
 tests:[{command:'node --test',result:'pass',evidence:'mock-only tests passed'}],
 changedFiles:[{path:'lib/ai.ts',sha256:createHash('sha256').update(bytes).digest('hex')}]};
const files={'REPORT.md':Buffer.from('Detailed report'),'changes/lib/ai.ts':bytes};
test('accepts a matching version and checks actual changed-file bytes',()=>{assert.equal(validateReturn(report,baseline,files),report);});
test('learning/research AI ownership includes topics and research but keeps shared UI and state out',()=>{
 for(const p of ['lib/topics.ts','lib/research.ts','tests/topics.test.mjs','tests/research-quality.test.mjs']){
  const r={...report,changedFiles:[{...report.changedFiles[0],path:p}]};
  assert.doesNotThrow(()=>validateReturn(r,baseline,{'REPORT.md':files['REPORT.md'],['changes/'+p]:bytes}));
 }
 for(const p of ['components/topic-explorer.tsx','app/api/research/route.ts','lib/study.ts'])
  assert.throws(()=>validateReturn({...report,changedFiles:[{...report.changedFiles[0],path:p}]},baseline));
});
test('rejects wrong task/version, duplicates, invalid state and missing evidence',()=>{
 for(const change of [{taskId:'other'},{protocolVersion:1},{bundleId:'old'},{sourceCommit:'b'.repeat(40)},
  {changedFiles:[...report.changedFiles,...report.changedFiles]},{tests:[]},{tests:[{command:'x',result:'pass',evidence:''}]},
  {cumulative:false},{patchBase:'last_patch'},{parentSubmissionId:report.submissionId},{iteration:2}])
   assert.throws(()=>validateReturn({...report,...change},baseline,files));
});
test('rejects out-of-scope files, altered content, hidden extra file and missing report',()=>{
 for(const bad of ['../lib/ai.ts','app/study-app.tsx','.env','lib/study.ts','lib/AI.ts','C:/secret'])
  assert.throws(()=>validateReturn({...report,changedFiles:[{...report.changedFiles[0],path:bad}]},baseline));
 assert.throws(()=>validateReturn(report,baseline,{...files,'changes/lib/ai.ts':Buffer.from('altered')}));
 assert.throws(()=>validateReturn(report,baseline,{...files,'changes/.env':Buffer.from('secret')}));
 assert.throws(()=>validateReturn(report,baseline,{'changes/lib/ai.ts':bytes}));
});
test('rejects patch paths outside declared changes and accepts a correctly scoped text patch',()=>{
 const ok=Buffer.from('--- a/lib/ai.ts\n+++ b/lib/ai.ts\n@@ -1 +1 @@\n-old\n+new\n');
 assert.doesNotThrow(()=>validateReturn(report,baseline,{...files,'changes.patch':ok}));
 for(const p of ['--- a/lib/study.ts\n+++ b/lib/study.ts\n','--- a/../../.env\n+++ b/../../.env\n','deleted file mode 100644\n','GIT binary patch\n'])
  assert.throws(()=>validateReturn(report,baseline,{...files,'changes.patch':Buffer.from(p)}));
});

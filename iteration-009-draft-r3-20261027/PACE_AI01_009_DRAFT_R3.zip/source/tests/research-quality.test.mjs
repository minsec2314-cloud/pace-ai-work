import test from 'node:test';
import assert from 'node:assert/strict';
import {searchResearch} from '../lib/research.ts';
const work=(title,abstract='')=>({DOI:'10.1234/'+encodeURIComponent(title),title:[title],abstract});
test('battery search excludes unrelated chemistry and preserves battery evidence',async()=>{
 let calls=0;
 const results=await searchResearch('차세대 화학전지',async()=>{calls++;return Response.json({message:{items:[work('Chemical analysis of ancient pottery'),work('Next generation rechargeable batteries'),work('Electrode materials','Sodium-ion batteries for energy storage')]}});});
 assert.equal(results.length,2);assert(!results.some(s=>s.title.includes('pottery')));assert.equal(calls,1);
});
test('specific battery chemistry cannot be replaced by another chemistry',async()=>{
 const result=await searchResearch('나트륨이온 전지',async()=>Response.json({message:{items:[work('Lithium-ion batteries'),work('Sodium-ion batteries')]}}));assert.equal(result.length,1);assert.match(result[0].title,/Sodium/);
});
test('unverifiable topic returns no filler',async()=>assert.deepEqual(await searchResearch('zznonexistenttopic',async()=>Response.json({message:{items:[work('Popular science')]}})),[]));
test('missing abstracts can use an explicit matching title',async()=>assert.equal((await searchResearch('photosynthesis',async()=>Response.json({message:{items:[work('Photosynthesis mechanisms')]}}))).length,1));
test('battery topic does not discard an additional safety constraint',async()=>{
 const r=await searchResearch('battery safety',async()=>Response.json({message:{items:[work('Battery market forecasts'),work('Battery safety under thermal stress')]}}));assert.equal(r.length,1);assert.match(r[0].title,/safety/);
});
test('solid-state physics does not silently become a battery query',async()=>{
 const r=await searchResearch('solid-state physics',async()=>Response.json({message:{items:[work('Solid-state batteries'),work('Solid-state physics of crystals')]}}));assert.equal(r.length,1);assert.match(r[0].title,/physics/);
});
for(const status of [429,500])test(`research HTTP${status} does not retry or fill results`,async()=>{let calls=0;await assert.rejects(searchResearch('batteries',async()=>{calls++;return new Response('{}',{status});}));assert.equal(calls,1);});

// This checks original-text assertions against selected excerpts, not work identity.
export function unsupportedLiteraryQuote(question:string,text:string,sources:string[]):boolean {
 const asserted=/(?:원문|원작|시구|구절|첫\s*행|첫\s*문장)[은는이가을를]?\s*(?:은|는|:|：|다음|["“‘「『])/;
 const originalRequested=/(원문|시구|인용)/.test(question);
 const explicitCreation=/(창작|지어\s*줘|써\s*줘)/.test(question)&&!/(원문|실제|인용)/.test(question);
 if(explicitCreation&&!asserted.test(text))return false;
 if(!originalRequested&&!asserted.test(text))return false;
 const normalize=(s:string)=>s.normalize('NFC').replace(/\s+/g,'');
 const quotes=[...text.matchAll(/["“‘「『]([^"”’」』\n]{4,500})["”’」』]/g)].map(m=>m[1]);
 // A model may omit quotation marks but still explicitly label a passage as original.
 for(const m of text.matchAll(/(?:원문|시구|구절)\s*[:：]\s*([^\n]{4,500})/g)){
  if(!/^["“‘「『]/.test(m[1]))quotes.push(m[1].trim());
 }
 return quotes.some(q=>!sources.some(s=>normalize(s).includes(normalize(q))));
}

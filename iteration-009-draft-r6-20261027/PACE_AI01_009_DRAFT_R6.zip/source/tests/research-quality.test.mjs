import test from 'node:test';
import assert from 'node:assert/strict';
import {searchResearch} from '../lib/research.ts';
const work=(title,abstract='')=>({DOI:'10.1234/'+encodeURIComponent(title),title:[title],abstract});
test('battery search excludes unrelated chemistry and preserves battery evidence',async()=>{
 let calls=0;
 const results=await searchResearch('차세대 화학전지',async()=>{calls++;return Response.json({message:{items:[work('Chemical analysis of ancient pottery'),work('Next generation rechargeable batteries'),work('Electrode materials','Sodium-ion batteries for energy storage')]}});});
 assert.equal(results.length,2);assert(!results.some(s=>s.title.includes('pottery')));assert.equal(calls,1);
});
test('specific battery chemistry cannot be replaced by another chemistry',async()=>{
 const result=await searchResearch('나트륨이온 전지',async()=>Response.json({message:{items:[work('Lithium-ion batteries'),work('Sodium-ion batteries')]}}));assert.equal(result.length,1);assert.match(result[0].title,/Sodium/);
});
test('unverifiable topic returns no filler',async()=>assert.deepEqual(await searchResearch('zznonexistenttopic',async()=>Response.json({message:{items:[work('Popular science')]}})),[]));
test('missing abstracts can use an explicit matching title',async()=>assert.equal((await searchResearch('photosynthesis',async()=>Response.json({message:{items:[work('Photosynthesis mechanisms')]}}))).length,1));
test('battery topic does not discard an additional safety constraint',async()=>{
 const r=await searchResearch('battery safety',async()=>Response.json({message:{items:[work('Battery market forecasts'),work('Battery safety under thermal stress')]}}));assert.equal(r.length,1);assert.match(r[0].title,/safety/);
});
test('solid-state physics does not silently become a battery query',async()=>{
 const r=await searchResearch('solid-state physics',async()=>Response.json({message:{items:[work('Solid-state batteries'),work('Solid-state physics of crystals')]}}));assert.equal(r.length,1);assert.match(r[0].title,/physics/);
});
for(const status of [429,500])test(`research HTTP${status} does not retry or fill results`,async()=>{let calls=0;await assert.rejects(searchResearch('batteries',async()=>{calls++;return new Response('{}',{status});}));assert.equal(calls,1);});
for(const [query,expected]of [['차세대 화학전지','next generation electrochemical batteries'],['전고체 전지','solid-state batteries'],['나트륨이온 전지','sodium-ion batteries'],['리튬황 전지','lithium-sulfur batteries']])test(`bounded bilingual query preserves intent:${query}`,async()=>{let sent,calls=0;await searchResearch(query,async url=>{sent=new URL(url).searchParams.get('query.bibliographic');calls++;return Response.json({message:{items:[]}});});assert.equal(sent,expected);assert.equal(calls,1);});
test('unmapped Korean constraints remain in the outgoing query',async()=>{let sent;await searchResearch('전고체 전지 저온',async url=>{sent=new URL(url).searchParams.get('query.bibliographic');return Response.json({message:{items:[]}});});assert.match(sent,/저온/);assert.match(sent,/solid-state/);});
test('non-battery homonym is not translated into batteries',async()=>{let sent;await searchResearch('전지적 작가 시점',async url=>{sent=new URL(url).searchParams.get('query.bibliographic');return Response.json({message:{items:[]}});});assert.equal(sent,'전지적 작가 시점');});
for(const [type,label]of [['component','구성자료'],['posted-content','게시자료'],['book-chapter','책의 장'],['journal-article','학술지 논문']])test(`Crossref supplied type is retained in source label:${type}`,async()=>{const results=await searchResearch('batteries',async()=>Response.json({message:{items:[{...work('Batteries overview'),type}]}}));assert.match(results[0].provider,new RegExp(label));assert(!/심사 완료|peer.reviewed/i.test(results[0].provider));});
test('unknown Crossref type does not become a journal article',async()=>{const r=await searchResearch('batteries',async()=>Response.json({message:{items:[{...work('Batteries overview'),type:'synthetic-unknown'}]}}));assert.match(r[0].provider,/유형 미확인/);});

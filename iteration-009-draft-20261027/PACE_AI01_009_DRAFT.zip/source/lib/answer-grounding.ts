// Conservative quotation guard, not a verifier of literary identity or interpretation.
export function unsupportedLiteraryQuote(question:string,text:string,sources:string[]):boolean {
 if(!/(원문|시구|구절|작품|소설|문학|가사|시인)/.test(question))return false;
 if(/(창작|지어\s*줘|써\s*줘)/.test(question)&&!/(원문|실제|인용)/.test(question))return false;
 const normalize=(s:string)=>s.normalize('NFC').replace(/\s+/g,'');
 const quotes=[...text.matchAll(/[“「]([^”」\n]{8,500})[”」]/g)].map(m=>m[1]);
 return quotes.some(q=>!sources.some(s=>normalize(s).includes(normalize(q))));
}

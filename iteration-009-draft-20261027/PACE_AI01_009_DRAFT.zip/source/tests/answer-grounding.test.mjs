import test from 'node:test';
import assert from 'node:assert/strict';
import {generateAI} from '../lib/ai.ts';
import {unsupportedLiteraryQuote as guard} from '../lib/answer-grounding.ts';
test('verified excerpt remains usable',()=>assert.equal(guard('작품 원문 해설','“확인 가능한 예제 문장입니다”',['앞부분 확인 가능한 예제 문장입니다 뒷부분']),false));
test('general factual explanations are not rejected',()=>assert.equal(guard('작품 설명','작가와 장르는 확인 가능한 자료에서 대조하세요.',[]),false));
test('explicit creation remains separate',()=>assert.equal(guard('문학 작품을 창작해줘','“내가 만든 새로운 문장입니다”',[]),false));
test('math quotations do not invoke literary guard',()=>assert.equal(guard('미분 설명','“순간 변화율을 나타냅니다”',[]),false));
test('literary explanation does not return an invented original quotation',async()=>{
 let calls=0;
 const result=await generateAI({mode:'ask',subject:'국어',question:'속미인곡의 원문과 의미를 설명해줘',materials:[]},'synthetic',async()=>{calls++;return Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({text:'속미인곡의 원문은 “은하수에 꽃배 띄워 그대를 만나리라”입니다.',referenceIds:[]})}}]});});
 assert(!result.text.includes('은하수에 꽃배'));
 assert.match(result.warning,/원문/);assert.equal(calls,1);
});

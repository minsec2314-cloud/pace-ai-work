import {validDate,type StudyState} from './study.ts';

export type StudyRoutine={id:string;subjectId:string;title:string;weekdays:number[];startsOn:string;archivedFrom?:string};
export type RoutineRecord={routineId:string;date:string;subjectId:string;title:string;status:'pending'|'done'|'skipped'};
export type RoutineItem=RoutineRecord;
export function removeSubjectRoutines(state:StudyState,subjectId:string){
 const removed=new Set((state.routines??[]).filter(r=>r.subjectId===subjectId).map(r=>r.id));
 return {routines:(state.routines??[]).filter(r=>r.subjectId!==subjectId),routineRecords:(state.routineRecords??[]).filter(r=>r.subjectId!==subjectId&&!removed.has(r.routineId))};
}
const key=(id:string,date:string)=>JSON.stringify([id,date]);
const text=(s:unknown,max:number):s is string=>typeof s==='string'&&s.trim().length>0&&s.length<=max;
export function validRoutineState(state:StudyState){
 const routines=state.routines===undefined?[]:state.routines,records=state.routineRecords===undefined?[]:state.routineRecords;
 if(!Array.isArray(routines)||routines.length>100||!Array.isArray(records)||records.length>20000)return false;
 const subjects=new Set(state.subjects.map(s=>s.id));
 if(!routines.every(r=>r&&text(r.id,100)&&subjects.has(r.subjectId)&&text(r.title,160)&&validDate(r.startsOn)&&(r.archivedFrom===undefined||validDate(r.archivedFrom))&&Array.isArray(r.weekdays)&&r.weekdays.length>0&&r.weekdays.length<=7&&r.weekdays.every(d=>Number.isInteger(d)&&d>=0&&d<=6)&&new Set(r.weekdays).size===r.weekdays.length))return false;
 const ids=new Set(routines.map(r=>r.id));if(ids.size!==routines.length)return false;
 return records.every(r=>r&&ids.has(r.routineId)&&subjects.has(r.subjectId)&&validDate(r.date)&&text(r.title,160)&&['pending','done','skipped'].includes(r.status))&&new Set(records.map(r=>key(r.routineId,r.date))).size===records.length;
}
export function routineItems(state:StudyState,date:string,today:string):RoutineItem[]{
 if(!validDate(date)||!validDate(today))return [];
 const records=(state.routineRecords??[]).filter(r=>r.date===date);
 const found=new Set(records.map(r=>r.routineId));
 // Past dates display recorded history only; rule edits never invent old work.
 const generated=date<today?[]:(state.routines??[]).filter(r=>!found.has(r.id)&&r.startsOn<=date&&(!r.archivedFrom||date<r.archivedFrom)&&r.weekdays.includes(new Date(date+'T00:00:00Z').getUTCDay())).map(r=>({routineId:r.id,date,subjectId:r.subjectId,title:r.title,status:'pending' as const}));
 return [...records,...generated];
}
export function recordRoutine(state:StudyState,id:string,date:string,status:RoutineRecord['status'],today:string):StudyState{
 if(!['pending','done','skipped'].includes(status)||!validDate(date)||!validDate(today)||date>today)return state;
 const item=routineItems(state,date,today).find(r=>r.routineId===id);if(!item)return state;
 const records=state.routineRecords??[];const index=records.findIndex(r=>r.routineId===id&&r.date===date);
 if(index<0&&records.length>=20000)return state;
 const next={...item,status};
 return {...state,routineRecords:index<0?[...records,next]:records.map((r,i)=>i===index?next:r)};
}

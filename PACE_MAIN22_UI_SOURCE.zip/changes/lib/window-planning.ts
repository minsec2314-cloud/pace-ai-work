import {availabilityForDay,type AvailabilityPlan} from './availability.ts';
import type {Session} from './study.ts';
export function freeStudyWindows(plan:AvailabilityPlan,date:string,done:Session[]){
 const day=availabilityForDay(plan,date);
 if(day.conflicts.length)return [];
 let legacy=done.filter(s=>s.date===date&&!s.startsAt).reduce((n,s)=>n+s.minutes,0);
 const result:{start:number;end:number;laptop:string;label:string;windowId:string}[]=[];
 for(const w of day.windows){
  let ranges=[{start:w.startMs,end:w.endMs}];
  for(const s of done.filter(s=>s.startsAt)){const start=Date.parse(s.startsAt!),end=start+s.minutes*60000;ranges=ranges.flatMap(r=>end<=r.start||start>=r.end?[r]:[{start:r.start,end:Math.min(start,r.end)},{start:Math.max(end,r.start),end:r.end}].filter(r=>r.end>r.start));}
  for(const r of ranges){const reserved=Math.min(legacy,(r.end-r.start)/60000);legacy-=reserved;const start=r.start+reserved*60000;if(start<r.end)result.push({start,end:r.end,laptop:w.laptop,label:w.label,windowId:w.windowId});}
 }
 return result;
}
export function koreaTime(ms:number){return new Date(ms+9*3600000).toISOString().slice(0,19)+'+09:00';}

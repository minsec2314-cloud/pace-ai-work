// Reference windows only. The existing daily planner is not connected to these
// windows until task tool requirements and preview/confirmation are implemented.
export type AvailabilityRule={
 id:string;label:string;weekdays:number[];start:string;end:string;dayOffset:0|1;
 place:'school'|'dorm'|'other';laptop:'allowed'|'forbidden'|'unknown';
 stayUntilEnd:boolean;activeFrom?:string;activeThrough?:string;
};
export type AvailabilityPlan={rules:AvailabilityRule[];enabled?:boolean};
export type AvailabilityWindow=AvailabilityRule&{
 windowId:string;studyDate:string;calendarDate:string;startsAt:string;endsAt:string;
 startMs:number;endMs:number;minutes:number;
};
export type AvailabilityDay={studyDate:string;windows:AvailabilityWindow[];
 conflicts:{first:string;second:string}[];minutes:number|null;laptopMinutes:number|null;unknownLaptopMinutes:number|null;};
const minute=(value:unknown,end=false):number|null=>{
 if(typeof value!=='string'||!/^\d{2}:\d{2}$/.test(value))return null;
 if(end&&value==='24:00')return 1440;
 const [hours,minutes]=value.split(':').map(Number);
 return hours<24&&minutes<60?hours*60+minutes:null;
};
function dateOK(value:unknown):value is string{
 return typeof value==='string'&&/^(19|20|21)\d{2}-\d{2}-\d{2}$/.test(value)&&Number.isFinite(Date.parse(value+'T00:00:00Z'))&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value;
}
function addDate(date:string,days:number){const d=new Date(date+'T00:00:00Z');d.setUTCDate(d.getUTCDate()+days);return d.toISOString().slice(0,10);}
const named=(value:unknown,max:number)=>typeof value==='string'&&value.trim().length>0&&value.length<=max;
export function validAvailability(value:unknown):value is AvailabilityPlan{
 if(!value||typeof value!=='object')return false;
 const rules=(value as AvailabilityPlan).rules;
 if((value as AvailabilityPlan).enabled!==undefined&&typeof (value as AvailabilityPlan).enabled!=='boolean')return false;
 if(!Array.isArray(rules)||rules.length>100)return false;
 return Array.from(rules).every(r=>{
  if(!r||!named(r.id,100)||!named(r.label,160)||!Array.isArray(r.weekdays)||!r.weekdays.length||r.weekdays.length>7||!Array.from(r.weekdays).every(d=>Number.isInteger(d)&&d>=0&&d<=6)||new Set(r.weekdays).size!==r.weekdays.length)return false;
  const start=minute(r.start),end=minute(r.end,true);
  return start!==null&&end!==null&&end>start&&end-start<=720&&[0,1].includes(r.dayOffset)&&['school','dorm','other'].includes(r.place)&&['allowed','forbidden','unknown'].includes(r.laptop)&&typeof r.stayUntilEnd==='boolean'&&(r.activeFrom===undefined||dateOK(r.activeFrom))&&(r.activeThrough===undefined||dateOK(r.activeThrough))&&(!r.activeFrom||!r.activeThrough||r.activeFrom<=r.activeThrough);
 })&&new Set(rules.map(r=>r.id)).size===rules.length;
}
function windowsFor(plan:AvailabilityPlan,date:string):AvailabilityWindow[]{
 const weekday=new Date(date+'T00:00:00Z').getUTCDay();
 return plan.rules.filter(r=>r.weekdays.includes(weekday)&&(!r.activeFrom||date>=r.activeFrom)&&(!r.activeThrough||date<=r.activeThrough)).map(r=>{
  const calendarDate=addDate(date,r.dayOffset);
  const startsAt=`${calendarDate}T${r.start}:00+09:00`;
  const endsAt=r.end==='24:00'?`${addDate(calendarDate,1)}T00:00:00+09:00`:`${calendarDate}T${r.end}:00+09:00`;
  const startMs=Date.parse(startsAt),endMs=Date.parse(endsAt);
  return {...r,weekdays:[...r.weekdays],windowId:JSON.stringify([date,r.id]),studyDate:date,calendarDate,startsAt,endsAt,startMs,endMs,minutes:(endMs-startMs)/60000};
 });
}
export function availabilityForDay(plan:AvailabilityPlan,date:string):AvailabilityDay{
 if(!validAvailability(plan)||!dateOK(date))throw new TypeError('Invalid study availability');
 const windows=windowsFor(plan,date).sort((a,b)=>a.startMs-b.startMs||a.windowId.localeCompare(b.windowId));
 // Adjacent study dates can refer to the same real calendar night. Check them
 // together so tomorrow's 00:00 is never budgeted twice under different anchors.
 const context=[...windowsFor(plan,addDate(date,-1)),...windows,...windowsFor(plan,addDate(date,1))];
 const own=new Set(windows.map(w=>w.windowId));const conflicts:AvailabilityDay['conflicts']=[];
 for(let i=0;i<context.length;i++)for(let j=i+1;j<context.length;j++){
  const a=context[i],b=context[j];if(!own.has(a.windowId)&&!own.has(b.windowId))continue;
  if(a.startMs<b.endMs&&b.startMs<a.endMs)conflicts.push({first:a.windowId,second:b.windowId});
 }
 const sum=(filter:(w:AvailabilityWindow)=>boolean)=>windows.filter(filter).reduce((n,w)=>n+w.minutes,0);
 return {studyDate:date,windows,conflicts,minutes:conflicts.length?null:sum(()=>true),laptopMinutes:conflicts.length?null:sum(w=>w.laptop==='allowed'),unknownLaptopMinutes:conflicts.length?null:sum(w=>w.laptop==='unknown')};
}
export function checkPlacement(day:AvailabilityDay,input:{windowId:string;startsAt:string;minutes:number;requiresLaptop:boolean}):{ok:boolean;reason?:'overlap'|'missing_window'|'invalid_time'|'outside_window'|'laptop_forbidden'|'laptop_unknown'}{
 if(day.conflicts.length)return {ok:false,reason:'overlap'};
 const window=day.windows.find(w=>w.windowId===input.windowId);if(!window)return {ok:false,reason:'missing_window'};
 if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:00\+09:00$/.test(input.startsAt)||!dateOK(input.startsAt.slice(0,10))||minute(input.startsAt.slice(11,16))===null||!Number.isInteger(input.minutes)||input.minutes<=0||input.minutes>720||typeof input.requiresLaptop!=='boolean')return {ok:false,reason:'invalid_time'};
 const start=Date.parse(input.startsAt),end=start+input.minutes*60000;
 if(!Number.isFinite(start)||start<window.startMs||end>window.endMs)return {ok:false,reason:'outside_window'};
 if(input.requiresLaptop&&window.laptop!=='allowed')return {ok:false,reason:window.laptop==='forbidden'?'laptop_forbidden':'laptop_unknown'};
 return {ok:true};
}
// This reports a boundary rule, never chooses when the student should sleep.
export function mayLeaveForSleep(window:AvailabilityWindow,at:number){
 return Number.isFinite(at)&&(!window.stayUntilEnd||at<window.startMs||at>=window.endMs);
}

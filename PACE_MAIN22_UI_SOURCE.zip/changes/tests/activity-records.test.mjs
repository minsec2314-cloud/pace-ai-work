import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState,replan,validateState,removeAssessment,subjectCompletedMinutes} from '../lib/study.ts';
import {preparationAudit} from '../lib/planning.ts';

function restoredBackup(){
 const state=initialState();
 state.profile.dailyMinutes=state.profile.weekendMinutes=120;
 state.subjects=[{id:'shared',name:'수학',color:'#6965db',examDate:'2026-10-21',scope:'시험 복습',minutes:90,confidence:3,teacher:''}];
 state.assessments=[{id:'shared',subjectId:'shared',title:'탐구',due:'2026-10-20',minutes:60,done:false,note:''}];
 state.sessions=[
  {id:'exam-done',sourceId:'shared',subjectId:'shared',kind:'subject',title:'시험 복습',date:'2026-10-18',minutes:30,done:true},
  {id:'task-done',sourceId:'shared',subjectId:'shared',kind:'task',title:'탐구',date:'2026-10-18',minutes:20,done:true},
  {id:'task-pending',sourceId:'shared',subjectId:'shared',kind:'task',title:'탐구',date:'2026-10-19',minutes:30,done:false},
 ];
 const restored=JSON.parse(JSON.stringify(state));assert(validateState(restored));return restored;
}
test('subject progress matches the preparation audit instead of including activity work',()=>{
 const state=restoredBackup();
 assert.equal(subjectCompletedMinutes(state,'shared'),30);
 assert.equal(subjectCompletedMinutes(state,'shared'),preparationAudit(state,'2026-10-19').find(j=>j.kind==='subject').completed);
 assert.equal(subjectCompletedMinutes(state,'missing'),0);
});
test('removing an activity preserves completed exam work across replanning and backup',()=>{
 const state=restoredBackup(),before=structuredClone(state);
 const removed=removeAssessment(state,'shared');
 assert.equal(removed.assessments.length,0);
 assert.deepEqual(removed.sessions,[state.sessions[0]],'only the activity sessions may be removed');
 const planned=replan(removed,'2026-10-19');
 assert.deepEqual(planned.sessions.find(s=>s.id==='exam-done'),state.sessions[0]);
 assert.equal(planned.sessions.filter(s=>!s.done&&s.kind==='subject').reduce((n,s)=>n+s.minutes,0),60,'completed exam time must not be scheduled again');
 assert(validateState(JSON.parse(JSON.stringify(planned))));
 assert.deepEqual(state,before,'the input backup must remain intact');
});

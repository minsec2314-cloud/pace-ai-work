import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState,replan,validateState} from '../lib/study.ts';
import {preparationAudit} from '../lib/planning.ts';

for(const completedKind of ['task','subject'])test(`completed ${completedKind} time does not reduce the other kind's workload after backup restore`,()=>{
 const state=initialState();
 state.profile.dailyMinutes=state.profile.weekendMinutes=120;
 state.subjects=[{id:'shared',name:'과학',color:'#6965db',examDate:'2026-10-20',scope:'시험 복습',minutes:60,confidence:3,teacher:''}];
 state.assessments=[{id:'shared',subjectId:'shared',title:'탐구 준비',due:'2026-10-19',minutes:60,done:false,note:''}];
 const completed={id:'saved-completed-session',sourceId:'shared',kind:completedKind,subjectId:'shared',title:'완료한 공부',date:'2026-10-18',minutes:30,done:true};
 state.sessions=[completed];
 const restored=JSON.parse(JSON.stringify(state));
 assert(validateState(restored),'IDs are unique within each collection; this is a supported backup');
 const planned=replan(restored,'2026-10-19');
 const audit=preparationAudit(planned,'2026-10-19');
 for(const kind of ['task','subject']){
  const item=audit.find(x=>x.kind===kind);
  const expected=kind===completedKind?30:60;
  assert.equal(item.scheduled,expected,`${kind} must receive its own remaining workload`);
  assert.equal(item.remaining,expected);
  assert.equal(item.shortage,0,'90 minutes of remaining work fit within 120 minutes');
 }
 assert.deepEqual(planned.sessions.find(x=>x.id===completed.id),completed,'completed history remains intact');
 assert.equal(planned.sessions.filter(x=>!x.done).reduce((n,x)=>n+x.minutes,0),90);
 assert(validateState(planned),'replanned state remains a valid backup');
 const twice=replan(planned,'2026-10-19');
 assert.equal(twice.sessions.filter(x=>x.done).length,1);
 assert.equal(twice.sessions.filter(x=>!x.done).reduce((n,x)=>n+x.minutes,0),90);
 assert.deepEqual(restored,state,'planning must not mutate restored history');
});

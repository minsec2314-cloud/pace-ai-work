'use client';
import {useState,type FormEvent} from 'react';
import {uid,validDate,type StudyState} from '../lib/study';
import {routineItems,recordRoutine,type StudyRoutine} from '../lib/routines';

const days=['일','월','화','수','목','금','토'];
export default function RoutineList({state,date,today,update,showManage=false}:{state:StudyState;date:string;today:string;update:(fn:(s:StudyState)=>StudyState)=>void;showManage?:boolean}){
 const [editing,setEditing]=useState(false),[editId,setEditId]=useState('');
 const [title,setTitle]=useState(''),[subjectId,setSubjectId]=useState(''),[weekdays,setWeekdays]=useState<number[]>([]),[startsOn,setStartsOn]=useState(today),[error,setError]=useState('');
 const items=routineItems(state,date,today),active=(state.routines??[]).filter(r=>!r.archivedFrom||r.archivedFrom>today);
 function open(r?:StudyRoutine){setEditId(r?.id??'');setTitle(r?.title??'');setSubjectId(r?.subjectId??state.subjects[0]?.id??'');setWeekdays(r?.weekdays??[]);setStartsOn(r?.startsOn??today);setError('');setEditing(true);}
 function save(e:FormEvent){e.preventDefault();if(!title.trim()||!subjectId||!weekdays.length||!validDate(startsOn)){setError('과목, 할 일, 시작일과 반복 요일을 확인해 주세요.');return;}if(!editId&&(state.routines??[]).length>=100){setError('반복 공부는 보관된 항목을 포함해 100개까지 저장할 수 있어요.');return;}
 const routine:StudyRoutine={id:editId||uid(),subjectId,title:title.trim(),weekdays:[...weekdays].sort(),startsOn};
 update(s=>({...s,routines:editId?(s.routines??[]).map(r=>r.id===editId?routine:r):[...(s.routines??[]),routine]}));setEditing(false);}
 function change(id:string,status:'pending'|'done'|'skipped'){
 if(date>today){setError('미래의 공부는 실제 공부한 날짜에 기록해 주세요.');return;}
 if((state.routineRecords??[]).length>=20000&&!(state.routineRecords??[]).some(r=>r.routineId===id&&r.date===date)){setError('기록 상한에 도달했어요. 기존 자료를 백업해 주세요.');return;}
 setError('');update(s=>recordRoutine(s,id,date,status,today));}
 return <section className="routine-list" aria-label="반복 공부">
  <div className="section-heading"><div><h3>반복 공부 · 시간 미배정</h3><p>{items.filter(r=>r.status==='done').length} / {items.length}개 완료 · 마감 없이 작은 목표를 이어가요.</p></div>{showManage&&<button type="button" className="text-btn" onClick={()=>open()} disabled={!state.subjects.length}>반복 공부 추가</button>}</div>
  <p className="form-note">이 목록은 자동 시간 배정과 남은 시간 계산에 포함되지 않아요.</p>
  {items.map(item=><div className={`routine-item ${item.status==='done'?'completed':''}`} key={item.routineId}>
   <button type="button" className="check-button" role="checkbox" aria-checked={item.status==='done'} aria-label={`${item.title} 반복 공부 ${item.status==='done'?'완료 취소':'완료'}`} disabled={date>today} onClick={()=>change(item.routineId,item.status==='done'?'pending':'done')}>{item.status==='done'?'✓':''}</button>
   <div><span className="muted-label">{state.subjects.find(s=>s.id===item.subjectId)?.name}</span><strong>{item.title}</strong>{item.status==='skipped'&&<span className="tag">오늘 건너뜀</span>}</div>
   <button type="button" className="text-btn" disabled={date>today} onClick={()=>change(item.routineId,item.status==='pending'?'skipped':'pending')}>{item.status==='pending'?'오늘 건너뛰기':'미완료로'}</button>
  </div>)}
  {!items.length&&<p className="empty-inline">{date<today?'이 날짜에 남긴 반복 공부 기록이 없어요.':'이 날짜의 반복 공부가 없어요.'}</p>}
  {showManage&&<><p className="form-note">과거 날짜에는 실제 남긴 기록만 표시해요. 미완료 공부를 다음 날에 자동으로 쌓지 않아요.</p>{!state.subjects.length&&<p className="form-note">먼저 과목을 추가해 주세요. 시험 날짜는 비워 두어도 돼요.</p>}
   {editing&&<form className="routine-form" onSubmit={save} aria-label="반복 공부 설정">
    <label className="field"><span>과목</span><select value={subjectId} onChange={e=>setSubjectId(e.target.value)} required>{state.subjects.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
    <label className="field"><span>반복할 공부</span><input value={title} maxLength={160} onChange={e=>setTitle(e.target.value)} placeholder="영어 단어 20개 복습" required/></label>
    <label className="field"><span>시작일</span><input type="date" value={startsOn} onChange={e=>setStartsOn(e.target.value)} required/></label>
    <div role="group" aria-label="반복 요일" className="routine-weekdays">{days.map((day,index)=><button type="button" key={day} role="checkbox" aria-checked={weekdays.includes(index)} onClick={()=>setWeekdays(v=>v.includes(index)?v.filter(d=>d!==index):[...v,index])}>{day}</button>)}</div>
    <div className="button-group"><button type="submit" className="btn">반복 공부 저장</button><button type="button" className="text-btn" onClick={()=>setEditing(false)}>취소</button></div>
   </form>}
   {!!active.length&&<details className="routine-manage"><summary>반복 규칙 관리 · {active.length}개</summary>{active.map(r=><div className="routine-item" key={r.id}><div><strong>{r.title}</strong><span>{r.weekdays.map(d=>days[d]).join('·')}</span></div><button type="button" className="text-btn" onClick={()=>open(r)}>수정</button><button type="button" className="text-btn" onClick={()=>update(s=>({...s,routines:(s.routines??[]).map(x=>x.id===r.id?{...x,archivedFrom:today}:x)}))}>반복 중지</button></div>)}<p className="form-note">수정·중지는 앞으로의 목록에 적용되며 이미 남긴 기록은 보존해요.</p></details>}
  </>}
  {error&&<p className="danger-text" role="alert">{error}</p>}
 </section>;
}

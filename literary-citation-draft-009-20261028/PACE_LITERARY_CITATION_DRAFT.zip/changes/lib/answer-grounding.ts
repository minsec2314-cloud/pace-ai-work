type LiterarySource=string|{text:string;name?:string};
type QuotedExcerpt={text:string;index:number;end?:number};
function quotedExcerpts(text:string){
 const pairs:Record<string,string>={'"':'"','“':'”','‘':'’','「':'」','『':'』'};
 const quotes:QuotedExcerpt[]=[],stack:string[]=[];let start=-1;
 for(let i=0;i<text.length;i++){
  const ch=text[i];
  if(stack.length&&ch===stack.at(-1)){
   stack.pop();
   if(!stack.length){if(text.slice(start+1,i).trim())quotes.push({text:text.slice(start+1,i),index:start,end:i+1});start=-1;}
  }else if(pairs[ch]){if(!stack.length)start=i;stack.push(pairs[ch]);}
 }
 return {quotes,unclosed:start>=0&&text.slice(start+1).trim().length>=1};
}
// Explicit title association is a metadata check, not independent bibliographic verification.
export function unsupportedLiteraryQuote(question:string,text:string,sources:LiterarySource[]):boolean {
 const markedText=text.replace(/\r\n?/g,'\n').replace(/^([ \t]*)(\*\*|__)(원문|시구|구절)[:：]?\2[ \t]*[:：]?/gm,'$1$3:').replace(/^([ \t]*)(원문|시구|구절)[ \t]*$/gm,'$1$2:');
 const asserted=/(?:원문|원작|시구|구절|첫\s*행|첫\s*문장)[은는이가을를]?\s*(?:은|는|:|：|다음|["“‘「『])/;
 const originalRequested=/(원문|시구|인용)/.test(question);
 const explicitCreation=/(창작|지어\s*줘|써\s*줘)/.test(question)&&!/(원문|실제|인용)/.test(question);
 if(explicitCreation&&!asserted.test(markedText))return false;
 if(!originalRequested&&!asserted.test(markedText))return false;
 const normalize=(s:string)=>s.normalize('NFC').replace(/\s+/g,'');
 // Line breaks and long excerpts must not skip evidence checks.
 // Inspect the complete quoted span/labelled line rather than silently ignoring or clipping it.
 const attributions=[...markedText.matchAll(/[「『《〈]([^」』》〉\n]{1,80})[」』》〉](?=\s*의\s*(?:원문|시구|구절))/g)].map(m=>({title:m[1].trim(),index:m.index!}));
 const scanned=quotedExcerpts(markedText);
 if(scanned.unclosed)return true; // An open outer quotation must not leave an unchecked suffix.
 const quotes=scanned.quotes.filter(q=>{
  if(attributions.some(a=>a.index===q.index))return false;
  if(q.text.trim().length>=4)return true;
  // Short terms in explanations are not automatically original text.
  // Explicit original framing or a standalone quoted response still requires evidence.
  const prefix=markedText.slice(0,q.index);
  return /(?:원문|시구|구절|첫\s*행|첫\s*문장)(?:은|는|이|가)?\s*[:：]?\s*$/.test(prefix)||(!prefix.trim()&&!markedText.slice(q.end).trim());
 });
 // Explicit unquoted original blocks continue until a blank line or a labelled explanation.
 // Do not validate only the first line while returning an unchecked continuation.
 for(const m of markedText.matchAll(/(?:원문|시구|구절)[ \t]*[:：][ \t]*/g)){
  const rest=markedText.slice(m.index!+m[0].length);
  if(/^["“‘「『]/.test(rest.trimStart()))continue; // Quoted spans are checked above.
  const lines=rest.replace(/^(?:[ \t]*\n)+/,'').split('\n');
  const block:string[]=[];
  const fence=lines[0]?.match(/^[ \t]*(`{3,}|~{3,})[^\n]*$/);
  if(fence){
   const close=new RegExp('^[ \\t]*'+fence[1][0]+'{'+fence[1].length+',}[ \\t]*$');
   for(const line of lines.slice(1)){if(close.test(line))break;block.push(line);}
  }else if(/^[ \t]*>/.test(lines[0]||'')){
   for(const line of lines){const quoted=line.match(/^[ \t]*>[ \t]?(.*)$/);if(!quoted)break;block.push(quoted[1]);}
  }else for(const line of lines){
   if(!line.trim()||/^(?:해설|설명|의미|풀이|분석|참고|출처)\s*[:：]/.test(line.trim()))break;
   block.push(line.trim());
  }
  const excerpt=block.join('\n');if(excerpt.trim().length>=1)quotes.push({text:excerpt,index:m.index!});
 }
 const titles=[...question.matchAll(/[「『《〈]([^」』》〉\n]{1,80})[」』》〉]/g)].map(m=>m[1].trim());
 const matchesTitle=(source:LiterarySource,title:string)=>{
  const identity=typeof source==='string'?source:(source.name||'')+'\n'+source.text;
  const escaped=title.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  return new RegExp('(^|[^\\p{L}\\p{N}])'+escaped+'(?=$|[^\\p{L}\\p{N}])','u').test(identity.normalize('NFC'));
 };
 return quotes.some(q=>{
  // A claimed work belongs to this excerpt,not any other work in the request.
  const attributed=attributions.filter(a=>a.index<q.index).at(-1)?.title;
  const targets=attributed?[attributed]:titles;
  const scoped=targets.length?sources.filter(source=>targets.some(title=>matchesTitle(source,title))):sources;
  return !scoped.some(source=>normalize(typeof source==='string'?source:source.text).includes(normalize(q.text)));
 });
}

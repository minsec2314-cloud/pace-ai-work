import test from 'node:test';
import assert from 'node:assert/strict';
import {crossrefSources} from '../lib/research.ts';

for(const doi of ['10.1234/plain','10.1234/a?b','10.1234/a#b','10.1234/a?b#c','10.1234/part/with spaces']){
 test(`DOI resolver preserves the full identifier: ${doi}`,()=>{
  const [source]=crossrefSources([{DOI:doi,title:['Synthetic study']}]);
  const url=new URL(source.url);
  assert.equal(url.origin,'https://doi.org');
  assert.equal(url.search,'');assert.equal(url.hash,'');
  assert.equal(decodeURIComponent(url.pathname.slice(1)),doi);
  assert.equal(source.id,doi);
 });
}

import {searchResearch} from '../lib/research.ts';
const validWork={DOI:'10.1234/valid',title:['Valid synthetic study']};
test('one malformed search row does not discard a valid scholarly source',()=>{
 const sources=crossrefSources([null,{DOI:'10.1234/wrong-title',title:'not-an-array'},{DOI:'10.1234/empty',title:['<b> </b>']},validWork]);
 assert.equal(sources.length,1);assert.equal(sources[0].id,validWork.DOI);assert.equal(sources[0].title,validWork.title[0]);
});
test('malformed optional authors do not break a valid source or invent names',()=>{
 for(const author of [{given:'wrong container'},[null,{}, {given:42,family:'Kim'}]]){
  const sources=crossrefSources([{...validWork,author}]);
  assert.equal(sources.length,1);assert.equal(sources[0].authors,Array.isArray(author)?'Kim':'저자 정보 없음');
 }
});
test('an empty DOI suffix cannot become a scholarly resolver link',()=>{
 assert.deepEqual(crossrefSources([{DOI:'10.1234/',title:['Empty DOI']}]),[]);
});
test('malformed search envelope is a readable failure rather than a successful empty result',async()=>{
 let calls=0;
 for(const body of [null,{}, {message:{}},{message:{items:null}},{message:{items:{}}}]){
  await assert.rejects(searchResearch('synthetic study',async()=>{calls++;return Response.json(body);}),e=>e instanceof Error&&/형식/.test(e.message));
 }
 assert.equal(calls,5);
});

test('a non-JSON upstream response reports the search result format failure',async()=>{
 await assert.rejects(searchResearch('synthetic study',async()=>new Response('<html>upstream failure</html>',{headers:{'Content-Type':'text/html'}})),e=>e instanceof Error&&/형식/.test(e.message));
});

// New metadata relevance/query coverage; original008 regression cases retained above.
const work=(title,abstract='')=>({DOI:'10.1234/'+encodeURIComponent(title),title:[title],abstract});
test('battery search excludes unrelated chemistry and preserves battery evidence',async()=>{
 let calls=0;
 const results=await searchResearch('차세대 화학전지',async()=>{calls++;return Response.json({message:{items:[work('Chemical analysis of ancient pottery'),work('Next generation rechargeable batteries'),work('Electrode materials','Sodium-ion batteries for energy storage')]}});});
 assert.equal(results.length,2);assert(!results.some(s=>s.title.includes('pottery')));assert.equal(calls,1);
});
test('specific battery chemistry cannot be replaced by another chemistry',async()=>{
 const result=await searchResearch('나트륨이온 전지',async()=>Response.json({message:{items:[work('Lithium-ion batteries'),work('Sodium-ion batteries')]}}));assert.equal(result.length,1);assert.match(result[0].title,/Sodium/);
});
test('unverifiable topic returns no filler',async()=>assert.deepEqual(await searchResearch('zznonexistenttopic',async()=>Response.json({message:{items:[work('Popular science')]}})),[]));
test('missing abstracts can use an explicit matching title',async()=>assert.equal((await searchResearch('photosynthesis',async()=>Response.json({message:{items:[work('Photosynthesis mechanisms')]}}))).length,1));
test('battery topic does not discard an additional safety constraint',async()=>{
 const r=await searchResearch('battery safety',async()=>Response.json({message:{items:[work('Battery market forecasts'),work('Battery safety under thermal stress')]}}));assert.equal(r.length,1);assert.match(r[0].title,/safety/);
});
test('solid-state physics does not silently become a battery query',async()=>{
 const r=await searchResearch('solid-state physics',async()=>Response.json({message:{items:[work('Solid-state batteries'),work('Solid-state physics of crystals')]}}));assert.equal(r.length,1);assert.match(r[0].title,/physics/);
});
for(const status of [429,500])test(`research HTTP${status} does not retry or fill results`,async()=>{let calls=0;await assert.rejects(searchResearch('batteries',async()=>{calls++;return new Response('{}',{status});}));assert.equal(calls,1);});
for(const [query,expected]of [['차세대 화학전지','next generation electrochemical batteries'],['전고체 전지','solid-state batteries'],['나트륨이온 전지','sodium-ion batteries'],['리튬황 전지','lithium-sulfur batteries']])test(`bounded bilingual query preserves intent:${query}`,async()=>{let sent,calls=0;await searchResearch(query,async url=>{sent=new URL(url).searchParams.get('query.bibliographic');calls++;return Response.json({message:{items:[]}});});assert.equal(sent,expected);assert.equal(calls,1);});
test('unmapped Korean constraints remain in the outgoing query',async()=>{let sent;await searchResearch('전고체 전지 저온',async url=>{sent=new URL(url).searchParams.get('query.bibliographic');return Response.json({message:{items:[]}});});assert.match(sent,/저온/);assert.match(sent,/solid-state/);});
test('non-battery homonym is not translated into batteries',async()=>{let sent;await searchResearch('전지적 작가 시점',async url=>{sent=new URL(url).searchParams.get('query.bibliographic');return Response.json({message:{items:[]}});});assert.equal(sent,'전지적 작가 시점');});
for(const [type,label]of [['component','구성자료'],['posted-content','게시자료'],['book-chapter','책의 장'],['journal-article','학술지 논문']])test(`Crossref supplied type is retained in source label:${type}`,async()=>{const results=await searchResearch('batteries',async()=>Response.json({message:{items:[{...work('Batteries overview'),type}]}}));assert.match(results[0].provider,new RegExp(label));assert(!/심사 완료|peer.reviewed/i.test(results[0].provider));});
test('unknown Crossref type does not become a journal article',async()=>{const r=await searchResearch('batteries',async()=>Response.json({message:{items:[{...work('Batteries overview'),type:'synthetic-unknown'}]}}));assert.match(r[0].provider,/유형 미확인/);});

test('non-battery bilingual concept and English synonym remain evidence-bound',async()=>{for(const query of ['광합성','photosynthesis','photosynthetic']){let calls=0;const result=await searchResearch(query,async url=>{calls++;if(query==='광합성')assert.equal(new URL(url).searchParams.get('query.bibliographic'),'photosynthesis');return Response.json({message:{items:[work('Photosynthetic light reactions'),work('Battery light indicators')]}});});assert.equal(result.length,1);assert.match(result[0].title,/Photosynthetic/);assert.equal(calls,1);}});
test('unmapped English constraint is not silently dropped',async()=>{assert.deepEqual(await searchResearch('photosynthesis magicconstraint',async()=>Response.json({message:{items:[work('Photosynthesis mechanisms')]}})),[]);});
const syntheticSource=title=>({id:'10.1234/test',url:'https://doi.org/10.1234/test',authors:'Synthetic',year:'2026',provider:'Synthetic',title,abstract:''});
import {researchMatches} from '../lib/research.ts';
test('MAIN006 single-character element constraint is not discarded',()=>assert.equal(researchMatches('차세대 전지 납',syntheticSource('Next generation sodium-ion batteries')),false));
test('MAIN006 chemical battery query excludes solar-only metadata',()=>assert.equal(researchMatches('화학전지',syntheticSource('고효율 태양전지의 광전 변환')),false));
test('MAIN006 spaced sodium-ion query retains relevant metadata',()=>assert.equal(researchMatches('나트륨 이온 전지',syntheticSource('Sodium-ion batteries for grid storage')),true));
for(const constraint of ['납','7','X'])test(`single-character constraint remains required:${constraint}`,()=>{assert.equal(researchMatches(`battery ${constraint}`,syntheticSource('Battery storage')),false);assert.equal(researchMatches(`battery ${constraint}`,syntheticSource(`Battery storage ${constraint}`)),true);});
test('chemical/solar comparison is not excluded when both have evidence',()=>assert.equal(researchMatches('화학전지',syntheticSource('태양전지와 화학전지의 에너지 변환 비교')),true));
test('one-digit constraint is not satisfied by a different multi-digit value',()=>assert.equal(researchMatches('battery 7',syntheticSource('Battery storage 17')),false));
test('single Latin condition is not inferred from inside another word',()=>assert.equal(researchMatches('battery X',syntheticSource('Battery oxide materials')),false));

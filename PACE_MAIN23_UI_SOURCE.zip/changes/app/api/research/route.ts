import { getChatGPTUser } from '../../chatgpt-auth';
import { searchResearch, researchProviderQuery } from '../../../lib/research';
export const dynamic='force-dynamic';
export async function GET(request:Request){if(!await getChatGPTUser())return Response.json({error:'자료 검색을 이용하려면 로그인해 주세요.'},{status:401});const q=new URL(request.url).searchParams.get('q')||'';try{return Response.json({sources:await searchResearch(q),query:{original:q,provider:researchProviderQuery(q),normalization:'fixed-scientific-aliases'},notice:'Crossref의 서지 정보와 제공된 초록입니다. 논문 본문을 읽거나 신뢰성을 보증한 결과가 아닙니다.'},{headers:{'Cache-Control':'private, max-age=300'}});}catch(e){return Response.json({error:e instanceof Error?e.message:'자료 검색에 실패했습니다.'},{status:502});}}
